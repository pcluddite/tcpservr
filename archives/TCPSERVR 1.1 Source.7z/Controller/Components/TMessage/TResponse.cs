﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Net.Sockets;
using System.Windows.Forms;

namespace Tcpclient {
    public class TResponse {

        public Socket Client { get; set; }
        private TReceiver receiver;

        public TResponse() {
        }

        public TResponse(TMessage original) {
            this.Original = original;
        }

        public TResponse(Socket client) {
            this.Client = client;
            receiver = new TReceiver(client);
        }

        public TResponse(Socket client, TMessage original) {
            this.Original = original;
            this.Client = client;
            receiver = new TReceiver(client);
        }

        public int Length {
            get {
                return this.Data.Length;
            }
        }

        public string DataString {
            get {
                return Encoding.UTF8.GetString(raw.Skip(7).ToArray());
            }
        }

        public string Header {
            get {
                return DataString.Replace("\r\n", "\n").Split('\n')[0];
            }
        }

        public string Name {
            get {
                return RespondedTo.Split(' ')[0];
            }
        }

        public string RespondedTo {
            get {
                return Header.Remove(0, 3).ToUpper().Trim();
            }
        }

        public string Message {
            get {
                return DataString.Remove(0, this.Header.Length).Trim();
            }
        }

        public byte[] Data {
            get {
                return raw;
            }
            set {
                this.Process(value);
            }
        }

        public int Status {
            get {
                return int.Parse(this.Header.Split(' ')[0]);
            }
        }

        public byte[] ByteBase64 {
            get {
                try {
                    return Convert.FromBase64String(this.Message);
                }
                catch {
                    return null;
                }
            }
        }

        public TMessage Original { get; set; }

        public void Process(int status, string message) {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(status + " " + Original.DataString.ToUpper());
            sb.Append(message);

            List<byte> data = new List<byte>();
            data.AddRange(Encoding.UTF8.GetBytes("TCP"));
            data.AddRange(BitConverter.GetBytes(sb.ToString().TrimEnd().Length));
            data.AddRange(Encoding.UTF8.GetBytes(sb.ToString().TrimEnd()));

            this.raw = data.ToArray();
        }

        private byte[] raw;

        public void Process(string data) {
            if (data.Trim().CompareTo("") == 0) {
                data = "202 Accepted";
            }
            this.Process(int.Parse(data.Remove(3, data.Length - 3)), data.Remove(0, 4));
        }

        public void Process(byte[] data) {
            this.raw = data;
        }

        private bool isFirst = true;
        public int Receive() {
            byte[] data;
            int len = receiver.Receive(out data);
            bool needsPass = false;
            if (Encoding.UTF8.GetString(data, 0, 3).StartsWith("ENC")) {
                try {
                    Process(Decrypt(data, Program.Password));
                }
                catch {
                    Program.Password = null;
                    needsPass = true;
                }
            }
            else {
                Process(data);
                needsPass = (Status == 401);
            }
            if (needsPass) {
                if (isFirst) {
                    isFirst = false;
                }
                else {
                    MessageBox.Show(
                        "The encryption was not recognized. The password may be incorrect.",
                        "Password Prompt", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                Pass p = new Pass();
                p.ShowDialog();
                if (Program.Password == null) {
                    receiver.Client.Shutdown(SocketShutdown.Both);
                    Environment.Exit(500);
                }
                TMessage original = new TMessage(receiver.Client);
                original.Process("HELLO");
                original.Send();
                return Receive();
            }
            return len;
        }

        private byte[] Decrypt(byte[] data, string pass) {
            using (Tcpclient.TcpSecure security = new Tcpclient.TcpSecure(pass)) {
                byte[] decrypted = security.Decrypt(data.Skip(7).ToArray());
                byte[] newData = new byte[7 + decrypted.Length];
                decrypted.CopyTo(newData, 7);
                return newData;
            }
        }

        public void Empty() {
            this.raw = null;
        }

        public string ReplaceKeyWords() {
            return this.RemoveSymbols(this.Message).Trim();
        }

        private string RemoveSymbols(string s) {
            return s.Replace("@break", "\r\n").Replace("@pipe", "|").Replace("@quote", "\"").Replace("@at", "@");
        }

        private string AddSymbols(string s) {
            return s.Replace("@", "@at").Replace("\"", "@quote").Replace("|", "@pipe").Replace("\r\n", "@break");
        }
    }
}
