﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;

namespace Tcpclient {
    public class TMessage {

        private byte[] raw;
        private string[] args;

        public byte[] RawData {
            get {
                return raw;
            }
        }

        public byte[] Data {
            get {
                return this.RawData.Skip(7).ToArray();
            }
        }

        private string original;

        public string DataString {
            get {
                return RemoveSymbols(original);
            }
        }

        public string[] Args {
            get {
                return args;
            }
        }

        public string[] ArgsOriginal {
            get {
                return ParseArgs(original, true);
            }
        }

        public int Length {
            get {
                return this.Data.Length;
            }
        }

        public string Name {
            get {
                return DataString.Split(' ')[0];
            }
        }

        public Socket Client { get; set; }

        public TMessage(Socket client) {
            this.Client = client;
        }

        public TMessage() {
        }

        public void Process(byte[] data) {
            this.raw = data;
            this.original = Encoding.UTF8.GetString(this.Data, 0, this.Data.Length);
            this.args = ParseArgs(original, false);
        }

        public void Process(params object[] args) {
            string[] newArgs = new string[args.Length];
            for (int i = 0; i < args.Length; i++) {
                newArgs[i] = AddSymbols(args[i].ToString());
            }
            this.Process(buildString(newArgs));
        }

        private string buildString(string[] args) {
            int i = 1;
            StringBuilder sb = new StringBuilder(args[0]);
            while (i < args.Length) {
                if (args[i].Contains(' ') || args[i].CompareTo("") == 0) {
                    sb.Append(" \"" + args[i] + "\"");
                }
                else {
                    sb.Append(" " + args[i]);
                }
                i++;
            }
            return sb.ToString();
        }

        public void Process(string message) {
            List<byte> data = new List<byte>();
            data.AddRange(Encoding.UTF8.GetBytes("TCP"));
            data.AddRange(BitConverter.GetBytes(message.Length));
            data.AddRange(Encoding.UTF8.GetBytes(message));
            this.Process(data.ToArray());
        }

        private byte[] Encrypt(string message, string pass) {
            using (Tcpclient.TcpSecure tcpSecure = new Tcpclient.TcpSecure(pass)) {
                byte[] encrypted = tcpSecure.Encrypt(Encoding.UTF8.GetBytes(message));
                byte[] data = new byte[7 + encrypted.Length];
                Encoding.UTF8.GetBytes("ENC").CopyTo(data, 0);
                BitConverter.GetBytes(encrypted.Length).CopyTo(data, 3);
                encrypted.CopyTo(data, 7);
                return data;
            }
        }

        public void Send(params object[] cmd) {
            this.Process(cmd);
            this.Send();
        }

        public void Send() {
            byte[] data;
            if (Program.Password.Equals("")) {
                 data = raw;
            }
            else {
                data = Encrypt(DataString, Program.Password);
            }
            Client.Send(data);
        }

        public void Send(string message) {
            this.Process(message);
            this.Send();
        }

        private string[] ParseArgs(string msg, bool keepQuotes) {
            string[] cmd = ParseArguments(msg, keepQuotes);
            for (int i = 0; i <= cmd.GetUpperBound(0); i++) {
                cmd[i] = RemoveSymbols(cmd[i]);
            }
            return cmd;
        }

        private string RemoveSymbols(string s) {
            return s.Replace("@break", "\r\n").Replace("@pipe$", "|").Replace("@quote", "\"").Replace("@at", "@");
        }

        private string AddSymbols(string s) {
            return s.Replace("@", "@at").Replace("\"", "@quote").Replace("|", "@pipe").Replace("\r\n", "@break");
        }

        private string[] ParseArguments(string commandLine) {
            return ParseArguments(commandLine, false);
        }

        private string[] ParseArguments(string commandLine, bool keepQuotes) {
            char[] parmChars = commandLine.ToCharArray();
            bool inQuote = false;
            for (int index = 0; index < parmChars.Length; index++) {
                if (parmChars[index] == '"')
                    inQuote = !inQuote;
                if (!inQuote && parmChars[index] == ' ')
                    parmChars[index] = '\n';
            }
            if (keepQuotes) {
                return (new string(parmChars)).Split('\n');
            }
            else {
                return (new string(parmChars)).Replace("\"", "").Split('\n');
            }
        }
    }
}
