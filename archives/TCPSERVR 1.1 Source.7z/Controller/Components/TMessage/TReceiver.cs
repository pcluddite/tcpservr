﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.IO;
using System.Threading;
using System.Security;

namespace Tcpclient {
    class TReceiver {

        public Socket Client;

        public TReceiver(Socket client) {
            this.Client = client;
        }

        public int Receive(out byte[] data) {
            data = new byte[512];
            int len = Client.Receive(data);

            string check = Encoding.UTF8.GetString(data, 0, len);
            if (len < 7 || (!check.StartsWith("TCP") && !check.StartsWith("ENC"))) {
                return -1;
            }

            List<byte> allData = new List<byte>();
            allData.AddRange(data.Take(len));
            int size = BitConverter.ToInt32(allData.Skip(3).Take(4).ToArray(), 0);

            while (allData.Count - 7 < size) {
                data = new byte[255];
                len = Client.Receive(data);
                allData.AddRange(data.Take(len));
            }
            data = allData.ToArray();
            return data.Length;
        }
    }
}
