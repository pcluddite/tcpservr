﻿using System;
using System.Security;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections;
using System.IO;

namespace Tcpclient {
    public class TcpSecure : IDisposable {

        private Rijndael rij;
        private ICryptoTransform encryptor;
        private ICryptoTransform decryptor;

        public TcpSecure(string key) {
            rij = Rijndael.Create();
            key = key.PadLeft(16, '0');
            encryptor = rij.CreateEncryptor(
                Encoding.UTF8.GetBytes(key),
                Encoding.ASCII.GetBytes("fq7XeXyqkbnmG4Ax")
                );
            decryptor = rij.CreateDecryptor(
                Encoding.UTF8.GetBytes(key),
                Encoding.ASCII.GetBytes("fq7XeXyqkbnmG4Ax")
                );
        }

        public byte[] Encrypt(byte[] data) {
            return encryptor.TransformFinalBlock(data, 0, data.Length);
        }

        public byte[] Decrypt(byte[] data) {
            return decryptor.TransformFinalBlock(data, 0, data.Length);
        }

        public static bool SecureStringEqual(SecureString privateKey, SecureString testString) {
            if (testString == null) {
                throw new ArgumentNullException("s1");
            }
            if (privateKey == null) {
                throw new ArgumentNullException("s2");
            }

            if (testString.Length != privateKey.Length) {
                return false;
            }

            IntPtr ss_bstr1_ptr = IntPtr.Zero;
            IntPtr ss_bstr2_ptr = IntPtr.Zero;

            try {
                ss_bstr1_ptr = Marshal.SecureStringToBSTR(testString);
                ss_bstr2_ptr = Marshal.SecureStringToBSTR(privateKey);

                string str1 = Marshal.PtrToStringBSTR(ss_bstr1_ptr);
                string str2 = Marshal.PtrToStringBSTR(ss_bstr2_ptr);

                return str1.Equals(str2);
            }
            finally {
                if (ss_bstr1_ptr != IntPtr.Zero) {
                    Marshal.ZeroFreeBSTR(ss_bstr1_ptr);
                }

                if (ss_bstr2_ptr != IntPtr.Zero) {
                    Marshal.ZeroFreeBSTR(ss_bstr2_ptr);
                }
            }
        }

        public void Dispose() {
            encryptor.Dispose();
            decryptor.Dispose();
            rij.Clear();
        }
    }
}