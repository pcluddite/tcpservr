﻿using System;
using System.IO;
using System.Linq;
using System.Text;

namespace console {
    public class TMessage {
        public Stream Stream { get; set; } 

        private byte[] raw;
        private string[] cmd;

        public byte[] RawData {
            get {
                return raw;
            }
        }

        public byte[] Data {
            get {
                return this.RawData.Skip(7).ToArray();
            }
        }

        private string original;

        public string DataString {
            get {
                return RemoveSymbols(original);
            }
        }

        public string[] Args {
            get {
                return cmd;
            }
        }

        public int Length {
            get {
                return this.Data.Length;
            }
        }

        public TMessage() {
        }

        public TMessage(Stream client) {
            this.Stream = client;
        }

        public void Process(byte[] data) {
            this.raw = data;
            this.original = Encoding.UTF8.GetString(this.Data, 0, this.Data.Length);
            this.cmd = ParseCmd(original);
        }

        public void Process(string message) {
            byte[] data = new byte[7 + message.Length];
            Encoding.UTF8.GetBytes("TCP").CopyTo(data, 0);
            BitConverter.GetBytes(message.Length).CopyTo(data, 3);
            Encoding.UTF8.GetBytes(message).CopyTo(data, 7);
            this.Process(data);
        }

        public void ProcessEncrypt(string message, string pass) {
            Tcpclient.TcpSecure tcpSecure = new Tcpclient.TcpSecure(pass);
            byte[] encrypted = tcpSecure.Encrypt(Encoding.UTF8.GetBytes(message));
            byte[] data = new byte[7 + encrypted.Length];
            Encoding.UTF8.GetBytes("ENC").CopyTo(data, 0);
            BitConverter.GetBytes(encrypted.Length).CopyTo(data, 3);
            encrypted.CopyTo(data, 7);
            this.Process(data);
        }

        public void Send() {
            Stream.Write(RawData, 0, RawData.Length);
        }

        private string[] ParseCmd(string msg) {
            string[] cmd = ParseArguments(msg);
            for (int i = 0; i <= cmd.GetUpperBound(0); i++) {
                cmd[i] = RemoveSymbols(cmd[i]);
            }
            return cmd;
        }

        private string RemoveSymbols(string s) {
            return s.Replace("@break", "\r\n").Replace("@pipe", "|").Replace("@quote", "\"").Replace("@at", "@");
        }

        private string[] ParseArguments(string commandLine) {
            char[] parmChars = commandLine.ToCharArray();
            bool inQuote = false;
            for (int index = 0; index < parmChars.Length; index++) {
                if (parmChars[index] == '"')
                    inQuote = !inQuote;
                if (!inQuote && parmChars[index] == ' ')
                    parmChars[index] = '\n';
            }
            return (new string(parmChars)).Replace("\"", "").Split('\n');
        }
    }
}
