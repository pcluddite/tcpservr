﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;

namespace console {
    public class TResponse {

        public Stream Client { get; set; }

        public string DataString {
            get {
                return Encoding.UTF8.GetString(this.Data.Skip(7).ToArray());
            }
        }

        public byte[] Data {
            get {
                return raw;
            }
        }

        public int Status { get; set; }
        public TMessage TMessage { get; set; }

        public string Header {
            get {
                return DataString.Replace("\r\n", "\n").Split('\n')[0];
            }
        }

        public string Message {
            get {
                return this.DataString.Remove(0, this.Header.Length).Trim();
            }
        }

        private byte[] raw;

        public TResponse() {
        }

        public TResponse(TMessage original) {
            this.TMessage = original;
        }

        public TResponse(Stream client, TMessage original) {
            this.TMessage = original;
            //secureStream = new SslStream(client.GetStream());
            //secureStream.AuthenticateAsClient((client.Client.RemoteEndPoint as IPEndPoint).Address.ToString());
            this.Client = client;
        }

        public TResponse(string data, TMessage original, Stream client) {
            this.TMessage = original;
            //secureStream = new SslStream(client.GetStream());
            this.Client = client;
            this.Process(data);
        }

        public void Process(byte[] data) {
            this.raw = data;
        }

        public void Process(string data) {
            this.Status = int.Parse(data.Remove(3, data.Length - 3));
            string header = data.Replace("\r\n", "\n").Split('\n')[0];
            this.Process(this.Status, data.Remove(0, header.Length).TrimStart());
        }

        public void Process(int status, string message) {
            this.Status = status;

            string text = (this.Header + "\r\n" + message).TrimEnd();

            byte[] data = new byte[7 + text.Length];
            Encoding.UTF8.GetBytes("TCP").CopyTo(data, 0);
            BitConverter.GetBytes(text.Length).CopyTo(data, 3);
            Encoding.UTF8.GetBytes(text).CopyTo(data, 7);

            this.raw = data.ToArray();
        }

        public int Receive(int timeout, string pass) {
            byte[] data = new byte[255];
            Client.ReadTimeout = timeout;
            List<byte> allData = new List<byte>();
            int bytes = Client.Read(data, 0, data.Length);
            allData.AddRange(data.Take(bytes));
            bool encrypted = Encoding.UTF8.GetString(data, 0, 3).Equals("ENC");
            int size = BitConverter.ToInt32(data.Skip(3).Take(4).ToArray(), 0);
            while (allData.Count < size + 7) {
                data = new byte[255];
                bytes = Client.Read(data, 0, data.Length);
                allData.AddRange(data.Take(bytes));
            }
            if (encrypted) {
                ProcessEncrypted(allData.ToArray(), pass);
            }
            else {
                Process(allData.ToArray());
            }
            return allData.Count;
        }

        public void ProcessEncrypted(byte[] data, string pass) {
            using (Tcpclient.TcpSecure security = new Tcpclient.TcpSecure(pass)) {
                byte[] decrypted = security.Decrypt(data.Skip(7).ToArray());
                byte[] newData = new byte[7 + decrypted.Length];
                decrypted.CopyTo(newData, 7);
                Process(newData);
            }
        }
    }
}
