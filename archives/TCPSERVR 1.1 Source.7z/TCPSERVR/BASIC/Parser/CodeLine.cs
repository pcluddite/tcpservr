﻿using System.Collections.Generic;
using System.Text;
using System;

namespace Tcpservr.BASIC {

    public class CodeLine {
        protected string line;

        /// <summary>
        /// A line of TBASIC code
        /// </summary>
        /// <param name="line">The text of the line</param>
        public CodeLine(string line) {
            this.Text = line.Trim();
        }

        /// <summary>
        /// Gets or sets the line identification
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Gets or sets the text of a line
        /// </summary>
        public string Text { 
            get { 
                return line;
            }
            set {
                line = value;
            }
        }

        /// <summary>
        /// Gets or sets the current block type
        /// </summary>
        public BlockType CurrentBlock { get; set; }

        /// <summary>
        /// Retrieves the name of the statement of function for the given line
        /// </summary>
        public string Name {
            get {
                int paren = line.IndexOf('('), space = line.IndexOf(' ');
                if (paren == -1) {
                    return line.GetFirstWord();
                }
                else if (space == -1) {
                    return line.Split('(')[0];
                }
                else {
                    return paren < space ? line.Split('(')[0] : line.GetFirstWord();
                }
            }
        }
    }
}
