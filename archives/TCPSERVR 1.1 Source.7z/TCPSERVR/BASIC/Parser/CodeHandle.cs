﻿
namespace Tcpservr.BASIC {
    public class CodeHandle {
        private bool isBlock;
        private CodeLine line;
        private CodeBlock block;

        /// <summary>
        /// Gets whether the handle is a CodeBlock
        /// </summary>
        public bool IsCodeBlock { 
            get { 
                return isBlock;
            }
        }

        /// <summary>
        /// The code object that is being handled
        /// </summary>
        public object Code {
            get {
                if (IsCodeBlock) {
                    return block;
                }
                else {
                    return line;
                }
            }
        }

        /// <summary>
        /// The text or header text of the CodeLine or CodeBlock
        /// </summary>
        public string Text {
            get {
                if (IsCodeBlock) {
                    return block.Header.Text;
                }
                else {
                    return line.Text;
                }
            }
        }

        /// <summary>
        /// The name or header name of the CodeLine or CodeBlock
        /// </summary>
        public string Name {
            get {
                if (IsCodeBlock) {
                    return block.Header.Name;
                }
                else {
                    return line.Name;
                }
            }
        }

        /// <summary>
        /// A handle for a given line or block of code
        /// </summary>
        /// <param name="line">The code line for the handle</param>
        public CodeHandle(CodeLine line, int lineNumber) {
            this.line = line;
            this.line.ID = lineNumber;
            this.ID = lineNumber;
            isBlock = false;
        }

        /// <summary>
        /// A handle for a given line or block of code
        /// </summary>
        /// <param name="line">The code block for the handle</param>
        public CodeHandle(CodeBlock block, int lineNumber) {
            this.block = block;
            this.block.Header.ID = lineNumber;
            this.ID = lineNumber;
            isBlock = true;
        }

        /// <summary>
        /// The main CodeLine
        /// </summary>
        public CodeLine Header {
            get {
                if (isBlock) {
                    return block.Header;
                }
                else {
                    return line;
                }
            }
        }

        /// <summary>
        /// Gets or sets the line identification number
        /// </summary>
        public int ID { get; set; }
    }
}
