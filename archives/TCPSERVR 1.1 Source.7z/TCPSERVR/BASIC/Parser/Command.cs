﻿using System.Collections.Generic;
using System.Text;

namespace Tcpservr.BASIC {
    public class Command : CodeLine {
        protected string[] args;
        /// <summary>
        /// Gets or sets the collection of variables that are used in parsing the command
        /// </summary>
        public DataManager Variables { get; set; }

        /// <summary>
        /// A TBASIC command
        /// </summary>
        /// <param name="line">The line of code to parse</param>
        public Command(string line)
            : base(line) {
            this.Text = line;
        }

        /// <summary>
        /// A TBASIC command
        /// </summary>
        /// <param name="line">The line of code to parse</param>
        /// <param name="vars">A collection of variables that are used in parsing the command</param>
        public Command(string line, DataManager vars)
            : base(line) {
            this.Variables = vars;
            this.Text = line;
        }

        /// <summary>
        /// Gets or sets the text of the command
        /// </summary>
        public new string Text {
            get {
                return line;
            }
            set {
                line = value;
                args = ParseCommand(value, false);
            }
        }

        /// <summary>
        /// Gets any arguments of the command
        /// </summary>
        public string[] Arguments {
            get {
                return args;
            }
        }

        /// <summary>
        /// Gets any arguments of the command with any variables in the dictionary assigned
        /// </summary>
        public string[] FormattedArgs {
            get {
                return format(args, this.Variables);
            }
        }

        /// <summary>
        /// Gets the text of the command with any variables in the dictionary assigned
        /// </summary>
        public string FormattedText {
            get {
                return buildCommand(FormattedArgs);
            }
        }

        /// <summary>
        /// Gets the text of the command without being formatted as a proper command. Quotes are not included. Each argument is appended to each other by a space.
        /// </summary>
        public string FormattedString {
            get {
                return buildString(FormattedArgs);
            }
        }

        protected string[] ParseCommand(string line, bool keepQuotes) {
            char[] parmChars = line.Trim().ToCharArray();
            bool inQuote = false;
            for (int index = 0; index < parmChars.Length; index++) {
                if (parmChars[index] == '"') {
                    inQuote = !inQuote;
                }
                if (!inQuote && parmChars[index] == ' ') {
                    parmChars[index] = '\n';
                }
            }
            if (keepQuotes) {
                return (new string(parmChars)).Split('\n');
            }
            else {
                return (new string(parmChars)).Replace("\"", "").Split('\n');
            }
        }

        /// <summary>
        /// Parses the arguments of the command, keeping the quotes in the array
        /// </summary>
        /// <returns>The parsed command</returns>
        public string[] ParseKeepQuotes() {
            return ParseCommand(this.line, true);
        }

        protected string[] format(string[] args, DataManager vars) {
            string[] newArgs = new string[args.Length];
            for (int i = 0; i < args.Length; i++) {
                newArgs[i] = doReplace(args[i], vars);
            }
            return newArgs;
        }

        private string doReplace(string s, DataManager vars) {
            if (vars == null) {
                return s;
            }
            return vars.ReplaceObjects(s);
        }

        protected string buildCommand(string[] args) {
            StringBuilder sb = new StringBuilder(args[0]);
            for (int i = 1; i < args.Length; i++) {
                if (args[i].Contains(" ") || args[i].Equals("")) {
                    sb.Append(" \"" + args[i] + "\"");
                }
                else {
                    sb.Append(" " + args[i]);
                }
            }
            return sb.ToString();
        }

        protected string buildString(string[] args) {
            StringBuilder sb = new StringBuilder(args[0]);
            for (int i = 1; i < args.Length; i++) {
                sb.Append(" " + args[i]);
            }
            return sb.ToString();
        }

        /// <summary>
        /// Converts the command into a TCPSERVR.Message using the FormattedArgs
        /// </summary>
        /// <returns>The TCPSERVR.Message converted</returns>
        public TMessage ToMessage() {
            TMessage msg = new TMessage();
            msg.Process(FormattedArgs);
            return msg;
        }
    }
}
