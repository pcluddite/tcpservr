﻿using System;
using System.Collections.Generic;

namespace Tcpservr.BASIC {
    public class CodeBlock {

        /// <summary>
        /// A block of TBASIC code
        /// </summary>
        /// <param name="blockType">The type of block to create</param>
        /// <param name="startLine">The line of code that contains the keyword</param>
        /// <param name="code">All lines of code</param>
        public CodeBlock(BlockType blockType, int startLine, CodeLineArray code) {
            this.CodeLines = new CodeLineArray(GetBlock(startLine, blockType, code));
            this.Type = blockType;
            if (HasElseBlock) {
                this.ElseLines = new CodeLineArray(GetBlock(startLine + this.CodeLines.Length + 1, BlockType.If, code));
            }
        }

        private string[] GetBlock(int start, BlockType blockType, CodeLineArray code) {
            // Retrieve proper keywords
            string startword = GetStartword(blockType);
            string endword = GetEndword(startword);
            string elseword = null;
            if (blockType == BlockType.If) {
                elseword = "ELSE";
            }

            // Create a list which will store all of the lines and add the first line to it
            List<string> lines = new List<string>();
            /* The offset is how many endwords it has to look for.
               The elseOffset is the same, only for elseWords 
               When the offset is 0, the program has loaded the block. */
            int offset = 1, lineNumber = start + 1, elseOffset = 1;
            while (offset != 0) {
                // If the line number exceeds the length of the code, throw an exception.
                if (lineNumber >= code.Length) {
                    throw new Exception("Could not find closing " + endword + " associated with " + 
                                        startword + ".");
                }
                // The line needs to be case insensitive
                CodeLine line = new CodeLine(code.Lines[lineNumber].Text.ToUpper().Trim());
                // If the line starts with the keyword, the offset needs to be increased
                if (line.Name.Equals(startword)) {
                    offset++;
                    elseOffset++;
                }
                // If the header is not null (i.e. This is the else block), then
                // the offset needs to be adjusted
                if (Header != null && line.Text.Equals(elseword)) {
                    offset++;
                }
                if (offset != 0) {
                    // If the line starts with the elseWord, decrease the offset
                    if (elseword != null && line.Text.Equals(elseword)) {
                        elseOffset--;
                        // If the elseOffset is 0, the first block has been found
                        // Check if the header is null to make sure that the first block has not been set.
                        if (elseOffset == 0 && Header == null) {
                            break;
                        }
                    }
                    // If the line starts with the endWord, decrease the offset
                    if (line.Text.Equals(endword)) {
                        offset--;
                        // If the offset is 0, break the loop.
                        if (offset == 0) {
                            break;
                        }
                    }
                    // Add the line of code to the block (not the lowered line)
                    lines.Add(code.Lines[lineNumber].Text);
                }
                // The line number is incremented by 1
                lineNumber++;
            }
            // If the header is null, set the header
            if (Header == null) {
                // If the elseOffset is 0, then there is an else block
                this.HasElseBlock = (elseOffset == 0);
                this.Header = code[start];
            }
            this.Footer = code[lineNumber];
            return lines.ToArray();
        }

        /// <summary>
        /// Gets or sets the line of code that begins the block
        /// </summary>
        public CodeLine Header { get; set; }

        /// <summary>
        /// Gets or sets the line of code that ends the block
        /// </summary>
        public CodeLine Footer { get; set; }

        /// <summary>
        /// Gets or sets all of the code lines of the main portion of the block
        /// </summary>
        public CodeLineArray CodeLines { get; set; }

        /// <summary>
        /// Gets or sets all of the code lines of the ELSE portion of the block
        /// </summary>
        public CodeLineArray ElseLines { get; set; }

        /// <summary>
        /// Gets or sets if an ELSE block is present
        /// </summary>
        public bool HasElseBlock { get; set; }

        /// <summary>
        /// Gets the number of code lines in the block
        /// </summary>
        public int Length {
            get {
                if (!HasElseBlock) {
                    // There are 2 keywords, so the length is actually 2 more
                    return this.CodeLines.Length + 2;
                }
                else {
                    // There are 3 keywords, so the length is actually 3 more
                    return this.CodeLines.Length + this.ElseLines.Length + 3;
                }
            }
        }

        /// <summary>
        /// Gets or sets the BlockType
        /// </summary>
        public BlockType Type { get; set; }

        /// <summary>
        /// Attempts to parse a section of code as a CodeBlock
        /// </summary>
        /// <param name="word">The keyword that begins the block</param>
        /// <param name="start">The line of code that contains the keyword</param>
        /// <param name="array">All lines of code</param>
        /// <param name="block">Stores the resulting block of code. This will be null if parsing failed.</param>
        /// <returns>If the CodeBlock is parsed successfully, it will return "true", otherwise "false"</returns>
        public static bool TryParse(string word, int start, CodeLineArray array, out CodeBlock block) {
            if (IsKeyword(word)) {
                if (word.ToUpper().Equals("IF")) {
                    block = new CodeBlock(BlockType.If, start, array);
                }
                else {
                    block = new CodeBlock(GetBlockType(word), start, array);
                }
            }
            else {
                block = null;
            }
            return (block != null);
        }

        /// <summary>
        /// Determines whether or not a string is a valid TBASIC keyword for a CodeBlock header
        /// </summary>
        /// <param name="word">The string to test</param>
        /// <returns>Returns "true" if it is a keyword, otherwise "false"</returns>
        public static bool IsKeyword(string word) {
            word = word.ToUpper();
            return word.Equals("IF") || word.Equals("WHILE") || word.Equals("DO") ||
                word.Equals("FOR") || word.Equals("FUNCTION") || word.Equals("SELECT");
        }

        /// <summary>
        /// Gets the corresponding keyword for a CodeBlock footer for a given header keyword
        /// </summary>
        /// <param name="keyword">The keyword for the code block header</param>
        /// <returns>Returns the corresponding end word. This will be null if the start word is not found.</returns>
        public static string GetEndword(string keyword) {
            switch (keyword.ToUpper()) {
                case "IF":
                case "ELSE":
                    return "END IF";
                case "WHILE":
                    return "WEND";
                case "DO":
                    return "LOOP";
                case "FOR":
                    return "NEXT";
                case "FUNCTION":
                    return "END FUNCTION";
                case "SELECT":
                    return "END SELECT";
                default:
                    return null;
            }
        }

        /// <summary>
        /// Gets the start word for a block
        /// </summary>
        /// <param name="type">The block type</param>
        /// <returns></returns>
        public static string GetStartword(BlockType type) {
            switch (type) {
                case BlockType.If:
                    return "IF";
                case BlockType.Do:
                    return "DO";
                case BlockType.For:
                    return "FOR";
                case BlockType.Function:
                    return "FUNCTION";
                case BlockType.While:
                    return "WHILE";
                case BlockType.Else:
                    return "ELSE";
                case BlockType.Select:
                    return "SELECT";
                default:
                    return null;
            }
        }

        /// <summary>
        /// Gets the start word for a block
        /// </summary>
        /// <param name="type">The block type</param>
        /// <returns></returns>
        public static string GetStartword(string type) {
            switch (type.ToUpper()) {
                case "END IF":
                    return "IF";
                case "LOOP":
                    return "DO";
                case "NEXT":
                    return "FOR";
                case "END FUNCTION":
                    return "FUNCTION";
                case "WHILE":
                    return "WHILE";
                case "ELSE":
                    return "IF";
                default:
                    return null;
            }
        }

        /// <summary>
        /// Gets the BlockType from a given block name
        /// </summary>
        /// <param name="type">The block name</param>
        /// <returns></returns>
        public static BlockType GetBlockType(string name) {
            switch (name.ToUpper()) {
                case "WHILE":
                    return BlockType.While;
                case "IF":
                    return BlockType.If;
                case "DO":
                    return BlockType.Do;
                case "FOR":
                    return BlockType.For;
                case "FUNCTION":
                    return BlockType.Function;
                case "SELECT":
                    return BlockType.Select;
                default:
                    return BlockType.None;
            }
        }
    }

    public enum BlockType {
        Main, For, While, Do, Function, If, Else, Select, None
    }
}
