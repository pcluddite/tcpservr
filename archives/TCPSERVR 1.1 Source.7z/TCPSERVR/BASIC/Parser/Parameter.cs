﻿using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;

namespace Tcpservr.BASIC {
    public class Parameter {

        /// <summary>
        /// An individual parameter of a function to manage
        /// </summary>
        /// <param name="text">The parameter text</param>
        public Parameter(string text) {
            this.text = text.Trim();
            this.QuotesRemoved = false;
        }

        /// <summary>
        /// An individual parameter of a function to manage
        /// </summary>
        /// <param name="text">The parameter text</param>
        /// /// <param name="text">The parameter type</param>
        public Parameter(string text, ParamType type) {
            this.text = text.Trim();
            thisType = type;
            this.QuotesRemoved = false;
        }

        string text;

        /// <summary>
        /// Gets or sets the text of the parameter
        /// </summary>
        public string Text {
            get {
                return text;
            }
            set {
                text = value;
                brokenString = null;
                thisType = GetParamType();
            }
        }

        ParamType thisType = ParamType.None;

        /// <summary>
        /// Gets or sets the Parameter type (Setting it will override the automatically derived type)
        /// </summary>
        public ParamType Type {
            get {
                if (thisType == ParamType.None) {
                    return thisType = GetParamType();
                }
                else {
                    return thisType;
                }
            }
            set {
                thisType = value;
            }
        }

        /// <summary>
        /// Gets or sets whether or not quotes have been removed. This is not set by this class and is only for outside parsing purposes.
        /// </summary>
        public bool QuotesRemoved { get; set; }

        private string RemoveParentheses(string text) {
            if (text.StartsWith("(") && text.EndsWith(")")) {
                text = text.Remove(0, 1);
                text = text.Remove(text.Length - 1, 1);
            }
            return text;
        }

        private bool isInQuotes() {
            return Text.StartsWith("\"") && Text.EndsWith("\"");
        }

        private bool isInParentheses() {
            return Text.StartsWith("(") && Text.EndsWith(")");
        }

        private ParamType GetParamType() {
            if (text.Equals("")) {
                return ParamType.Empty;
            }
            Function fTemp;
            if (Function.TryParse(text, out fTemp)) {
                return ParamType.Function;
            }
            double dTemp;
            if (double.TryParse(text, out dTemp)) {
                return ParamType.Double;
            }
            if (IsMath()) {
                return ParamType.Math;
            }
            if (BreakString(text).Length > 1) {
                return ParamType.Broken;
            }
            if (isInQuotes()) {
                return ParamType.String;
            }
            if (text.EndsWith("$") || text.StartsWith("@") || TBASIC.DimensionEx.Match(text).Success) {
                return ParamType.Variable;
            }
            return ParamType.Error;
        }

        private bool IsMath() {
            if (BeginsWithOpr(text) || EndsWithOpr(text)) {
                return false;
            }
            string temp = TBASIC.VariableEx.Replace(text, "0");      // All variables will be seen as integers
            if (temp.Equals("0")) {
                return false;
            }
            temp = TBASIC.FunctionEx.Replace(temp, "0"); // All functions will be seen as integers
            if (temp.Equals("0")) {
                return false;
            }
            foreach (char c in temp.ToCharArray()) {
                if (!char.IsDigit(c) && !IsMathOpr(c)) {
                    return false;
                }
            }
            return true;
        }

        private readonly char[] MATH_CHARS = { '%', '(', ')', '.', '+', '/', '*', '-' };

        private bool IsMathOpr(char c) {
            return MATH_CHARS.Contains(c);
        }

        private bool BeginsWithOpr(string s) {
            return MATH_CHARS.Contains(s[0]);
        }

        private bool EndsWithOpr(string s) {
            return MATH_CHARS.Contains(s[s.Length - 1]);
        }

        /// <summary>
        /// Breaks up a parameter into more Parameters if the Parameter type is ParamType.Broken
        /// </summary>
        /// <returns>An array of all Parameters in a Broken Parameter</returns>
        public Parameter[] BreakParameter() {
            return BreakString(this.Text);
        }

        private Parameter[] brokenString = null;

        private Parameter[] BreakString(string line) {
            if (brokenString != null) {
                return brokenString;
            }
            StringBuilder currentParm = new StringBuilder();
            List<Parameter> parms = new List<Parameter>(); // Initialize a list of parameters
            int offset = 0; // How many parentheses are expected
            bool inQuotes = false;
            foreach (char c in line.ToCharArray()) {
                if (c == '"') {
                    inQuotes = !inQuotes;
                }
                if (!inQuotes) { // Ignore if in quotes
                    if (c == '(') {
                        offset++;
                    }
                    if (c == ')') {
                        offset--;
                    }
                    if (offset == 0 && isDelimeter(c)) { // No parentheses are expected, this is the current parameter
                        parms.Add(new Parameter(RemoveParentheses(currentParm.ToString().Trim()).Trim()));
                        currentParm = new StringBuilder();
                        continue;
                    }
                }
                currentParm.Append(c);
            }
            parms.Add(new Parameter(RemoveParentheses(currentParm.ToString().Trim()).Trim()));
            return brokenString = parms.ToArray();
        }

        private string delim = "+-/*%";
        private bool isDelimeter(char c) {
            return delim.IndexOf(c) > -1;
        }

        private bool isDouble(string d) {
            double dum;
            return double.TryParse(d, out dum);
        }

        public override string ToString() {
            return text;
        }
    }

    public enum ParamType {
        String, Variable, Double, Math, Empty, None,
        Function, Broken, Error
    }
}
