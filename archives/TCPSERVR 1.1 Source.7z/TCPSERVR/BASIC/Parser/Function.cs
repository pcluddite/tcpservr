﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tcpservr.BASIC {
    public class Function {
        private string text;
        private Parameter[] args;

        /// <summary>
        /// A TBASIC function
        /// </summary>
        /// <param name="text">The text of the function</param>
        public Function(string text) {
            if (!isPairedWithName(text)) {
                throw new Exception("Invalid function");
            }
            this.Text = text;
        }

        /// <summary>
        /// Gets or sets the current text of the function
        /// </summary>
        public string Text {
            get {
                return text;
            }
            set {
                text = value;
                args = ParseFunction(value); // The new text needs to be parsed
            }
        }

        /// <summary>
        /// Gets any parameters of the function
        /// </summary>
        public Parameter[] Parameters {
            get {
                return args;
            }
        }

        private Parameter[] ParseFunction(string text) {
            if (!text.Trim().EndsWith(")")) {
                throw new Exception("Could not find closing ')'");
            }
            string name = this.Name;
            text = text.Remove(0, name.Length).Trim().Remove(0,1); // Removes the name, plus the beginning parenthesis
            char[] allChars = text.ToCharArray(); // All characters in the text to parse
            List<Parameter> parameters = new List<Parameter>(); // All parameters of the function
            StringBuilder currentParam = new StringBuilder(); // The current parameter being parsed
            int offset = 1, // How many end parentheses the parser is expecting
                index = 0; // The current character index
            bool inQuote = false;
            while (offset != 0) {
                if (index >= allChars.Length) {
                    throw new Exception("Could not find closing ')'");
                }
                if (!inQuote) { // Text inside quotes should be ignored
                    if (allChars[index] == ')') {
                        offset--;
                    }
                    if (allChars[index] == '(') {
                        offset++;
                    }
                    if (offset == 1 && allChars[index] == ',') { // One parenthesis is expected, the parameter is for this function
                        parameters.Add(new Parameter(currentParam.ToString())); // Add new parameter
                        currentParam = new StringBuilder(); // Initialize new StringBuilder
                        index++;
                        continue;
                    }
                    if (offset == 0) { // The final parenthesis was found - end the search
                        parameters.Add(new Parameter(currentParam.ToString()));
                        break;
                    }
                }
                if (allChars[index] == '"') {
                    inQuote = !inQuote;
                }
                currentParam.Append(allChars[index]);
                index++;
            }
            if (parameters.Count == 1 && parameters[0].Text.Trim().Equals("")) {
                parameters = new List<Parameter>();
            }
            return parameters.ToArray();
        }

        private bool isPairedWithName(string text) {
            text = text.Trim();
            while (text.Contains(" (")) {
                text = text.Replace(" (", "(");
            }
            return !text.StartsWith("(");
        }

        /// <summary>
        /// Gets the name of the function
        /// </summary>
        public string Name {
            get {
                return GetName(text);
            }
        }

        private string GetName(string text) {
            // It is not a function if there are no parentheses
            if (!text.Contains("(")) {
                throw new Exception(text + " is not a function.");
            }

            // The name should end at '(' and white space should be removed
            string tempName = text.Split('(')[0].Trim();
            char[] allChars = tempName.ToCharArray();
            StringBuilder name = new StringBuilder();
            for (int i = 0; i < allChars.Length; i++) {
                // The name cannot contain any symbols or spaces
                if (!char.IsLetterOrDigit(allChars[i]) && allChars[i] != '_') {
                    throw new Exception("Invalid character in function name - '" + allChars[i] + "'");
                }
                name.Append(allChars[i]);
            }

            if (name.Length == 0) {
                throw new Exception("The function has no name");
            }

            return name.ToString();
        }

        /// <summary>
        /// Attempts to parse a function
        /// </summary>
        /// <param name="text">The text of the function</param>
        /// <param name="func">The name of the variable to store the function. This will be set to null if the function cannot be parsed.</param>
        /// <returns>Returns "true" if the function was parsed, otherwise "false"</returns>
        public static bool TryParse(string text, out Function func) {
            try {
                func = new Function(text);
                return true;
            }
            catch {
                func = null;
                return false;
            }
        }

        public override string ToString() {
            return Text;
        }
    }
}
