﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tcpservr.BASIC {
    public class CodeLineArray {
        CodeLine[] allLines;

        public CodeLine[] Lines { 
            get { 
                return allLines; 
            } 
        }

        /// <summary>
        /// An array of CodeLines
        /// </summary>
        /// <param name="code">The code as a string. This will be split into separate lines by \r\n or \n</param>
        public CodeLineArray(string code) {
            Load(code.Replace("\r\n", "\n").Split('\n'));
        }

        /// <summary>
        /// An array of CodeLines
        /// </summary>
        /// <param name="code">The code as a string array. Each value in the array is a line of code.</param>
        public CodeLineArray(string[] code) {
            Load(code);
        }

        private void Load(string[] code) {
            string[] lineArray = code;
            allLines = new CodeLine[lineArray.Length];
            for (int i = 0; i < lineArray.Length; i++) {
                allLines[i] = new CodeLine(lineArray[i].Trim());
            }
        }

        /// <summary>
        /// Gets the number of code lines in this array
        /// </summary>
        public int Length {
            get {
                return this.Lines.Length;
            }
        }

        /// <summary>
        /// Gets a specific line of code at a given index
        /// </summary>
        /// <param name="line">The line number</param>
        /// <returns></returns>
        public CodeLine this[int line] {
            get {
                return this.Lines[line];
            }
        }

        /// <summary>
        /// Returns an IEnumerator for the array
        /// </summary>
        /// <returns></returns>
        public IEnumerator GetEnumerator() {
            return allLines.GetEnumerator();
        }
    }
}
