﻿using System.Collections.Generic;

namespace Tcpservr.BASIC {
    public class Code {
        private List<CodeHandle> handles = new List<CodeHandle>();

        /// <summary>
        /// Manage a set of TBASIC code statements
        /// </summary>
        /// <param name="array">All lines of code</param>
        /// <param name="processFuncs">Whether or not FUNC blocks are allowed</param>
        /// /// <param name="type">The type of block the code is currently in</param>
        public Code(CodeLineArray array, int startLine, BlockType type) {
            Load(array, startLine, type);
        }

        private void Load(CodeLineArray lines, int currentLine, BlockType currentBlock) {
            bool processFuncs = (currentBlock == BlockType.Main);
            List<CodeBlock> funcs = new List<CodeBlock>();
            for (int i = 0; i < lines.Length; i++) {
                CodeBlock block;
                string keyword = lines[i].Name.ToUpper();
                if (CodeBlock.TryParse(keyword, i, lines, out block)) {
                    if (processFuncs && keyword.Equals("FUNCTION")) {
                        block.Header.ID = currentLine;
                        funcs.Add(block);
                    }
                    else {
                        handles.Add(new CodeHandle(block, currentLine));
                    }
                    i += block.Length - 1;
                }
                else {
                    handles.Add(new CodeHandle(lines[i], currentLine));
                }
                currentLine++;
            }
            if (funcs.Count == 0) {
                functions = null;
            }
            else {
                functions = funcs.ToArray();
            }
        }

        private CodeBlock[] functions;

        /// <summary>
        /// Gets the parsed functions that exist within the code
        /// </summary>
        public CodeBlock[] Functions {
            get {
                return functions;
            }
        }

        /// <summary>
        /// Gets the parsed handles of each line of code
        /// </summary>
        public CodeHandle[] CodeHandles { 
            get { 
                return handles.ToArray(); 
            } 
        }
    }
}