﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Tcpservr.BASIC.Library {
    public class BooleanManager {
        private Interpreter inter;

        public BooleanManager(Interpreter interpreter) {
            this.inter = interpreter;
        }

        public Dictionary<string, FunctionMethod> GetFuncLibrary() {
            Dictionary<string, FunctionMethod> lib = new Dictionary<string, FunctionMethod>();
            lib.Add("not", new FunctionMethod(Not));
            lib.Add("evalbool", new FunctionMethod(EvalBool));
            return lib;
        }

        public string EvalBool(TMessage line) {
            if (line.ArgsOriginal.Length != 2) { return "400 Bad Request"; }
            BooleanManager bm = new BooleanManager(this.inter);
            return "200 " + bm.GetBoolValue(new Command("if " + line.Args[1]));
        }

        public string Not(TMessage line) {
            if (line.ArgsOriginal.Length != 2) { return "400 Bad Request"; }
            BooleanManager bm = new BooleanManager(this.inter);
            return "200 " + !bm.GetBoolValue(new Command("if " + line.Args[1]));
        }

        public Dictionary<string, BlockMethod> GetBlockLibrary() {
            Dictionary<string, BlockMethod> lib = new Dictionary<string, BlockMethod>();
            lib.Add("if", new BlockMethod(IF));
            lib.Add("while", new BlockMethod(WHILE));
            lib.Add("do", new BlockMethod(DO));
            return lib;
        }

        public void IF(CodeBlock b) {
            Command header = new Command(b.Header.Text, inter.DataManager);
            if (header.Arguments.Length < 3) {
                throw new Exception("The statement was poorly formatted");
            }
            if (!header.Arguments[header.Arguments.Length - 1].ToUpper().Equals("THEN")) {
                throw new Exception("The keyword THEN is used at the end of an IF statement");
            }
            if (GetBoolValue(header)) {
                inter.TBASIC.Process(new Code(b.CodeLines, b.Header.ID + 1, BlockType.If));
            }
            else if (b.HasElseBlock) {
                inter.TBASIC.Process(new Code(b.ElseLines, b.Header.ID + b.CodeLines.Length + 1, BlockType.Else));
            }
        }

        public void WHILE(CodeBlock b) {
            Command line = new Command(b.Header.Text, inter.DataManager);

            Code c = new Code(b.CodeLines, b.Header.ID + 1, BlockType.While);

            while (GetBoolValue(line)) {
                inter.TBASIC.Process(c);
                if (inter.TBASIC.ExitRequest || inter.TBASIC.BreakRequest) {
                    inter.TBASIC.BreakRequest = false;
                    break;
                }
            }
        }

        public void FOR(CodeBlock b) {
            Command line = new Command(b.Header.Text, inter.DataManager);
            string[] args = line.Arguments;
            if (args.Length == 6) {
                args = new string[] { args[0], args[1], args[2], args[3], args[4], args[5], "STEP", "1" };
            }
            if (args.Length != 8 || !args[2].Equals("=") || !args[4].ToLower().Equals("to") || !args[6].ToLower().Equals("step")) {
                throw new Exception("The FOR loop was formatted incorrectly");
            }

            //int start, to, step;

            Code c = new Code(b.CodeLines, b.Header.ID + 1, BlockType.For);
            while (GetBoolValue(line)) {
                inter.TBASIC.Process(c);
                if (inter.TBASIC.ExitRequest || inter.TBASIC.BreakRequest) {
                    inter.TBASIC.BreakRequest = false;
                    break;
                }
            }
        }

        public void DO(CodeBlock b) {
            Command header = new Command(b.Header.Text, inter.DataManager);
            
            Code c = new Code(b.CodeLines, b.Header.ID + 1, BlockType.Do);
            string conditionString = header.Text.Remove(0, 2).TrimStart();
            if (conditionString.ToUpper().StartsWith("UNTIL")) {
                conditionString = conditionString.Remove(0, 5).TrimStart();
                conditionString = "NOT (" + conditionString + ")";
            }
            else if (conditionString.ToUpper().StartsWith("WHILE")) {
                conditionString = conditionString.Remove(0, 5).TrimStart();
            }
            else {
                throw new Exception("Unknown logic test - '" + conditionString + "'");
            }
            Command condition;
            do {
                condition = new Command("do " + conditionString, inter.DataManager);
                inter.TBASIC.Process(c);
                if (inter.TBASIC.ExitRequest || inter.TBASIC.BreakRequest) {
                    inter.TBASIC.BreakRequest = false;
                    break;
                }
            }
            while (GetBoolValue(condition));
        }

        public bool GetBoolValue(Command line) {
            List<string> newArgs = new List<string>();

            for (int i = 1; i < line.Arguments.Length; i++) {
                string arg = line.Arguments[i].ToLower();
                switch (arg) {
                    case "not":
                        newArgs.Add("NOT");
                        break;
                    case "and":
                        newArgs.Add("AND");
                        break;
                    case "or":
                        newArgs.Add("OR");
                        break;
                    case "then":
                        break;
                    default:
                        newArgs.Add(line.Arguments[i]);
                        break;
                }
            }

            string expression = buildString(newArgs.ToArray());

            foreach (string s in Regex.Split(expression, " AND | OR ")) {
                string condition = s.Trim();
                if (condition.Contains("NOT")) {
                    condition = condition.Replace("NOT", "").Trim();
                }
                condition = condition.RemoveParentheses().Trim();
                Command fLine = new Command(condition, inter.DataManager);
                if (fLine.Arguments.Length >= 3) {
                    expression = expression.Replace(condition,
                        GetBoolValue(fLine.FormattedArgs[0], fLine.Arguments[1], fLine.FormattedArgs[2]).ToString());
                }
                else if (fLine.Arguments.Length == 1) {
                    expression = expression.Replace(condition,
                        GetBoolValue(fLine.FormattedArgs[0]).ToString());
                }
                else {
                    throw new Exception("Invalid condition - '" + condition + "'");
                }
            }
            return CalculateBool(expression);
        }

        private bool CalculateBool(string expression) {
            expression = expression.ToLower().RemoveDoubleSpaces().Trim();
            bool[] allReplaces = new bool[14];
            allReplaces[0] = true;
            while (expression.GetFirstWord().Length != 1 && allReplaces.OneIsTrue()) {
                #region NOT
                allReplaces[0] = expression.TryReplace("not true", "false", out expression);
                allReplaces[1] = expression.TryReplace("not false", "true", out expression);
                #endregion
                #region AND
                allReplaces[2] = expression.TryReplace("true and true", "true", out expression);
                allReplaces[3] = expression.TryReplace("true and false", "false", out expression);
                allReplaces[4] = expression.TryReplace("false and true", "false", out expression);
                allReplaces[5] = expression.TryReplace("false and false", "false", out expression);
                #endregion
                #region OR
                allReplaces[6] = expression.TryReplace("true or true", "true", out expression);
                allReplaces[7] = expression.TryReplace("true or false", "true", out expression);
                allReplaces[8] = expression.TryReplace("false or true", "true", out expression);
                allReplaces[9] = expression.TryReplace("false or false", "false", out expression);
                #endregion
                #region Parentheses
                allReplaces[10] = expression.TryReplace("(true)", "true", out expression);
                allReplaces[11] = expression.TryReplace("( true )", "true", out expression);
                allReplaces[12] = expression.TryReplace("(false)", "false", out expression);
                allReplaces[13] = expression.TryReplace("( false )", "false", out expression);
                #endregion
            }
            return bool.Parse(expression);
        }

        private bool GetBoolValue(string operand) {
            operand = operand.Trim();
            if (operand.Equals("1")) {
                return true;
            }
            if (operand.Equals("0")) {
                return false;
            }
            return bool.Parse(operand);
        }

        private bool GetBoolValue(string operand1, string operant, string operand2) {
            double opr1, opr2;

            switch (operant) {
                case "=":
                case "==":
                    return (operand1.Equals(operand2));
                case "<>":
                case "!=":
                    return !(operand1.Equals(operand2));
                default:
                    if (!double.TryParse(operand1, out opr1) || !double.TryParse(operand2, out opr2)) {
                        throw new Exception("Operator cannot be applied to strings");
                    }
                    switch (operant) {
                        case ">":
                            return (opr1 > opr2);
                        case ">=":
                        case "=>":
                            return (opr1 >= opr2);
                        case "<":
                            return (opr1 < opr2);
                        case "<=":
                        case "=<":
                            return (opr1 <= opr2);
                        default:
                            throw new Exception("Invalid operator - '" + operant + "'");
                    }
            }
        }

        private string buildString(params string[] args) {
            int i = 0;
            StringBuilder sb = new StringBuilder();
            do {
                if (args[i].Contains(" ") || args[i].Equals("")) {
                    sb.Append(" \"" + args[i] + "\"");
                }
                else {
                    sb.Append(" " + args[i]);
                }
                i++;
            }
            while (i < args.Length);
            return sb.ToString();
        }
    }
}
