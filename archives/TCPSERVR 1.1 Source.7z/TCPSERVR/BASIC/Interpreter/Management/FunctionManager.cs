﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tcpservr.BASIC.Library;

namespace Tcpservr.BASIC {
    public class FunctionManager {

        private MathLibrary mathLib;
        private ScriptLibrary scriptLib;
        private StringLibrary stringLib;
        private BooleanManager boolMan;

        private Dictionary<string, FunctionMethod> library;

        public FunctionManager(Interpreter interpreter) {
            // Initialize the libraries
            library = new Dictionary<string, FunctionMethod>();

            // Add all math functions
            mathLib = new MathLibrary();
            foreach (var v in mathLib.GetStatementLibrary()) {
                this.library.Add(v.Key, v.Value);
            }

            // Add all script functions
            scriptLib = new ScriptLibrary(interpreter);
            foreach (var v in scriptLib.GetStatementLibrary()) {
                this.library.Add(v.Key, v.Value);
            }

            // Add all string functions
            stringLib = new StringLibrary(interpreter);
            foreach (var v in stringLib.GetLibrary()) {
                this.library.Add(v.Key, v.Value);
            }

            // Add all bool functions
            boolMan = new BooleanManager(interpreter);
            foreach (var v in boolMan.GetFuncLibrary()) {
                this.library.Add(v.Key, v.Value);
            }

            // Add all form functions
            foreach (var v in interpreter.FormLibrary.GetLibrary()) {
                this.library.Add(v.Key, v.Value);
            }
        }

        public bool FuncExists(string func) {
            return this.library.ContainsKey(func);
        }

        public object InvokeFunc(TMessage statement) {
            return this.library[statement.ArgsOriginal[0].ToLower()].Invoke(statement);
        }
    }
}
