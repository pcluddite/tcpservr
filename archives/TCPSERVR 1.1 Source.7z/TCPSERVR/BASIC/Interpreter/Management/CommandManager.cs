﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tcpservr.BASIC.Library;

namespace Tcpservr.BASIC {
    public class CommandManager {

        private BooleanManager boolMan;
        private ScriptLibrary scriptLib;
        private Dictionary<string, CommandMethod> library;
        private Dictionary<string, BlockMethod> blockLib;

        public CommandManager(Interpreter interpreter) {
            blockLib = new Dictionary<string, BlockMethod>();
            library = new Dictionary<string, CommandMethod>();

            // Script commands
            scriptLib = new ScriptLibrary(interpreter);
            foreach (var v in scriptLib.GetCommandLibrary()) {
                library.Add(v.Key, v.Value);
            }

            // Add all code blocks
            boolMan = new BooleanManager(interpreter);
            foreach (var v in boolMan.GetBlockLibrary()) {
                blockLib.Add(v.Key, v.Value);
            }
        }

        public bool CmdExists(string name) {
            return library.ContainsKey(name.ToLower());
        }

        public string InvokeCMD(Command command) {
            return this.library[command.Name.ToLower()].Invoke(command);
        }

        public void InvokeBlock(CodeBlock block) {
            this.blockLib[block.Header.Name.ToLower()].Invoke(block);
        }
    }
}
