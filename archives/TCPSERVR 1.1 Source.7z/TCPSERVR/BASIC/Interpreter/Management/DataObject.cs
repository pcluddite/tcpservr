﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tcpservr.BASIC {
    public class DataObject {

        private object data;
        private string name;

        private bool isMacro;

        public string Name {
            get {
                return name;
            }
        }

        public Type Type {
            get {
                double dummy;
                if (double.TryParse(data.ToString(), out dummy)) {
                    return typeof(double);
                }
                if (data.GetType() == typeof(object[]) ||
                    data.GetType() == typeof(DataObject[])) {
                    return typeof(DataObject[]);
                }
                return typeof(string);
            }
        }

        public int Length {
            get {
                if (Type == typeof(DataObject[])) {
                    return (data as object[]).Length;
                }
                else {
                    return data.ToString().Length;
                }
            }
        }

        public DataObject(string name) {
            init(name, null, false);
        }

        public DataObject(string name, bool isMacro) {
            init(name, null, isMacro);
        }

        public DataObject(string name, object data) {
            init(name, data, false);
        }

        public DataObject(string name, object data, bool isMacro) {
            init(name, data, isMacro);
        }

        private void init(string name, object data, bool isMacro) {
            this.isMacro = isMacro;
            this.name = name;
            CheckName(name, isMacro);
            this.data = data;
        }

        public void SetData(object data) {
            this.data = data;
        }

        public object GetData() {
            return this.data;
        }

        public void AllocateArray(int dim) {
            data = new DataObject[dim];
        }

        public void SetArrayElement(int element, object data) {
            if (this.Type != typeof(DataObject[])) {
                throw new Exception("The data object is not an array");
            }
            object[] array = (object[])this.data;
            if (array[element] == null) {
                array[element] = new DataObject(name);
            }
            (array[element] as DataObject).SetData(data);
        }

        public void CopyArrayElements(object[] data, int index) {
            if (this.Type != typeof(DataObject[])) {
                throw new Exception("The data object is not an array");
            }
            object[] array = (object[])this.data;
            data.CopyTo(array, 0);
            this.data = array;
        }

        public static DataObject[] FromStringArray(string[] array) {
            DataObject[] ret = new DataObject[array.Length];
            for (int i = 0; i < ret.Length; i++) {
                ret[i] = new DataObject("a$", array[i]);
            }
            return ret;
        }

        public DataObject GetArrayElement(int element) {
            if (this.Type != typeof(DataObject[])) {
                throw new Exception("The data object is not an array");
            }
            object[] array = (data as object[]);
            if (array[element] == null) {
                array[element] = new DataObject(name);
            }
            return (DataObject)array[element];
        }

        private void CheckName(string key, bool isMacro) {
            if (!isMacro) {
                if (key.EndsWith("$")) {
                    key = key.Remove(key.Length - 1, 1);
                }
                else {
                    throw new Exception("Variable name does not end with '$'");
                }
            }
            else {
                if (key.StartsWith("@")) {
                    key = key.Remove(0, 1);
                }
            }
            if (char.IsDigit(key, 0)) {
                throw new Exception("Variable cannot start with a digit");
            }
            foreach (char c in key.ToCharArray()) {
                if (!char.IsLetterOrDigit(c)) {
                    throw new Exception("Invalid character in variable name");
                }
            }
        }
    }
}
