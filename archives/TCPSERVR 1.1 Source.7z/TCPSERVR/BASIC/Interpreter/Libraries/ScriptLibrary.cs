﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;

namespace Tcpservr.BASIC.Library {
    public class ScriptLibrary {

        private Interpreter interpreter;

        public ScriptLibrary(Interpreter interpreter) {
            this.interpreter = interpreter;
        }

        public Dictionary<string, CommandMethod> GetCommandLibrary() {
            Dictionary<string, CommandMethod> lib = new Dictionary<string, CommandMethod>();
            lib.Add("showerror", ShowError);
            lib.Add("hideerror", HideError);
            lib.Add("return", Return);
            lib.Add("seterror", SetStatus);
            lib.Add("setstatus", SetStatus);
            lib.Add("let", LET);
            lib.Add("exit", Exit);
            lib.Add("break", Break);
            lib.Add("delvar", DelVar);
            lib.Add("dim", DIM);
            lib.Add("else", UhOh);
            lib.Add("end", UhOh);
            lib.Add("wend", UhOh);
            return lib;
        }

        public Dictionary<string, FunctionMethod> GetStatementLibrary() {
            Dictionary<string, FunctionMethod> lib = new Dictionary<string, FunctionMethod>();
            lib.Add("msgbox", MsgBox);
            lib.Add("input", Input);
            lib.Add("sleep", Sleep);
            lib.Add("ver", Ver);
            return lib;
        }

        public string Storage { get; set; }

        public string Ver(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            return "200 " + TBASIC.VER;
        }

        public string Input(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 5) { return "400 Bad Request"; }
            int width, height;
            if (!(int.TryParse(args[3], out width) && int.TryParse(args[4], out height))) {
                return "400 Bad Request: arg[3], arg[4] not integer";
            }
            INPUT input = new INPUT(this, args[2], args[1], width, height);
            input.ShowDialog();
            string ret = this.Storage;
            if (ret == null) {
                ret = "204 No Input";
            }
            else {
                ret = "200 " + ret;
            }
            return ret;
        }

        public string MsgBox(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 4) { return "400 Bad Request"; }
            string flasg = args[1],
                   text = args[2],
                   title = args[3];
            int flag;
            if (!int.TryParse(flasg, out flag)) {
                return "400 Bad Request: arg[1] not integer";
            }
            MsgBoxStyle style = MsgBoxStyle.OkOnly;

            if ((flag & 1) == 1) { style = style | MsgBoxStyle.OkCancel; }
            if ((flag & 2) == 2) { style = style | MsgBoxStyle.AbortRetryIgnore; }
            if ((flag & 3) == 3) { style = style | MsgBoxStyle.YesNoCancel; }
            if ((flag & 4) == 4) { style = style | MsgBoxStyle.YesNo; }
            if ((flag & 5) == 5) { style = style | MsgBoxStyle.RetryCancel; }
            if ((flag & 16) == 16) { style = style | MsgBoxStyle.Critical; }
            if ((flag & 32) == 32) { style = style | MsgBoxStyle.Question; }
            if ((flag & 48) == 48) { style = style | MsgBoxStyle.Exclamation; }
            if ((flag & 64) == 64) { style = style | MsgBoxStyle.Information; }
            if ((flag & 256) == 256) { style = style | MsgBoxStyle.DefaultButton2; }
            if ((flag & 512) == 512) { style = style | MsgBoxStyle.DefaultButton3; }
            if ((flag & 262144) == 262144) { style = style | MsgBoxStyle.MsgBoxSetForeground; }
            if ((flag & 524288) == 524288) { style = style | MsgBoxStyle.MsgBoxRight; }

            MsgBoxResult result = Interaction.MsgBox(text, style, title);
            return "200 " + result.ToString();
        }

        public string Sleep(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 2) { return "400 Bad Request"; }
            int timeout;
            if (!int.TryParse(args[1], out timeout)) {
                return "400 Bad Request: arg[1] not integer";
            }
            System.Threading.Thread.Sleep(timeout);
            return NULL(null);
        }

        public string Break(Command line) {
            interpreter.TBASIC.BreakRequest = true;
            return NULL(line);
        }

        public string Exit(Command line) {
            interpreter.RequestExit();
            return "202 Exiting";
        }

        public string NULL(CodeLine line) {
            if (interpreter.DataManager.ObjectExists("@return") && interpreter.DataManager.ObjectExists("@status")) {
                return interpreter.DataManager["@status"].GetData() + " " + interpreter.DataManager["@return"].GetData();
            }
            else {
                return "200 Done";
            }
        }

        public string UhOh(Command line) {
            throw new Exception("No opening " + CodeBlock.GetStartword(line.Text.Trim()) + " statement");
        }

        public string DIM(Command line) {
            string[] args = line.Arguments;
            if (args.Length < 2) {
                throw new Exception("DIM was formatted poorly");
            }
            if (args[1].EndsWith("$")) {
                return LET(line);
            }
            if (args.Length != 2) {
                throw new Exception("DIM was formatted poorly");
            }

            string name = args[1];
            Match dim = TBASIC.DimensionEx.Match(args[1]);

            if (dim.Success) {
                name = name.Replace(dim.Value, "");
            }

            int index;
            if (!int.TryParse(interpreter.JoinParm(new Parameter(dim.Value.RemoveBrackets()), false), out index)) {
                throw new Exception("Could not parse array index");
            }
            interpreter.DataManager.AllocateArray(name, index);

            return this.NULL(line);
        }

        public string LET(Command line) {
            string[] args = line.ParseKeepQuotes();
            if (args.GetUpperBound(0) < 3) {
                throw new Exception("LET was formatted poorly");
            }
            string name = args[1];

            if (args[2].CompareTo("=") != 0) {
                throw new Exception("An equality was expected: '='");
            }

            string nLine = line.Text;
            nLine = nLine.Remove(0, args[0].Length).TrimStart();
            nLine = nLine.Remove(0, args[1].Length).TrimStart();
            nLine = nLine.Remove(0, args[2].Length).TrimStart();

            Parameter val = new Parameter(nLine);
            interpreter.DataManager.SaveObject(name, interpreter.JoinParm(val, false));
            return this.NULL(line);
        }

        public string DelVar(Command line) {
            string[] args = line.FormattedArgs;
            if (args.Length != 2) { return "400 Bad Request"; }
            interpreter.DataManager.DeleteObject(args[1]);
            return NULL(line);
        }

        public string ShowError(Command line) {
            this.interpreter.ThrowOnError = true;
            return "200 OK";
        }

        public string HideError(Command line) {
            this.interpreter.ThrowOnError = false;
            return "200 OK";
        }

        private string Return(Command line) {
            if (line.Arguments.Length < 1) {
                throw new Exception("The return statement was formatted poorly.");
            }
            string ret = interpreter.JoinParm(new Parameter(line.Text.Remove(0,line.Name.Length).TrimStart()), true);
            //Command dummy = new Command(ret);
            interpreter.TBASIC.ReturnValue = ret;
            interpreter.TBASIC.BreakRequest = true;
            return "200 OK";
        }

        private string SetStatus(Command line) {
            if (line.Arguments.Length != 2) {
                throw new Exception("Could not set the status code for the command.");
            }
            if (line.FormattedArgs[1].Length != 3) {
                throw new Exception("The status code was invalid.");
            }
            int status;
            if (!int.TryParse(line.FormattedArgs[1], out status)) {
                throw new Exception("The status code was not represented by an integer.");
            }
            interpreter.TBASIC.Status = status;
            return "200 OK";
        }
    }
}
