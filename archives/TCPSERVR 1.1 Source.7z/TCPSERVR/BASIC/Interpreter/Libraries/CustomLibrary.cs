﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tcpservr.BASIC {
    public class CustomLibrary {

        private Dictionary<Function, CodeBlock> funcs;
        private Interpreter inter;
        
        public CustomLibrary() {
            funcs = new Dictionary<Function, CodeBlock>();
        }

        public void SetInterpreter(Interpreter inter) {
            this.inter = inter;
        }

        public void AddFunction(CodeBlock func) {
            Function header;
            if (!Function.TryParse(func.Header.Text.Remove(0, func.Header.Name.Length).Trim(), out header)) {
                throw new Exception("The header for the function block was formatted poorly.");
            }
            if (this.FunctionExists(header.Name)) {
                throw new Exception("A function with the name '" + header.Name + "' already exists.");
            }
            funcs.Add(header, func);
        }

        public bool FunctionExists(string name) {
            foreach (var func in funcs) {
                if (func.Key.Name.ToLower().Equals(name.ToLower())) {
                    return true;
                }
            }
            return false;
        }

        public CodeBlock GetCode(string name) {
            foreach (var func in funcs) {
                if (func.Key.Name.ToLower().Equals(name.ToLower())) {
                    return func.Value;
                }
            }
            throw new Exception("No function with that name was found.");
        }

        public Function GetFunction(string name) {
            name = name.ToLower();
            foreach (var func in funcs) {
                if (func.Key.Name.ToLower().Equals(name)) {
                    return func.Key;
                }
            }
            throw new Exception("No function with that name was found.");
        }

        public string Invoke(TMessage func) {
            Function template = GetFunction(func.Args[0]);
            CodeBlock code = GetCode(func.Args[0]);
            if (template.Parameters.Length != func.Args.Length - 1) {
                return "400 Bad Request";
            }
            Dictionary<string, object> localVars = new Dictionary<string, object>();
            Dictionary<string, object> oldVars = new Dictionary<string, object>();
            for (int i = 0; i < template.Parameters.Length; i++) {
                string name = template.Parameters[i].Text;
                localVars.Add(name, func.Args[i + 1]);
                if (inter.DataManager.ObjectExists(name)) {
                    oldVars.Add(name, inter.DataManager[name].GetData());
                }
                inter.DataManager.SaveObject(template.Parameters[i].Text, func.Args[i + 1]);
            }
            inter.TBASIC.Status = 202;
            inter.TBASIC.ReturnValue = "Accepted";
            string ret = inter.TBASIC.Process(new Code(code.CodeLines, code.Header.ID + 1, BlockType.Function));
            inter.TBASIC.BreakRequest = false;
            foreach (string name in localVars.Keys) {
                inter.DataManager.DeleteObject(name);
            }
            foreach (var v in oldVars) {
                inter.DataManager.SaveObject(v.Key, v.Value);
            }
            return ret;
        }
    }
}
