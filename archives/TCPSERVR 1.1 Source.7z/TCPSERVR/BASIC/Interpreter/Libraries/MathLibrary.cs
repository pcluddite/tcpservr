﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tcpservr.BASIC.Library {
    public class MathLibrary {

        private Random rand;

        public MathLibrary() {
            rand = new Random();
        }

        public Dictionary<string, FunctionMethod> GetStatementLibrary() {
            Dictionary<string, FunctionMethod> lib = new Dictionary<string, FunctionMethod>();
            lib.Add("pow", Pow);
            lib.Add("ipart", iPart);
            lib.Add("fpart", fPart);
            lib.Add("round", Round);
            lib.Add("eval", Eval);
            lib.Add("random", Random);
            return lib;
        }

        public string Random(TMessage line) {
            if (line.Args.Length != 1) {
                return "400 Bad Request";
            }
            return "200 " + rand.NextDouble().ToString("0.########");
        }

        public string Round(TMessage line) {
            string[] args = line.Args;
            if (args.Length == 2) { args = new string[] { args[0], args[1], "2" }; }
            if (args.Length != 3) {
                return "400 Bad Request";
            }
            decimal dec;
            int places;
            if (!decimal.TryParse(args[1], out dec)) {
                return "400 Bad Request: arg[1] not decimal";
            }
            if (!int.TryParse(args[2], out places)) {
                return "400 Bad Request: arg[2] not integer";
            }
            return "200 " + System.Math.Round(dec, places);
        }

        public string iPart(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 2) {
                return "400 Bad Request";
            }
            decimal d;
            if (!decimal.TryParse(args[1], out d)) {
                return "400 Bad Request: arg[1] not decimal";
            }
            string result = d.ToString();
            int period = result.IndexOf('.');
            if (period == -1) {
                return "200 " + result.ToString();
            }
            else {
                return "200 " + result.Remove(period, result.Length - period);
            }
        }

        public string fPart(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 2) {
                return "400 Bad Request";
            }
            decimal d;
            if (!decimal.TryParse(args[1], out d)) {
                return "400 Bad Request: arg[1] not decimal";
            }
            string result = d.ToString();
            int period = result.IndexOf('.');
            if (period == -1) {
                return "200 " + result.ToString();
            }
            else {
                return "200 " + result.Remove(0, period);
            }
        }

        public string Eval(TMessage line) {
            if (line.ArgsOriginal.Length != 2) { return "400 Bad Request"; }
            return "200 " + Eval(line.Args[1]);
        }

        private static System.Text.RegularExpressions.Regex mathEx = new System.Text.RegularExpressions.Regex(@"([\+\-\*])");
        public static double Eval(string expression) {
            Parameter p = new Parameter(expression);
            if (p.Type == ParamType.Double) {
                return double.Parse(expression);
            }
            if (p.Type != ParamType.Math) {
                throw new Exception("The string was unable to be parsed as a valid math expression");
            }
            return (double)new System.Xml.XPath.XPathDocument
                    (new System.IO.StringReader("<r/>")).CreateNavigator().Evaluate(
                    string.Format("number({0})", mathEx
                        .Replace(expression, " ${1} ")
                        .Replace("/", " div ")
                        .Replace("%", " mod ")));
        }

        public string Pow(TMessage line) {
            if (line.ArgsOriginal.Length != 3) { return "400 Bad Request"; }
            double b, exp;
            if (!double.TryParse(line.Args[1], out b)) {
                return "400 Bad Request: arg[1] not double";
            }
            if (!double.TryParse(line.Args[2], out exp)) {
                return "400 Bad Request: arg[1] not double";
            }
            return "200 " + System.Math.Pow(b, exp);
        }
    }
}