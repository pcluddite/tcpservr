﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Tcpservr.BASIC.Library {
    public class StringLibrary {

        private Interpreter inter;

        public StringLibrary(Interpreter inter) {
            this.inter = inter;
        }

        public Dictionary<string, FunctionMethod> GetLibrary() {
            Dictionary<string, FunctionMethod> lib = new Dictionary<string, FunctionMethod>();
            lib.Add("append", Append);
            lib.Add("contains", Contains);
            lib.Add("index", Index);
            lib.Add("upper", Upper);
            lib.Add("lower", Lower);
            lib.Add("left", Left);
            lib.Add("right", Right);
            lib.Add("take", Take);
            lib.Add("len", Len);
            lib.Add("isint", IsInt);
            lib.Add("isdecimal", IsDecimal);
            lib.Add("trim", Trim);
            lib.Add("trimstart", TrimStart);
            lib.Add("trimend", TrimEnd);
            lib.Add("split", Split);
            return lib;
        }

        public object Split(TMessage msg) {
            if (msg.Args.Length != 3) {
                return "400 Bad Request";
            }
            string[] split = Regex.Split(msg.Args[1], msg.Args[2]);
            DataObject dObject = new DataObject("a200$");
            dObject.AllocateArray(split.Length);
            dObject.CopyArrayElements(DataObject.FromStringArray(split), 0);
            return dObject;
        }

        public string Trim(TMessage msg) {
            if (msg.Args.Length != 2) {
                return "400 Bad Request";
            }
            return "200 " + msg.Args[1].Trim();
        }

        public string TrimStart(TMessage msg) {
            if (msg.Args.Length != 2) {
                return "400 Bad Request";
            }
            return "200 " + msg.Args[1].TrimStart();
        }

        public string TrimEnd(TMessage msg) {
            if (msg.Args.Length != 2) {
                return "400 Bad Request";
            }
            return "200 " + msg.Args[1].TrimEnd();
        }

        public string Len(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 2) { return "400 Bad Request"; }
            Function funcLine = new Function(line.Storage.ToString());
            if (funcLine.Parameters[0].BreakParameter().Length == 1 &&
                inter.DataManager.ObjectExists(funcLine.Parameters[0].Text) &&
                inter.DataManager.GetObjectType(funcLine.Parameters[0].Text) == typeof(DataObject[])) {
                return "200 " + inter.DataManager.GetObject(funcLine.Parameters[0].Text).Length;
            }
            return "200 " + args[1].Length;
        }

        public string Append(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 3) { return "400 Bad Request"; }
            return "200 " + args[1] + args[2];
        }

        public string Contains(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 3) { return "400 Bad Request"; }
            return "200 " + args[1].Contains(args[2]).ToString();
        }

        public string Index(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 3) { return "400 Bad Request"; }
            return "200 " + args[1].IndexOf(args[2]).ToString();
        }

        public string Upper(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 2) { return "400 Bad Request"; }
            return "200 " + args[1].ToUpper();
        }

        public string Lower(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 2) { return "400 Bad Request"; }
            return "200 " + args[1].ToLower();
        }

        public string Left(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 4) { return "400 Bad Request"; }
            int start, length;
            if (!int.TryParse(args[2], out start) || !int.TryParse(args[3], out length)) {
                return "400 Bad Request: arg[2], arg[3] not integer";
            }
            return "200 " + args[1].Remove(start, length);
        }

        public string Right(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 4) { return "400 Bad Request"; }
            int start, length;
            if (!int.TryParse(args[2], out start) || !int.TryParse(args[3], out length)) {
                return "400 Bad Request: arg[2], arg[3] not integer";
            }
            return "200 " + args[1].Remove(start - length, length);
        }

        public string Take(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 4) {
                return "400 Bad Request";
            }
            int start, length;
            if (!int.TryParse(args[2], out start) || !int.TryParse(args[3], out length)) {
                return "400 Bad Request: arg[2], arg[3] not integer";
            }
            return "200 " + args[1].Substring(start, length);
        }

        public string IsInt(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 2) {
                return "400 Bad Request";
            }
            int temp;
            return "200 " + int.TryParse(args[1], out temp);
        }

        public string IsDecimal(TMessage line) {
            string[] args = line.Args;
            if (args.Length != 2) {
                return "400 Bad Request";
            }
            double temp;
            return "200 " + double.TryParse(args[1], out temp);
        }
    }
}
