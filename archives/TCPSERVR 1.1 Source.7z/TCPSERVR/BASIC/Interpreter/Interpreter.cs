﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using Tcpservr.Libraries;

namespace Tcpservr.BASIC {

    public delegate object FunctionMethod(TMessage statement);
    public delegate string CommandMethod(Command statement);
    public delegate void BlockMethod(CodeBlock block);

    public delegate void UserHasExittedEventHandler(object sender, EventArgs e);

    public class Interpreter {
        
        public LibraryCollection MainLibrary { get; set; }
        public CommandManager CmdLib { get; set; }
        public FunctionManager FuncLib { get; set; }
        public CustomLibrary UserLibrary { get; set; }

        public FormLibrary FormLibrary { get; set; }

        public DataManager DataManager { get; set; }

        public bool ThrowOnError { get; set; }

        public TBASIC TBASIC { get; set; }

        public event UserHasExittedEventHandler OnUserExitRequest;

        protected virtual void OnUserExit(EventArgs e) {
            if (OnUserExitRequest != null) {
                OnUserExitRequest(this, e);
            }
        }

        public Interpreter(TBASIC tbasic, CustomLibrary userFuncs) {
            this.DataManager = new DataManager(this);
            this.FormLibrary = new FormLibrary(userFuncs);
            this.ThrowOnError = true;
            this.TBASIC = tbasic;
            this.CmdLib = new CommandManager(this);
            this.FuncLib = new FunctionManager(this);
            this.MainLibrary = new LibraryCollection(tbasic.TCPSERVR, true);
            this.UserLibrary = userFuncs;
        }

        public void RequestExit() {
            TBASIC.ExitRequest = true;
            OnUserExit(EventArgs.Empty);
        }

        public object Execute(CodeLine codeLine) {
            string text = codeLine.Text;
            object ret;
            if (CmdLib.CmdExists(codeLine.Name)) {
                ret = CmdLib.InvokeCMD(new Command(text, this.DataManager));
            }
            else {
                ret = SolveFunction(text);
            }
            int status;
            if (ret.GetType() == typeof(string)) {
                string retString = ret.ToString();
                if (!int.TryParse(retString.Split(' ')[0].Trim(), out status)) {
                    throw new Exception("The command returned a bad status code");
                }
                ret = retString.Remove(0, 3).Trim();
                if (this.ThrowOnError && (status < 200 || status >= 300)) {
                    throw new Exception(retString);
                }
            }
            else {
                DataObject dObject = (DataObject)ret;
                if (!int.TryParse(TBASIC.Digits.Match(dObject.Name).Value, out status)) {
                    throw new Exception("The command returned a bad status code");
                }
                ret = dObject.GetData();
            }
            DataManager.SaveObject("@status", status, true);
            DataManager.SaveObject("@error", status, true);
            DataManager.SaveObject("@return", ret, true);
            DataManager.SaveObject("@ret", ret, true);
            return ret;
        }

        private object SolveFunction(string funcLine) {
            Function function = new Function(funcLine);
            string name = function.Name.ToLower();
            List<string> parms = new List<string>();
            parms.Add(name);
            foreach (Parameter p in function.Parameters) {
                parms.Add(ProcessParam(p, false).ToString());
            }
            TMessage msg = new TMessage();
            msg.Process(parms.ToArray()); // Convert to message to be processed by the main library
            msg.Storage = funcLine; // Store the original function text for possible use
            TBASIC.TCPSERVR.CurrentThread.CreateReport(msg);
            try {
                if (this.FuncLib.FuncExists(name)) {
                    return this.FuncLib.InvokeFunc(msg);
                }
                else if (this.MainLibrary.ContainsKey(name)) {
                    return this.MainLibrary[name].Invoke(msg);
                }
                else if (this.UserLibrary.FunctionExists(name)) {
                    return this.UserLibrary.Invoke(msg);
                }
                else {
                    throw new Exception("The meaning of '" + name + "' is unknown");
                }
            }
            finally {
                TBASIC.TCPSERVR.CurrentThread.CompletedReport(msg);
            }
        }

        private object ProcessParam(Parameter p, bool passError) {
            object ret;
            switch (p.Type) {
                case ParamType.Function:
                    ret = Execute(new CodeLine(p.Text));
                    break;
                case ParamType.Broken:
                    ret = JoinParm(p);
                    p.QuotesRemoved = true;
                    break;
                case ParamType.Math:
                    string eval = DataManager.ReplaceObjects(p.Text);
                    foreach (Match m in TBASIC.FunctionEx.Matches(p.Text)) {
                        eval = eval.Replace(m.Value, SolveFunction(m.Value).ToString().Remove(0, 4));
                    }
                    ret = Library.MathLibrary.Eval(eval);
                    break;
                case ParamType.Variable:
                    ret = DataManager.GetObject(p.Text).GetData();
                    p.QuotesRemoved = true;
                    break;
                case ParamType.Error:
                    if (!passError) {
                        throw new Exception("The name '" + p.Text + "' is undefined");
                    }
                    else {
                        ret = p.Text;
                    }
                    break;
                default:
                    ret = p.Text;
                    break;
            }
            p.Text = ret.ToString();
            if (p.Type == ParamType.Math) {
                ret = ProcessParam(p, passError);
            }
            if (ret.GetType() == typeof(double)) {
                return ret;
            }
            if (!p.QuotesRemoved) {
                return RemoveQuotes(ret.ToString());
            }
            return ret.ToString();
        }

        public string JoinParm(Parameter parm) {
            return JoinParm(parm, false);
        }

        public string JoinParm(Parameter parm, bool hideError) {
            List<string> allParms = new List<string>();
            Parameter lastParm = null;
            foreach (Parameter p in parm.BreakParameter()) {
                string ret;
                switch (p.Type) {
                    case ParamType.Double:
                        if (lastParm != null && lastParm.Type == ParamType.Double) {
                            allParms.RemoveAt(allParms.Count - 1);
                            ret = (double.Parse(lastParm.Text) + double.Parse(p.Text)).ToString();
                        }
                        else {
                            ret = p.Text;
                        }
                        break;
                    default:
                        ret = ProcessParam(p, hideError).ToString();
                        break;
                }
                allParms.Add(ret);
                lastParm = p;
            }
            return string.Join("", allParms.ToArray());
        }

        private string RemoveQuotes(string s) {
            if (s.Length == 1) {
                return s;
            }
            while ((s.StartsWith("\"") && s.EndsWith("\"")) ||
                (s.StartsWith("(") && s.EndsWith(")"))) {
                s = s.Remove(0, 1);
                s = s.Remove(s.Length - 1, 1);
            }
            return s;
        }
    }
}
