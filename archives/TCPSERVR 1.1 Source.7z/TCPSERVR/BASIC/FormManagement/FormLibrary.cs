﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using global::Tcpservr.Libraries;
using System.Drawing;

namespace Tcpservr.BASIC {

    public delegate void AllDisposedEventHandler(object sender, EventArgs e);

    public class FormLibrary {

        private Dictionary<IntPtr, FormInfo> windows;

        public Dictionary<IntPtr, ControlInfo> Controls {
            get {
                Dictionary<IntPtr, ControlInfo> infos = new Dictionary<IntPtr, ControlInfo>();
                foreach (var form in this) {
                    foreach(ControlInfo control in form.Value.Controls) {
                        infos.Add(control.Handle, control);
                    }
                }
                return infos;
            }
        }

        public CustomLibrary UserLibrary {
            get {
                return userLib;
            }
        }

        private CustomLibrary userLib;
        public FormLibrary(CustomLibrary userLib) {
            windows = new Dictionary<IntPtr, FormInfo>();
            this.userLib = userLib;
        }

        public FormInfo this[IntPtr hwnd] {
            get {
                return windows[hwnd];
            }
        }

        public int Count {
            get {
                return windows.Count;
            }
        }

        public Dictionary<IntPtr, FormInfo>.Enumerator GetEnumerator() {
            return this.windows.GetEnumerator();
        }

        public void AddForm(FormInfo f) {
            windows.Add(f.Form.Handle, f);
        }

        public void RemoveForm(IntPtr hwnd) {
            windows.Remove(hwnd);
        }

        public void ClearDisposed() {
            List<IntPtr> toRemove = new List<IntPtr>();
            foreach (var v in this.windows) {
                if (v.Value.IsDisposed) {
                    toRemove.Add(v.Key);
                }
            }
            foreach (IntPtr hwnd in toRemove) {
                windows.Remove(hwnd);
            }
            if (windows.Count == 0) {
                OnAllDisposed(EventArgs.Empty);
            }
        }

        public event AllDisposedEventHandler AllDisposed;

        protected virtual void OnAllDisposed(EventArgs e) {
            if (AllDisposed != null) {
                AllDisposed(this, e);
            }
        }

        public Dictionary<string, FunctionMethod> GetLibrary() {
            Dictionary<string, FunctionMethod> lib = new Dictionary<string, FunctionMethod>();
            lib.Add("guicreate", GuiCreate);
            lib.Add("defineevent", DefineEvent);
            lib.Add("guicreatebutton", GuiCreateButton);
            lib.Add("guicreatetextbox", GuiCreateTextBox);
            lib.Add("guicreatelabel", GuiCreateLabel);

            lib.Add("controlgettext", ControlGetText);
            lib.Add("controlsettext", ControlSetText);
            lib.Add("guisetdefaultbutton", GuiSetDefaultButton);
            return lib;
        }

        public string GuiCreate(TMessage msg) {
            if (msg.Args.Length > 7) {
                return "400 Bad Request";
            }
            string[] args = new string[7];
            for (int i = 0; i < args.Length; i++) {
                if (i < msg.Args.Length) {
                    args[i] = msg.Args[i];
                }
            }
            string title, parent;
            parent = args[6];


            title = args[1];
            if (title == null) {
                title = "";
            }

            for (int i = 0; i < args.Length; i++) {
                if (args[i] == null) {
                    args[i] = "-1";
                }
            }
            int x, y, w, h;
            if (!(int.TryParse(args[2], out w) &&
                  int.TryParse(args[3], out h) &&
                  int.TryParse(args[4], out x) &&
                  int.TryParse(args[5], out y))) {
                return "400 Bad Request: Argument was not an integer!";
            }

            try {
                if (windows.Count == 0) {
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                }
                GUI temp = new GUI(this, title, w, h, x, y, parent);
                FormInfo gui = new FormInfo(temp, this);
                this.AddForm(gui);
                return "201 " + gui.Handle;
            }
            catch (Exception ex) {
                return "400 " + ex.Message;
            }
        }

        public string DefineEvent(TMessage msg) {
            if (msg.Args.Length != 4) {
                return "400 Bad Request";
            }
            int hwnd;
            if (!int.TryParse(msg.Args[1], out hwnd)) {
                return "400 Bad Request: Arguemnt 1 was not an integer";
            }
            if (!userLib.FunctionExists(msg.Args[3])) {
                return "404 The function does not exist";
            }
            ControlInfo info;
            IntPtr hwndIntPtr = (IntPtr)hwnd;
            if (windows.ContainsKey(hwndIntPtr)) {
                info = windows[hwndIntPtr];
            }
            else {
                var controls = this.Controls;
                if (controls.ContainsKey(hwndIntPtr)) {
                    info = controls[hwndIntPtr];
                }
                else {
                    return "404 The control does not exist or is not managed";
                }
            }
            switch (msg.Args[2].ToLower()) {
                case "closed":
                    (info as FormInfo).Closed = msg.Args[3];
                    break;
                case "closing":
                    (info as FormInfo).OnClosing = msg.Args[3];
                    break;
                case "keypress":
                    info.OnKeyPress = msg.Args[3];
                    break;
                case "keydown":
                    info.OnKeyDown = msg.Args[3];
                    break;
                case "keyup":
                    info.OnKeyUp = msg.Args[3];
                    break;
                case "mousedown":
                    info.OnMouseDown = msg.Args[3];
                    break;
                case "mouseup":
                    info.OnMouseUp = msg.Args[3];
                    break;
                case "mouseclick":
                    info.OnMouseClick = msg.Args[3];
                    break;
                case "mousedoubleclick":
                    info.OnMouseDoubleClick = msg.Args[3];
                    break;
                case "gotfocus":
                    info.GotFocus = msg.Args[3];
                    break;
                default:
                    return "400 Bad Request: Argument 2 was not a valid event.";
            }
            return "200 OK";
        }

        public string GuiCreateButton(TMessage msg) {
            string[] args = msg.Args;
            if (args.Length == 5) {
                args = new string[] { args[0], args[1], args[2], args[3], args[4], "-1", "-1" };
            }
            if (args.Length != 7) {
                return "400 Bad Request";
            }
            string data;
            int[] parms;
            if (!checkAddControlSyntax(args, out data, out parms)) {
                return data;
            }
            Button button = new Button();
            button.Text = msg.Args[2];
            addControl(windows[(IntPtr)parms[4]], button,parms[0], parms[1], parms[2], parms[3]);
            return "201 " + button.Handle;
        }

        public string GuiCreateTextBox(TMessage msg) {
            string[] args = msg.Args;
            if (args.Length == 5) {
                args = new string[] { args[0], args[1], args[2], args[3], args[4], "-1", "-1" };
            }
            if (args.Length != 7) {
                return "400 Bad Request";
            }
            string data;
            int[] parms;
            if (!checkAddControlSyntax(args, out data, out parms)) {
                return data;
            }
            TextBox textBox = new TextBox();
            textBox.Text = msg.Args[2];
            addControl(windows[(IntPtr)parms[4]], textBox, parms[0], parms[1], parms[2], parms[3]);
            return "201 " + textBox.Handle;
        }

        public string GuiCreateLabel(TMessage msg) {
            string[] args = msg.Args;
            if (args.Length == 5) {
                args = new string[] { args[0], args[1], args[2], args[3], args[4], "-1", "-1" };
            }
            if (args.Length != 7) {
                return "400 Bad Request";
            }
            string data;
            int[] parms;
            if (!checkAddControlSyntax(args, out data, out parms)) {
                return data;
            }
            Label label = new Label();
            label.Text = msg.Args[2];
            if (parms[2] == -1 && parms[3] == -1) {
                label.AutoSize = true;
            }
            addControl(windows[(IntPtr)parms[4]], label, parms[0], parms[1], parms[2], parms[3]);
            return "201 " + label.Handle;
        }

        public string ControlSetText(TMessage msg) {
            if (msg.Length != 3) {
                return "400 Bad Request";
            }
            int tmp;
            if (!int.TryParse(msg.Args[1], out tmp)) {
                return "400 Bad Request: Argument 1 is not a valid handle";
            }
            IntPtr hwnd = (IntPtr)tmp;
            Dictionary<IntPtr, ControlInfo> controls = this.Controls;
            if (!controls.ContainsKey(hwnd)) {
                return "404 The control is either does not exist or is not managed.";
            }
            controls[hwnd].Text = msg.Args[2];
            return "200 OK";
        }

        public string ControlGetText(TMessage msg) {
            if (msg.Args.Length != 2) {
                return "400 Bad Request";
            }
            int tmp;
            if (!int.TryParse(msg.Args[1], out tmp)) {
                return "400 Bad Request: Argument 1 is not a valid handle";
            }
            IntPtr hwnd = (IntPtr)tmp;
            Dictionary<IntPtr, ControlInfo> controls = this.Controls;
            if (!controls.ContainsKey(hwnd)) {
                return "404 The control either does not exist or is not managed.";
            }
            return "200 " + controls[hwnd].Text;
        }

        public string GuiSetDefaultButton(TMessage msg) {
            if (msg.Args.Length != 3) {
                return "400 Bad Request";
            }
            int tmp;
            if (!int.TryParse(msg.Args[1], out tmp)) {
                return "400 Bad Request: Argument 1 is not a valid handle";
            }
            IntPtr wind = (IntPtr)tmp;
            if (!int.TryParse(msg.Args[2], out tmp)) {
                return "400 Bad Request: Argument 2 is not a valid handle";
            }
            IntPtr control = (IntPtr)tmp;
            if (!windows.ContainsKey(wind)) {
                return "404 The window either does not exist or is not managed.";
            }
            Dictionary<IntPtr, ControlInfo> controls = this.Controls;
            if (!controls.ContainsKey(control)) {
                return "404 The control either does not exist or is not managed.";
            }
            windows[wind].Form.AcceptButton = (Button)controls[control].Control;
            return "200 OK";
        }

        private bool checkAddControlSyntax(string[] args, out string data, out int[] parms) {
            int x, y, w, h, hwnd;
            data = null;
            parms = null;
            if (!int.TryParse(args[1], out hwnd)) {
                data = "400 Bad Request: Argument 1 not int";
                return false;
            }
            if (!int.TryParse(args[3], out x)) {
                data = "400 Bad Request: Argument 3 not int";
                return false;
            }
            if (!int.TryParse(args[4], out y)) {
                data = "400 Bad Request: Argument 4 not int";
                return false;
            }

            if (!int.TryParse(args[5], out w)) {
                data = "400 Bad Request: Argument 5 not int";
                return false;
            }
            if (!int.TryParse(args[6], out h)) {
                data = "400 Bad Request: Argument 6 not int";
                return false;
            }
            if (!windows.ContainsKey((IntPtr)hwnd)) {
                data = "404 Window does not exist or is not managed";
                return false;
            }
            parms = new int[] { x, y, w, h, hwnd };
            return true;
        }

        private void addControl(FormInfo form, Control control, int x, int y, int width, int height) {
            control.Location = new Point(x, y);
            if (width > -1) {
                control.Size = new Size(width, control.Size.Height);
            }
            if (height > -1) {
                control.Size = new Size(control.Size.Width, height);
            }
            form.AddControl(new ControlInfo(control, userLib));
        }
    }
}
