﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tcpservr.BASIC {
    class FormLoader : ApplicationContext {

        private Interpreter interpreter;

        public FormLoader(Interpreter interpreter) {
            this.interpreter = interpreter;
            Application.ApplicationExit += new EventHandler(Application_ApplicationExit);
            interpreter.FormLibrary.AllDisposed += new AllDisposedEventHandler(formLib_AllDisposed);
            interpreter.FormLibrary.ClearDisposed();
            interpreter.OnUserExitRequest += new UserHasExittedEventHandler(interpreter_OnUserExitRequest);
        }

        private void interpreter_OnUserExitRequest(object sender, EventArgs e) {
            ExitThread();
        }

        private void Application_ApplicationExit(object sender, EventArgs e) {
            ExitThread();
        }

        private void formLib_AllDisposed(object sender, EventArgs e) {
            ExitThread();
        }

    }
}
