﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tcpservr.BASIC {
    public partial class GUI : Form {

        public GUI(FormLibrary formManager, string title, int width, int height, int left, int top, string parent) {
            InitializeComponent();
            this.Text = title;
            if (width == -1) {
                width = 300;
            }
            if (height == -1) {
                height = 300;
            }
            if (left == -1) {
                left = (Screen.PrimaryScreen.Bounds.Width - width) / 2;
            }
            if (top == -1) {
                top = (Screen.PrimaryScreen.Bounds.Height - height) / 2;
            }
            this.Size = new Size(width, height);
            this.Location = new Point(left, top);
            if (parent != null) {
                int iHwnd;
                if (!int.TryParse(parent, out iHwnd)) {
                    throw new Exception("Unable to parse parent handle!");
                }
                this.Parent = formManager[(IntPtr)iHwnd].Form;
            }
        }
    }
}
