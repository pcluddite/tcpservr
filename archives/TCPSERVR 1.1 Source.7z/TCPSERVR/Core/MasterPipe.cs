﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Security.Principal;
using System.Threading;
using Tcpservr.Errors;

namespace Tcpservr {
    public class MasterPipe {
        public Dictionary<string, string> Users;
        private TCPSERVR tcpservr;

        public MasterPipe(TCPSERVR tcpservr) {
            this.Users = new Dictionary<string, string>();
            this.tcpservr = tcpservr;
        }

        public void BeginStart() {
            Thread t = new Thread(this.Start);
            t.Start();
        }

        public void Start() {
            try {
                PipeSecurity ps = new PipeSecurity();
                var sid = new SecurityIdentifier(WellKnownSidType.WorldSid, null);
                NTAccount account = (NTAccount)sid.Translate(typeof(NTAccount));
                ps.SetAccessRule(
                    new PipeAccessRule(account, PipeAccessRights.ReadWrite,
                        System.Security.AccessControl.AccessControlType.Allow));

                NamedPipeServerStream server = new NamedPipeServerStream("TCPSERVR",
                    PipeDirection.InOut, 254, PipeTransmissionMode.Message, PipeOptions.None, 16384, 16384, ps);

                while (true) {
                    server.WaitForConnection();
                    byte[] data;
                    TReceiver receiver = new TReceiver(server, server);
                    int len = receiver.Receive(out data);

                    if (len == -1) {
                        server.Disconnect();
                        continue;
                    }

                    TMessage pMsg = new TMessage();
                    pMsg.Process(data);

                    TResponse response = new TResponse(pMsg);

                    try {

                        switch (pMsg.Args[0].ToUpper()) {
                            case "REGISTER":
                                pMsg.ConfirmArgumentCount(3);
                                string user = pMsg.Args[1];
                                string pipe = pMsg.Args[2];
                                if (Users.ContainsKey(user)) {
                                    if (!Libraries.PipeLibrary.PipeExists(Users[user])) {
                                        Users[user] = pipe;
                                        response.Process(200, "OK");
                                    }
                                    else {
                                        throw new TException(409, "User already registered");
                                    }
                                }
                                else {
                                    Users.Add(user, pipe);
                                    response.Process(200, "OK");
                                }
                                break;
                            case "CHANGEPIPE":
                                pMsg.ConfirmArgumentCount(3);
                                int id = pMsg.GetArgumentInt(1);
                                if (!tcpservr.Threads.Contains(id)) {
                                    throw new TException(404, "thread");
                                }
                                if (pMsg.Args[2].Equals("")) {
                                    tcpservr.Threads[id].UsingPipe = false;
                                }
                                else {
                                    tcpservr.Threads[id].CurrentPipeName = pMsg.Args[2];
                                    tcpservr.Threads[id].UsingPipe = true;
                                }
                                response.Process(200, "Pipe has been set on thread " + id);
                                break;
                            case "HELLO":
                                response.Process(200, "Hello!");
                                break;
                            case "QUIT":
                                Environment.Exit(200);
                                break;
                            case "GETUSERS":
                                string users = "";
                                foreach (var v in Users) {
                                    users += v.Key + "|" + v.Value + "\r\n";
                                }
                                response.Process(200, users.Trim());
                                break;
                            default:
                                throw new TException(501, pMsg.Args[0].ToUpper());
                        }
                    }
                    catch (Exception ex) {
                        response.Process(TException.GetMessage(ex));
                    }
                    server.Write(response.Data, 0, response.Length);
                    server.WaitForPipeDrain();
                    server.Disconnect();
                }
            }
            catch (Exception ex) {
                if (Program.DEBUG) {
                    throw;
                }
                new LoggedError("TCPSERVR", ex, true, false).Write();
            }
        }
    }
}
