﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Tcpservr.Errors;

namespace Tcpservr {
    class Program {
        public const bool DEBUG = false;
        public const string VER = "Tcpservr [Version 1.1.2014]";


        public static readonly string ApplicationPath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase).Remove(0, 6);
        public static readonly string SettingsPath = Program.ApplicationPath + "\\Settings.ini";

        public static void Main(string[] args) {

            TCPSERVR server = new TCPSERVR();

            if (args.Length == 1) {
                if (args[0].Equals("-START", StringComparison.OrdinalIgnoreCase)) {
                    try {
                        server.Start();
                    }
                    catch (Exception ex) {
                        if (ex.TargetSite.Name == "DoBind") {
                            SlaveMode offline = new SlaveMode(server);
                            offline.Start();
                            return;
                        }
                        if (Program.DEBUG) {
                            throw ex;
                        }
                        new LoggedError("--", ex, true, true).Write();
                    }
                }
                else if (File.Exists(args[0])) {
                    try {
                        BASIC.TBASIC tbasic = new BASIC.TBASIC(server);
                        tbasic.Initialize(File.ReadAllLines(args[0]));
                    }
                    catch (Exception ex) {
                        MessageBox.Show(ex.Message, "Scripting Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                return;
            }
            else if (args.Length > 1) {
                if (Installer.TryInstall(args)) {
                    return;
                }
                else if (Installer.TryRemove(args)) {
                    return;
                }
                else if (args[0].Equals("-R", StringComparison.OrdinalIgnoreCase)) {
                    Process p = new Process();
                    p.StartInfo.FileName = args[1];
                    if (args.Length > 3) {
                        StringBuilder nArgs = new StringBuilder(args[3]);
                        for (int i = 4; i < args.Length; i++) {
                            nArgs.Append(" \"" + args[i] + "\"");
                        }
                        p.StartInfo.Arguments = nArgs.ToString();
                    }
                    p.Start();
                }
                else if (args.Length > 3 && args[0].Equals("-M", StringComparison.OrdinalIgnoreCase)) {
                    TMessage msg = new TMessage();
                    msg.Process("MSGBOX", args[1], args[2], args[3]);
                    Libraries.CommunicationsLibrary.MsgBox(msg);
                }
                return;
            }
            
            MessageBox.Show("The arguments passed to this program were invalid.", "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public static void CleanResources() {
            string[] resources = new string[] { 
                Path.GetTempPath() + "\\thelper.exe",
                Path.GetTempPath() + "\\7za.exe",
                Application.StartupPath + "\\Updater.exe"
            };
            foreach (string path in resources) {
                try {
                    if (File.Exists(path)) {
                        File.Delete(path);
                    }
                }
                catch (Exception ex) {
                    new LoggedError("CleanResources", ex, false, false).Write();
                }
            }
        }
    }
}