﻿using System;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Tcpservr.Errors;
using Tcpservr.Libraries;
using Tcpservr.Threads;

namespace Tcpservr
{
    public class TCPSERVR {

        public string ApplicationDirectory {
            get {
                return Program.ApplicationPath;
            }
        }

        public string ExecutablePath {
            get {
                return System.Windows.Forms.Application.ExecutablePath;
            }
        }

        private TcpListener listener;
        private LibraryCollection commands;

        public string PrivateKey;

        public bool IsSecure {
            get {
                return PrivateKey != null;
            }
        }

        public ThreadCollection Threads;
        public LoggedErrorCollection ErrorLog;

        private MasterPipe masterPipe;
        public MasterPipe MasterPipe {
            get {
                return masterPipe;
            }
        }

        public bool LogHistory { get; set; }
        
        public ThreadInfo CurrentThread {
            get {
                if (Threads.Contains(Thread.CurrentThread.ManagedThreadId)) {
                    return Threads[Thread.CurrentThread.ManagedThreadId];
                }
                else {
                    return null;
                }
            }
        }

        public TCPSERVR() {
            Threads = new ThreadCollection();
            commands = new LibraryCollection(this, true);
            Directory.SetCurrentDirectory(ApplicationDirectory);
            GlobalPipe = "";
            UsingGlobalPipe = false;
            LogHistory = init.GetDoLogHistory();
        }

        private Initializer init = new Initializer();

        public void Start() {
            masterPipe = new MasterPipe(this);
            ErrorLog = new LoggedErrorCollection(10);

            listener = new TcpListener(init.GetEndpoint());
            PrivateKey = init.GetPrivateKey();

            Thread cleaner = new Thread(new ThreadStart(Program.CleanResources));
            cleaner.Start();

            listener.Start();
            masterPipe.BeginStart();

            while (true) {
                TcpClient client = listener.AcceptTcpClient();
                ThreadInfo tInfo = new ThreadInfo(client.Client, LogHistory, new Thread(handleClient));
                Threads.Add(tInfo);
                tInfo.Start(client);
            }
        }

        public string GlobalPipe;
        public bool UsingGlobalPipe;

        private readonly string[] MASTERWORDS = new string[] { "USER", "PIPESETUSER", "PIPELISTUSERS" };

        private void handleClient(object Client) {
            int msgId = 0;
            ThreadInfo thread = CurrentThread;
            TcpSecure security = null;
            try {
                int bytes;
                thread.CurrentPipeName = GlobalPipe;
                thread.UsingPipe = UsingGlobalPipe;
                Stream stream = (Client as TcpClient).GetStream();
                //CryptoStream decryptorStream = null;
                //CryptoStream encryptorStream = null;
                bool isSecure = (PrivateKey != null);
                TReceiver receiver;
                if (isSecure) {
                    security = new TcpSecure(PrivateKey);
                    //encryptorStream = security.CreateEncryptorStream(stream);
                    //decryptorStream = security.CreateDecryptorStream(stream);
                    //receiver = new TReceiver(encryptorStream, decryptorStream);
                }
                //else {
                    receiver = new TReceiver(stream);
                //}
                bool doEncrypt = isSecure;
                byte[] data;
                while ((bytes = receiver.Receive(out data)) != 0) {

                    #region Manage Invalid
                    if (bytes < 0) {
                        Http http = new Http(receiver.GetWriteStream(), Encoding.UTF8.GetString(data));
                        http.SendWebpage();
                        break;
                    }
                    #endregion

                    TMessage tMsg = new TMessage(msgId++);
                    tMsg.Process(data);

                    TResponse response = new TResponse(tMsg);
                    #region Security
                    
                    if (isSecure) {
                        try {
                            if (tMsg.IsEncrypted) {
                                tMsg.Process(security.Decrypt(tMsg.Data), true);
                            }
                            else {
                                throw new TException(401, "The server requires messages to be encrypted");
                            }
                        }
                        catch(Exception ex) {
                            doEncrypt = false;
                            security = new TcpSecure(PrivateKey);
                            tMsg.Process("[ Unreadable Message ]");
                            response.Process(TException.GetMessage(ex));
                            goto Write;
                        }
                    }
                    #endregion

                    thread.CreateReport(tMsg);

                    string msg = tMsg.DataString;
                    string cmd = tMsg.Args[0].ToUpper();

                    AddTask("Processing " + cmd);

                    try {
                        switch (cmd) {
                            #region USINGPIPE
                            case "USINGPIPE":
                                if (tMsg.Args.Length == 1) {
                                    response.Process(200, (thread.UsingPipe + " " + thread.CurrentPipeName).Trim());
                                    goto Write;
                                }
                                if (tMsg.Args.Length == 2) {
                                    tMsg.AppendArguments("False");
                                }
                                tMsg.ConfirmArgumentCount(3);
                                thread.CurrentPipeName = tMsg.Args[1];
                                if (tMsg.GetArgumentBool(2)) {
                                    GlobalPipe = thread.CurrentPipeName;
                                    UsingGlobalPipe = !GlobalPipe.Equals("");
                                }
                                if (tMsg.Args[1].Equals("")) {
                                    thread.UsingPipe = false;
                                    response.Process(200, "No pipe being used");
                                }
                                else {
                                    thread.UsingPipe = true;
                                    response.Process(202, "Now piping commands through '" + tMsg.Args[1] + "'");
                                }
                                goto Write;
                            #endregion
                            #region END
                            case "END":
                                response.Process(202, "Remote application will now exit. Do not reconnect.");
                                if (doEncrypt) {
                                    response.ProcessEncrypted(
                                        security.Encrypt(response.Data.Skip(7).ToArray())
                                        );
                                }
                                receiver.Send(response.Data);
                                receiver.Dispose();
                                listener.Stop();
                                Program.CleanResources();
                                Environment.Exit(200);
                                break;
                            #endregion
                            #region RESTART
                            case "RESTART":
                                Program.CleanResources();
                                if (File.Exists(this.ApplicationDirectory + "\\tcpservr2.EXE")) {
                                    response.Process((new TException(409, "Could not delete existing file 'tcpservr2.exe'")).Message);
                                    goto Write;
                                }
                                File.Copy(this.ExecutablePath, this.ApplicationDirectory + "\\tcpservr2.exe");
                                TMessage restart = new TMessage();
                                restart.Process("UPDATE");
                                Libraries.ServerLibrary updater = new Libraries.ServerLibrary(this);
                                if (!updater.Update(restart).StartsWith("202")) {
                                    response.Process(409, "Unknown conflict");
                                    goto Write;
                                }
                                response.Process(202, "Attempting to restart. Please wait a few minutes to reconnect.");
                                if (doEncrypt) {
                                    response.ProcessEncrypted(
                                        security.Encrypt(response.Data.Skip(7).ToArray())
                                        );
                                }
                                receiver.Send(response.Data);
                                receiver.Dispose();
                                listener.Stop();
                                Environment.Exit(200);
                                break;
                            #endregion
                        }
                    }
                    catch (Exception ex) {
                        response.Process(TException.GetMessage(ex));
                        goto Write;
                    }
                    if (!thread.UsingPipe || MASTERWORDS.Contains(cmd)) {
                        AddTask("Retrieving response from master application");
                        response = GetResponse(response, true);
                    }
                    else {
                        AddTask("Retrieving response from slave application");
                        response.Process(PipeLibrary.PipeUse(thread.CurrentPipeName, tMsg, CurrentThread));
                        #region Error
                        if (response.Status == 502) {
                            StringBuilder errorResponse = new StringBuilder();
                            errorResponse.AppendLine("Cannot operate on the current pipe: " + response.Message);
                            errorResponse.AppendLine("Defaulting to main client");
                            thread.UsingPipe = false;
                            if (UsingGlobalPipe && thread.CurrentPipeName.Equals(GlobalPipe)) {
                                UsingGlobalPipe = false;
                                errorResponse.AppendLine("New connections will not use this pipe");
                            }
                            response.Process(502, errorResponse.ToString());
                        }
                        #endregion
                    }
                Write:
                    AddTask("Sending '" + response.Message.Replace("\r\n", "\n").Replace("\n", " ").Roof(35) + "'");
                    if (doEncrypt) {
                        response.ProcessEncrypted(security.Encrypt(response.Data.Skip(7).ToArray()));
                        //response.ProcessEncrypted(response.Data.Skip(7).ToArray());
                    }
                    receiver.Send(response.Data);
                    if (isSecure) {
                        doEncrypt = true;
                    }
                    AddTask("Waiting for message");
                    thread.CompletedReport(tMsg);
                    if (thread.ForceGarbageCollection) {
                        GC.Collect();                        
                        thread.ForceGarbageCollection = false;
                    }
                }
                receiver.Dispose();
            }
            catch (Exception ex) {
                if (Program.DEBUG) {
                    throw;
                }
                CurrentThread.AddTask("Failing: " + ex.Message);
                LoggedError error = new LoggedError(CurrentThread.Client + ":" + CurrentThread.Port, ex, true, false);
                if (ex.GetType() != typeof(IOException)) {
                    error.Write();
                }
                ErrorLog.Add(error);
            }
            finally {
                CurrentThread.End();
                if (security != null) {
                    security.Dispose();
                }
            }
        }

        public TResponse GetResponse(TResponse response, bool isMaster) {
            if (isMaster != commands.IsMaster) {
                commands.IsMaster = isMaster;
            }
            try {
                string cmd = response.Original.Args[0].ToLower();
                if (commands.ContainsKey(cmd)) {
                    CurrentThread.AddTask("Found in the main library. Processing");
                    response.Process(commands[cmd].Invoke(response.Original));
                }
                else if (commands.PipeLibrary.ContainsKey(cmd)) {
                    CurrentThread.AddTask("Found in the pipe library. Processing");
                    response.Process(commands.PipeLibrary[cmd].Invoke(response.Original));
                }
                else {
                    throw new TException(501, response.Original.Args[0].ToUpper());
                }
                if (cmd.Equals("put")) {
                    CurrentThread.AddTask("Truncating PUT header");
                    TMessage newMsg = new TMessage();
                    newMsg.Process(response.Original.Args[0], response.Original.Args[1]);
                    TResponse newResponse = new TResponse(newMsg);
                    newResponse.Process(response.Status, response.Message);
                    response.Process(newResponse.Data);
                }
            }
            catch (Exception ex) {
                if (Program.DEBUG) {
                    throw;
                }
                response.Process(TException.GetMessage(ex));
                CurrentThread.AddTask("Processing exception: " + response.Message);
            }
            return response.Clone();
        }

        public void AddTask(string task) {
            if (CurrentThread != null) {
                CurrentThread.AddTask(task);
            }
        }

        public string GetRealPath(string path) {
            if (path.Equals("\\")) {
                path = Path.GetPathRoot(CurrentThread.CurrentDirectory);
            }
            else if (path.StartsWith("\\")) {
                path = Path.Combine(Path.GetPathRoot(CurrentThread.CurrentDirectory), path.Remove(0, 1));
            }
            if (!Path.IsPathRooted(path)) {
                path = Path.Combine(CurrentThread.CurrentDirectory, path);
            }
            return Path.GetFullPath(path);
        }
    }
}
