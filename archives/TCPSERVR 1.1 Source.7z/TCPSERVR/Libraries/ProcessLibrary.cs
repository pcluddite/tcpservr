﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Security;
using Tcpservr.Errors;

namespace Tcpservr.Libraries {
    public class ProcessLibrary : TcpservrLibrary {

        public ProcessLibrary(TCPSERVR tcpservr)
            : base(tcpservr) {
        }

        public override Dictionary<string, Command> GetLibrary() {
            Dictionary<string, Command> lib = new Dictionary<string, Command>();
            lib.Add("run", new Command(Run));
            lib.Add("runas", new Command(RunWithInfo));
            lib.Add("processclose", new Command(ProcessClose));
            lib.Add("processkill", new Command(ProcessKill));
            lib.Add("processexists", new Command(ProcessExists));
            lib.Add("blockedlist", new Command(BlockedList));
            lib.Add("block", new Command(Block));
            lib.Add("unblock", new Command(Unblock));
            lib.Add("processlist", new Command(ProcessList));
            return lib;
        }

        public string ProcessExists(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            foreach (Process p in Process.GetProcesses()) {
                if (p.ProcessName.ToLower().CompareTo(tMsg.Args[1].ToLower()) == 0) {
                    return "200 True";
                }
            }
            return "200 False";
        }

        public string ProcessList(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            StringBuilder sb = new StringBuilder("200 ");
            foreach (Process p in Process.GetProcesses()) {
                sb.AppendLine(p.ProcessName);
            }
            return sb.ToString().Trim();
        }

        public string ProcessKill(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            foreach (Process p in Process.GetProcesses()) {
                if (p.ProcessName.ToLower().CompareTo(tMsg.Args[1].ToLower()) == 0) {
                    p.Kill();
                    return "204 No Content";
                }
            }
            throw new TException(404);
        }

        public string ProcessClose(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            foreach (Process p in Process.GetProcesses()) {
                if (p.ProcessName.ToLower().CompareTo(tMsg.Args[1].ToLower()) == 0) {
                    p.Close();
                    return "204 No Content";
                }
            }
            throw new TException(404);
        }

        public string BlockedList(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            string[] list =  BlockedList();
            if (list.Length > 0) {
                return "200 " + string.Join("\r\n", list);
            }
            else {
                throw new TException(204, "No applications blocked");
            }
        }

        private string[] BlockedList() {
            using (RegistryKey imgKey = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options")) {
                List<string> blocked = new List<string>();
                foreach (string s in imgKey.GetSubKeyNames()) {
                    using (RegistryKey app = imgKey.OpenSubKey(s)) {
                        if (app.GetValueNames().Contains("Debugger")) {
                            blocked.Add(s + "\n" +
                                        (string)app.GetValue("Debugger"));
                        }
                    }
                }
                return blocked.ToArray();
            }
        }

        private bool IsBlocked(string app) {
            foreach (string s in BlockedList()) {
                if (app.Equals(s.Split('\n')[0], System.StringComparison.OrdinalIgnoreCase)) {
                    return true;
                }
            }
            return false;
        }

        public string Block(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                tMsg.AppendArguments("/m", "16", "The application you requested has been blocked.", "Blocked");
            }
            if (tMsg.Args.Length != 4 && tMsg.Args.Length != 6) {
                tMsg.ConfirmArgumentCount(6);
            }
            string app = tMsg.Args[1];
            if (!app.Contains(".")) { 
                app += ".exe"; 
            }
            string key = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\" + app;
            switch (tMsg.Args[2].ToLower()) {
                case "/m":
                    Registry.LocalMachine.CreateSubKey(key);
                    Registry.SetValue("HKEY_LOCAL_MACHINE\\" + key, "Debugger", "\"" + Application.ExecutablePath + "\" -m \"" + tMsg.GetArgument(3) + "\" \"" + tMsg.GetArgument(4) + "\" \"" + tMsg.GetArgument(5) + "\"");
                    return "200 " + app + " was successfully blocked.";
                case "/r":
                    Registry.LocalMachine.CreateSubKey(key);
                    Registry.SetValue("HKEY_LOCAL_MACHINE\\" + key, "Debugger", "\"" + Application.ExecutablePath + "\" -r \"" + tMsg.GetArgument(3) + "\"");
                    return "200 " + app + " was successfully redirected.";
                case "/d":
                    Registry.LocalMachine.CreateSubKey(key);
                    Registry.SetValue("HKEY_LOCAL_MACHINE\\" + key, "Debugger", "\"" + tMsg.GetArgument(3) + "\"");
                    return "200 " + app + " was successfully redirected.";
                default:
                    throw new TException(400, "Invalid switch - " + tMsg.Args[2]);
            }
        }

        public string Unblock(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            string[] args = tMsg.Args;
            if (!args[1].Contains(".")) { 
                args[1] += ".exe";
            }
            if (!IsBlocked(args[1])) {
                throw new TException(404);
            }
            string keyName = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\" + args[1];
            using (RegistryKey key = Registry.LocalMachine.OpenSubKey(keyName, true)) {
                key.DeleteValue("Debugger");
            }
            return "200 " + args[1] + " was successfully unblocked";
        }

        public string RunWithInfo(TMessage tMsg) {
            if (tMsg.Args.Length < 2) {
                tMsg.ConfirmArgumentCount(3);
            }
            tcpservr.AddTask("Processing RUN parameters");
            Dictionary<string, string> args = tMsg.GetLooseArgs('=');            
            if (!args.ContainsKey("file")) {
                throw new TException(400, "No file specified");
            }
            ProcessStartInfo startInfo = new ProcessStartInfo(args["file"]);
            if (args.ContainsKey("args")) {
                startInfo.Arguments = args["args"];
            }
            if (args.ContainsKey("dir")) {
                startInfo.WorkingDirectory = args["dir"];
            }
            else {
                startInfo.WorkingDirectory = tcpservr.CurrentThread.CurrentDirectory;
            }
            if (args.ContainsKey("user")) {
                startInfo.UseShellExecute = false;
                startInfo.UserName = args["user"];
            }
            if (args.ContainsKey("pass")) {
                startInfo.UseShellExecute = false;
                SecureString pass = new SecureString();
                foreach (char c in args["pass"].ToCharArray()) {
                    pass.AppendChar(c);
                }
                startInfo.Password = pass;
            }
            if (args.ContainsKey("domain")) {
                startInfo.UseShellExecute = false;
                startInfo.Domain = args["domain"];
            }
            if (args.ContainsKey("style")) {
                string style = args["style"].ToUpper();
                foreach (char c in style.ToCharArray()) {
                    switch (c) {
                        case 'H':
                            startInfo.WindowStyle = startInfo.WindowStyle | ProcessWindowStyle.Hidden;
                            break;
                        case 'X':
                            startInfo.WindowStyle = startInfo.WindowStyle | ProcessWindowStyle.Maximized;
                            break;
                        case 'M':
                            startInfo.WindowStyle = startInfo.WindowStyle | ProcessWindowStyle.Minimized;
                            break;
                        case 'N':
                            startInfo.WindowStyle = startInfo.WindowStyle | ProcessWindowStyle.Normal;
                            break;
                        default:
                            throw new TException(400, "'" + c + "' not a valid style code");
                    }
                }
            }
            Run(startInfo, false);
            return "202 Accepted";
        }

        public string Run(TMessage tMsg) {
            string[] args = tMsg.Args;
            if (args.Length < 2) {
                throw new TException(400);
            }
            tcpservr.AddTask("Initializing process start information");
            ProcessStartInfo startInfo = new ProcessStartInfo(tMsg.Args[1]);
            startInfo.Arguments = tMsg.DataString.Remove(0, tMsg.Args[0].Length + tMsg.Args[1].Length + 1).Trim();
            Run(startInfo, false);
            return "202 Accepted";
        }

        public string Run(ProcessStartInfo info, bool wait) {
            tcpservr.AddTask("Initializing new process");
            using (Process p = new Process()) {
                p.StartInfo = info;
                tcpservr.AddTask("Running process");
                p.Start();
                string result = null;
                if (p.StartInfo.RedirectStandardOutput) {
                    tcpservr.AddTask("Redirecting standard output");
                    result = p.StandardOutput.ReadToEnd();
                }
                if (wait) {
                    tcpservr.AddTask("Waiting for process to exit");
                    p.WaitForExit();
                }
                return result;
            }
        }
    }
}