﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Tcpservr.Borrowed;
using Tcpservr.Errors;
using System.Linq;

namespace Tcpservr.Libraries {

    class WindowLibrary : TcpservrLibrary {

        private WindowFlag windowFlags;

        public WindowLibrary(TCPSERVR tcpservr)
            : base(tcpservr) {
                windowFlags = new WindowFlag();
        }

        public override Dictionary<string, Command> GetLibrary() {
            Dictionary<string, Command> lib = new Dictionary<string, Command>();
            lib.Add("winactivate", WinActivate);
            lib.Add("winclose", WinClose);
            lib.Add("winkill", WinKill);
            lib.Add("winmove", WinMove);
            lib.Add("winsize", WinSize);
            lib.Add("wingethandle", WinGetHandle);
            lib.Add("wingettitle", WinGetTitle);
            lib.Add("winsettitle", WinSetTitle);
            lib.Add("winsettrans", WinSetTrans);
            lib.Add("winsetstate", WinSetState);
            lib.Add("winlistinfo", WinListInfo);
            lib.Add("wininfo", WinInfo);
            lib.Add("winlist", WinList);
            lib.Add("removex", disableX);
            lib.Add("getscreen", GetScreen);
            lib.Add("winpicture", WinPicture);
            lib.Add("winexists", WindowExists);
            return lib;
        }

        [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        static extern bool SetWindowText(IntPtr hwnd, String lpString);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static extern int GetWindowTextLength(IntPtr hWnd);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool GetWindowPlacement(IntPtr hWnd, out WINDOWPLACEMENT lpwndpl);

        private struct WINDOWPLACEMENT {
            public int length;
            public int flags;
            public int showCmd;
            public System.Drawing.Point ptMinPosition;
            public System.Drawing.Point ptMaxPosition;
            public System.Drawing.Rectangle rcNormalPosition;
        }

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool ShowWindow(IntPtr hWnd, uint nCmdShow);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT {
            public int Left;        // x position of upper-left corner
            public int Top;         // y position of upper-left corner
            public int Right;       // x position of lower-right corner
            public int Bottom;      // y position of lower-right corner
        }

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, int uFlags);

        public class HWND {
            public static IntPtr
            NoTopMost = new IntPtr(-2),
            TopMost = new IntPtr(-1),
            Top = new IntPtr(0),
            Bottom = new IntPtr(1);
        }

        public class SWP {
            public static readonly int
            NOSIZE = 0x0001,
            NOMOVE = 0x0002,
            NOZORDER = 0x0004,
            NOREDRAW = 0x0008,
            NOACTIVATE = 0x0010,
            DRAWFRAME = 0x0020,
            FRAMECHANGED = 0x0020,
            SHOWWINDOW = 0x0040,
            HIDEWINDOW = 0x0080,
            NOCOPYBITS = 0x0100,
            NOOWNERZORDER = 0x0200,
            NOREPOSITION = 0x0200,
            NOSENDCHANGING = 0x0400,
            DEFERERASE = 0x2000,
            ASYNCWINDOWPOS = 0x4000;
        }

        [DllImport("user32.dll")]
        static extern bool DestroyWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        static extern bool SetLayeredWindowAttributes(IntPtr hwnd, uint crKey, byte bAlpha, uint dwFlags);

        [DllImport("user32.dll", SetLastError = true)]
        static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        public const int GWL_EXSTYLE = -20;
        public const int WS_EX_LAYERED = 0x80000;
        public const int LWA_ALPHA = 0x2;
        public const int LWA_COLORKEY = 0x1;

        [DllImport("user32.dll")]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);

        const int MF_BYPOSITION = 0x400;

        [DllImport("User32")]
        private static extern int RemoveMenu(IntPtr hMenu, int nPosition, int wFlags);

        [DllImport("User32")]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [DllImport("User32")]
        private static extern int GetMenuItemCount(IntPtr hWnd);

        public string disableX(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            IntPtr handle = new IntPtr(tMsg.GetArgumentInt(1));
            IntPtr hMenu = GetSystemMenu(handle, false);
            int menuItemCount = GetMenuItemCount(hMenu);
            RemoveMenu(hMenu, menuItemCount - 1, MF_BYPOSITION);
            return "200 OK";
        }

        public string WinGetHandle(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            IntPtr hwnd = FindWindow(null, tMsg.Args[1]);
            return "200 " + hwnd.ToInt32().ToString();
        }

        public string WinGetTitle(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            return "200 " + WinGetTitle(new IntPtr(tMsg.GetArgumentInt(1)));
        }

        /// <summary>
        /// Gets the title of a window
        /// </summary>
        /// <param name="hwnd">The handle of the window</param>
        /// <returns></returns>
        public static string WinGetTitle(IntPtr hwnd) {
            int capacity = GetWindowTextLength(hwnd) + 1;
            StringBuilder sb = new StringBuilder(capacity);
            GetWindowText(hwnd, sb, capacity);
            return sb.ToString();
        }

        public string WinSetTitle(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            IntPtr hwnd = new IntPtr(tMsg.GetArgumentInt(1));
            if (SetWindowText(hwnd, tMsg.Args[2])) {
                return "200 OK";
            }
            else {
                throw new TException(500, "Window title was unable to be set");
            }
        }

        public string WinSetState(TMessage tMsg) {
            if (tMsg.Args.Length == 4) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], tMsg.Args[3]);
            }
            tMsg.ConfirmArgumentCount(3);
            uint flag;
            if (!windowFlags.Flags.TryGetValue(tMsg.Args[2], out flag)) {
                throw new TException(400, "arg[2] not window state");
            }
            ShowWindow(new IntPtr(tMsg.GetArgumentInt(1)), flag);
            return "200 OK";
        }

        public string WinInfo(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            return "200 " + WinInfo(new IntPtr(tMsg.GetArgumentInt(1)));
        }

        /// <summary>
        /// Retrieves some general information of a window as a string
        /// </summary>
        /// <param name="handle">The window handle</param>
        /// <returns></returns>
        public string WinInfo(IntPtr handle) {
            string title = WinGetTitle(handle);
            RECT rect = new RECT();
            WINDOWPLACEMENT winPlac = new WINDOWPLACEMENT();
            if (!GetWindowPlacement(handle, out winPlac)) {
                throw new TException(404, "Window");
            }
            GetWindowRect(handle, out rect);
            WinList winLoader = new WinList();
            string[] result = new string[] { 
                title,
                winLoader.WinGetState(handle).ToString(),
                string.Format("Size: {0}x{1}", (rect.Right - rect.Left), (rect.Bottom - rect.Top)),
                string.Format("Location: ({0},{1})", (rect.Right - rect.Left), (rect.Bottom - rect.Top)),
                handle.ToString()
            };
            return string.Join("\n", result);
        }

        public string WinActivate(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            SetForegroundWindow(new IntPtr(tMsg.GetArgumentInt(1)));
            return "200 OK";
        }

        public string WinMove(TMessage tMsg) {
            if (tMsg.Args.Length == 5) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], tMsg.Args[3], tMsg.Args[4]);
            }
            tMsg.ConfirmArgumentCount(4);
            IntPtr hwnd = new IntPtr(tMsg.GetArgumentInt(1));
            RECT rect = new RECT();
            if (!GetWindowRect(hwnd, out rect)) {
                throw new TException(404, "Window");
            }
            if (SetWindowPos(hwnd, HWND.NoTopMost,
                tMsg.GetArgumentInt(2),
                tMsg.GetArgumentInt(3),
                (rect.Right - rect.Left), (rect.Bottom - rect.Top), SWP.NOACTIVATE)) {
                return "200 OK";
            }
            else {
                throw new TException(500, "The window was unable to be moved");
            }
        }

        public string WinSize(TMessage tMsg) {
            if (tMsg.Args.Length == 5) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], tMsg.Args[3], tMsg.Args[4]);
            }
            tMsg.ConfirmArgumentCount(4);
            IntPtr hwnd = new IntPtr(tMsg.GetArgumentInt(1));
            WINDOWPLACEMENT place = new WINDOWPLACEMENT();
            if (!GetWindowPlacement(hwnd, out place)) {
                throw new TException(404, "Window");
            }
            if (SetWindowPos(hwnd, HWND.NoTopMost,
                place.rcNormalPosition.X, place.rcNormalPosition.Y,
                tMsg.GetArgumentInt(2),
                tMsg.GetArgumentInt(3),
                SWP.NOACTIVATE)) {
                return "200 OK";
            }
            else {
                throw new TException(500, "The window was unable to be sized");
            }
        }

        public string WinKill(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            int hwnd = tMsg.GetArgumentInt(1);

            if (DestroyWindow(new IntPtr(hwnd))) {
                return "200 OK";
            }
            else {
                throw new TException(500, "Unable to kill window");
            }
        }

        public string WinClose(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                tMsg.AppendArguments("");
            }
            tMsg.ConfirmArgumentCount(3);
            SendMessage(new IntPtr(tMsg.GetArgumentInt(1)), 0x0112, 0xF060, 0);
            return "202 Accepted";
        }

        public string WinSetTrans(TMessage tMsg) {
            if (tMsg.Length == 4) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], tMsg.Args[3]);
            }
            tMsg.ConfirmArgumentCount(3);
            IntPtr hwnd = new IntPtr(tMsg.GetArgumentInt(1));
            SetWindowLong(hwnd, GWL_EXSTYLE, GetWindowLong(hwnd, GWL_EXSTYLE) ^ WS_EX_LAYERED);
            SetLayeredWindowAttributes(hwnd, 0, tMsg.GetArgumentByte(2), LWA_ALPHA);
            return "200 OK";
        }

        public string WinList(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.Process(tMsg.Args[0], "VISIBLE");
            }
            tMsg.ConfirmArgumentCount(2);
            int state = 0;
            foreach (var v in windowFlags.States) {
                if (v.Key.Equals(tMsg.Args[1], StringComparison.OrdinalIgnoreCase)) {
                    state += v.Value;
                }
            }
            if (state == 0) {
                throw new TException(400, "arg[1] not window state");
            }

            WinList winLoader = new WinList();
            var windows =
                from hwnd in winLoader.List(state)
                let title = WinGetTitle(hwnd)
                where !title.Equals("")
                select title;
            string ret = string.Join("\n", windows.ToArray()).Trim();
            if (ret.Equals("")) {
                return "204 No Content";
            }
            return "200 " + ret;
        }

        public string WinListInfo(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.Process(tMsg.Args[0], "visible");
            }
            tMsg.ConfirmArgumentCount(2);
            int state = 0;
            foreach (var v in windowFlags.States) {
                if (v.Key.Equals(tMsg.Args[1], StringComparison.OrdinalIgnoreCase)) {
                    state += v.Value;
                }
            }
            if (state == 0) {
                throw new TException(400, "arg[1] not window state");
            }

            WinList winLoader = new WinList();

            var windows =
                from hwnd in winLoader.List(state)
                let title = WinGetTitle(hwnd)
                where !title.Equals("")
                select WinInfo(hwnd) + "\n";

            string result = string.Join("\n", windows.ToArray());
            if (result.Trim().Equals("")) {
                return "204 No Content";
            }
            return "200 " + result.Trim();
        }

        public string GetScreen(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);

            int compression = tMsg.GetArgumentInt(1);
            if (compression > 100 || compression < 0) {
                throw new TException(400, "arg[1] must be int between 0 and 100");
            }

            ScreenCapture sc = new ScreenCapture();
            Image img = sc.CaptureScreen();
            MemoryStream ms = Compress.DoIt(img, compression);
            return "200 " + Convert.ToBase64String(Initializer.ReadToEnd(ms));
        }

        public string WinPicture(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            int compression = tMsg.GetArgumentInt(2);
            if (compression > 100 || compression < 0) {
                throw new TException(400, "arg[2] must be int between 0 and 100");
            }
            int hwnd = tMsg.GetArgumentInt(1);
            ScreenCapture sc = new ScreenCapture();
            System.Drawing.Image pic = sc.CaptureWindow(new IntPtr(hwnd));
            MemoryStream ms = Compress.DoIt(pic, compression);
            return "200 " + Convert.ToBase64String(Initializer.ReadToEnd(ms));
        }

        public string WindowExists(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            return "200 " + WindowExists(new IntPtr(tMsg.GetArgumentInt(1)));
        }

        private bool WindowExists(IntPtr hwnd) {
            RECT rect;
            return GetWindowRect(hwnd, out rect);
        }
    }

    public class WindowFlag {

        public Dictionary<string, uint> Flags;
        public Dictionary<string, int> States;

        public WindowFlag() {
            Flags = new Dictionary<string, uint>();
            Flags.Add("SW_HIDE", 0);
            Flags.Add("SW_SHOWNORMAL", 1);
            Flags.Add("SW_NORMAL", 1);
            Flags.Add("SW_SHOWMINIMIZED", 2);
            Flags.Add("SW_SHOWMAXIMIZED", 3);
            Flags.Add("SW_MAXIMIZE", 3);
            Flags.Add("SW_SHOWNOACTIVATE", 4);
            Flags.Add("SW_SHOW", 5);
            Flags.Add("SW_MINIMIZE", 6);
            Flags.Add("SW_SHOWMINNOACTIVE", 7);
            Flags.Add("SW_SHOWNA", 8);
            Flags.Add("SW_RESTORE", 9);

            States = new Dictionary<string, int>();
            States.Add("EXISTING", 1);
            States.Add("VISIBLE", 2);
            States.Add("ENABLED", 4);
            States.Add("ACTIVE", 8);
            States.Add("MINIMIZED", 16);
            States.Add("MAXIMIZED", 32);
        }

        public const UInt32 SW_HIDE = 0;
        public const UInt32 SW_SHOWNORMAL = 1;
        public const UInt32 SW_NORMAL = 1;
        public const UInt32 SW_SHOWMINIMIZED = 2;
        public const UInt32 SW_SHOWMAXIMIZED = 3;
        public const UInt32 SW_MAXIMIZE = 3;
        public const UInt32 SW_SHOWNOACTIVATE = 4;
        public const UInt32 SW_SHOW = 5;
        public const UInt32 SW_MINIMIZE = 6;
        public const UInt32 SW_SHOWMINNOACTIVE = 7;
        public const UInt32 SW_SHOWNA = 8;
        public const UInt32 SW_RESTORE = 9;
    }
}
