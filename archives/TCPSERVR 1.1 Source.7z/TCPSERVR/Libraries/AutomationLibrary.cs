﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Tcpservr.Errors;

namespace Tcpservr.Libraries
{
    public class AutomationLibrary : TcpservrLibrary
    {
        public AutomationLibrary(TCPSERVR tcpservr)
            : base(tcpservr) {
        }

        public override Dictionary<string, Command> GetLibrary() {
            Dictionary<string, Command> lib = new Dictionary<string, Command>();
            lib.Add("mouseclick", MouseClick);
            lib.Add("blockinput", BlockInput);
            lib.Add("mousemove", MouseMove);
            lib.Add("send", Send);
            lib.Add("volumeup", VolumeUp);
            lib.Add("volumedown", VolumeDown);
            lib.Add("volumemute", VolumeMute);
            lib.Add("webcamcapture", WebCamCapture);
            lib.Add("microphone", Microphone);
            return lib;
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        private static extern void mouse_event(long dwFlags, long dx, long dy, long cButtons, long dwExtraInfo);

        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;
        private const int MOUSEEVENTF_RIGHTDOWN = 0x08;
        private const int MOUSEEVENTF_RIGHTUP = 0x10;

        [DllImport("user32.dll")]
        private static extern bool BlockInput(bool fBlockIt);

        [DllImport("user32.dll")]
        static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);

        public string MouseClick(TMessage tMsg) {
            if (tMsg.Args.Length == 4) {
                tMsg.AppendArguments("1", "1");
            }
            if (tMsg.Args.Length == 5) {
                tMsg.AppendArguments("5");
            }
            tMsg.ConfirmArgumentCount(6);

            int x = tMsg.GetArgumentInt(2),
                y = tMsg.GetArgumentInt(3),
                clicks = tMsg.GetArgumentInt(4),
                speed = tMsg.GetArgumentInt(5);

            int button;
            if (tMsg.GetArgument(1, "button", "LEFT", "RIGHT").Equals("LEFT", StringComparison.OrdinalIgnoreCase)) {
                button = MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP;
            }
            else {
                button = MOUSEEVENTF_RIGHTDOWN | MOUSEEVENTF_RIGHTUP;
            }
            MouseMove(x, y, speed);

            for (int i = 0; i < clicks; i++) {
                mouse_event(button, x, y, 0, 0);
            }
            return "200 OK";
        }

        public string MouseMove(TMessage tMsg) {
            if (tMsg.Args.Length == 3) {
                tMsg.AppendArguments("1");
            }
            tMsg.ConfirmArgumentCount(4);

            int x = tMsg.GetArgumentInt(1),
                y = tMsg.GetArgumentInt(2),
                s = tMsg.GetArgumentInt(3);
            MouseMove(x, y, s);
            return "200 OK";
        }

        private void MouseMove(double endX, double endY, int speed) {
            if (speed == 0) {
                Cursor.Position = new Point((int)(endX + 0.5), (int)(endY + 0.5));
                return;
            }
            else if (speed < 0) {
                throw new TException(400, "Speed must be positive");
            }
            double startX = Cursor.Position.X,
                   startY = Cursor.Position.Y;

            double direction = startX < endX ? 1 : -1;
            double slope = (endY - startY) / (endX - startX);
            speed = (int)(Math.Sqrt(speed));

            double oldX = startX;
            bool finished = false;
            for (double x = startX; !finished; x += direction) {
                double y = slope * (x - startX) + startY;
                int newX = (int)(x + 0.5),
                    newY = (int)(y + 0.5);
                System.Threading.Thread.Sleep(speed);
                oldX = x;
                if (finished = endX.IsBetween(oldX, x)) {
                    Cursor.Position = new Point((int)endX, (int)endY);
                }
                else {
                    Cursor.Position = new Point(newX, newY);
                }
            }
        }

        public string BlockInput(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            tMsg.Process(tMsg.Args[0], tMsg.Args[1].Replace("1", "true").Replace("0", "false"));
            if (BlockInput(tMsg.GetArgumentBool(1))) {
                return "200 OK";
            }
            else {
                throw new TException(500, "Check user priveleges");
            }
        }

        public string Send(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            SendKeys.SendWait(tMsg.Args[1]);
            return "200 OK";
        }

        public string VolumeUp(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.Process(tMsg.Args[0], "1");
            }
            tMsg.ConfirmArgumentCount(2);
            int count = tMsg.GetArgumentInt(1);
            for (int i = 0; i < count; i++) {
                keybd_event((byte)Keys.VolumeUp, 0, 0, 0);
            }
            return "200 OK";
        }

        public string VolumeDown(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.Process(tMsg.Args[0], "1");
            }
            tMsg.ConfirmArgumentCount(2);
            int count = tMsg.GetArgumentInt(1);
            for (int i = 0; i < count; i++) {
                keybd_event((byte)Keys.VolumeDown, 0, 0, 0);
            }
            return "200 OK";
        }

        public string VolumeMute(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            keybd_event((byte)Keys.VolumeMute, 0, 0, 0);
            return "200 OK";
        }

        public string WebCamCapture(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], "500");
            }
            tMsg.ConfirmArgumentCount(3);
            int compression = tMsg.GetArgumentInt(1);
            if (compression < 0 || compression > 100) {
                throw new TException(400, "args[1] must be between 0 and 100");
            }
            byte[] data = Borrowed.ccWebCam.CaptureSTA(tMsg.GetArgumentInt(2));
            try {
                using (MemoryStream img = Borrowed.Compress.DoIt(
                       Image.FromStream(new MemoryStream(data)), compression)) {
                    return "200 " + Convert.ToBase64String(Initializer.ReadToEnd(img));
                }
            }
            catch (ArgumentException) {
                return "404 A web camera may not be enabled on this system.";
            }
            finally {
                Borrowed.ccWebCam.Disconnect();
            }
        }

        public string Microphone(TMessage tMsg) {
            throw new NotImplementedException("Reserved for future use");
        }
    }
}
