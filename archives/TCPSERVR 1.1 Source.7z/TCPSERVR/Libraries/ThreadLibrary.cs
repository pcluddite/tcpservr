﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using Tcpservr.Errors;
using Tcpservr.Threads;

namespace Tcpservr.Libraries {
    class ThreadLibrary : TcpservrLibrary {

        public ThreadLibrary(TCPSERVR tcpservr)
            : base(tcpservr) {
        }

        public override Dictionary<string, Command> GetLibrary() {
            Dictionary<string, Command> lib = new Dictionary<string, Command>();
            lib.Add("threadlist", ThreadList);
            lib.Add("threadlistclean", ThreadListClean);
            lib.Add("threadabort", ThreadAbort);
            lib.Add("threadstate", ThreadState);
            lib.Add("threaddelete", ThreadDelete);
            lib.Add("processthreadlist", ProcessThreadList);
            lib.Add("history", History);
            lib.Add("getreport", GetReport);
            lib.Add("clearhistory", ClearHistory);
            lib.Add("historylog", HistoryLog);
            return lib;
        }

        public string HistoryLog(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                tMsg.Process(tMsg.Args[0], tcpservr.CurrentThread.ID.ToString(), tMsg.Args[1]);
            }
            if (tMsg.Args.Length == 3) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], tMsg.Args[2], "CURRENT");
            }
            tMsg.ConfirmArgumentCount(4);
            int id = tMsg.GetArgumentInt(1);
            if (!tcpservr.Threads.Contains(id)) {
                throw new TException(404, "thread");
            }
            ThreadInfo thread = tcpservr.Threads[id];
            bool threadLog = tMsg.GetArgument(2, "'ON' or 'OFF'", "ON", "OFF").Equals("ON", StringComparison.OrdinalIgnoreCase);
            bool globalLog = tMsg.GetArgument(3, "'ALL' or 'CURRENT'", "ALL", "CURRENT").Equals("ALL", StringComparison.OrdinalIgnoreCase);
            thread.LogHistory = threadLog;
            if (globalLog) {
                tcpservr.LogHistory = threadLog;
            }
            return "200 OK";
        }

        public string History(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.AppendArguments(Thread.CurrentThread.ManagedThreadId.ToString());
            }
            tMsg.ConfirmArgumentCount(2);
            int id = tMsg.GetArgumentInt(1);
            if (!tcpservr.Threads.Contains(id)) {
                throw new TException(404, "thread");
            }
            ThreadInfo thread = tcpservr.Threads[id];
            if (!thread.LogHistory) {
                return "204 History is not being logged for this thread. No reports are available.";
            }
            StringBuilder history = new StringBuilder('|' + ("Message History for Thread " + thread.ID).Center(70));
            history.AppendFormat("\n{0,-8}{1,-40}{2,-20}", "[ ID ]", "[ Message ]", "[ Received ]");
            foreach (var v in thread.Reports) {
                history.AppendFormat("\n{0,6}  {1,-40}{2,-20}", v.Key.ID, v.Key.DataString, v.Key.CreationTime.ToString("HH:mm:ss MM/dd/yyyy"));
            }
            return "200 " + history.ToString();
        }

        public string ClearHistory(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.AppendArguments(Thread.CurrentThread.ManagedThreadId.ToString());
            }
            tMsg.ConfirmArgumentCount(2);
            int id = tMsg.GetArgumentInt(1);
            if (!tcpservr.Threads.Contains(id)) {
                throw new TException(404, "thread");
            }
            ThreadInfo thread = tcpservr.Threads[id];
            thread.Reports.Clear();
            return "200 All reports cleared for thread " + id;
        }

        public string GetReport(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                tMsg.Process(tMsg.Args[0], Thread.CurrentThread.ManagedThreadId.ToString(), tMsg.Args[1]);
            }
            tMsg.ConfirmArgumentCount(3);
            ThreadInfo thread = tcpservr.Threads.GetThread(tMsg.GetArgumentInt(1));
            Report report = thread.Reports.GetReportFromId(tMsg.GetArgumentInt(2));
            return "200 " + report.ToString();
        }

        public string ProcessThreadList(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            return "200 " + tcpservr.Threads.GetProcessThreadList();
        }

        public string ThreadList(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            return "200 " + tcpservr.Threads.GetManagedThreadList();
        }

        public string ThreadDelete(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            int id = tMsg.GetArgumentInt(1);
            if (!tcpservr.Threads.Contains(id)) {
                return "404 Thread not found";
            }
            if (tcpservr.Threads[id].ThreadState != System.Threading.ThreadState.Aborted &&
                tcpservr.Threads[id].ThreadState != System.Threading.ThreadState.Stopped) {
                return "409 Cannot delete thread because thread is running";
            }
            tcpservr.Threads.Remove(id);
            return "200 Thread Removed";
        }

        public string ThreadListClean(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            tcpservr.Threads.Clean();
            return "200 Unused threads removed from record";
        }

        public string ThreadAbort(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            int id = tMsg.GetArgumentInt(1);
            if (!tcpservr.Threads.Contains(id)) {
                return "404 Thread not found";
            }
            tcpservr.Threads[id].Abort();
            return "202 Terminating thread " + id;
        }

        public string ThreadState(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            int id = tMsg.GetArgumentInt(1);
            if (!tcpservr.Threads.Contains(id)) {
                return "404 Thread not found";
            }
            else {
                return "200 " + tcpservr.Threads[id].CurrentTask;
            }
        }
    }
}
