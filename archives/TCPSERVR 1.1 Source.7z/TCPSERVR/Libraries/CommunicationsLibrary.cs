﻿using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Collections.Generic;
using Tcpservr.Errors;

namespace Tcpservr.Libraries
{
    public class CommunicationsLibrary : TcpservrLibrary
    {
        public CommunicationsLibrary(TCPSERVR tcpservr)
            : base(tcpservr) {
        }

        public override Dictionary<string, Command> GetLibrary() {
            Dictionary<string, Command> lib = new Dictionary<string, Command>();
            lib.Add("blockmessage", new Command(BlockMessage));
            lib.Add("traytip", new Command(TrayTip));
            lib.Add("msgbox", new Command(MsgBox));
            lib.Add("say", new Command(Say));
            lib.Add("chat", new Command(Chat));
            return lib;
        }

        public string BlockMessage(TMessage tMsg) {
            if (tMsg.Args.Length == 2) { 
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], "remote");
            }
            tMsg.ConfirmArgumentCount(3);

            if (PipeLibrary.PipeExists("BLOCKMESSAGEPIPE")) {
                throw new TException(409, "A block message is already open");
            }

            switch (tMsg.Args[2].ToLower()) {
                case "remote":
                    new Thread(BlockMessageRemote).Start(tMsg.Args[1]);
                    break;
                case "local":
                    new Thread(BlockMessage).Start(tMsg.Args[1]);
                    break;
                default:
                    throw new TException(400, "arg[2] not 'local' or 'remote'");
            }
            return "202 Accepted";
        }

        public string TrayTip(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(5);
            Thread t = new Thread(TrayTip);
            t.Start(tMsg.Args);
            return "202 Accepted";
        }

        public void TrayTip(object param) {
            try {
                string[] cmd = (string[])param;
                using (NotifyIcon tray = new NotifyIcon()) {
                    tray.Icon = Properties.Resources.Danrabbit_Elementary_Button_info;
                    tray.Visible = true;
                    int timeout;
                    if (!int.TryParse(cmd[1], out timeout)) {
                        timeout = 5000;
                    }
                    ToolTipIcon icon;
                    switch (cmd[4]) {
                        case "1": icon = ToolTipIcon.Info; break;
                        case "2": icon = ToolTipIcon.Warning; break;
                        case "3": icon = ToolTipIcon.Error; break;
                        default: icon = ToolTipIcon.None; break;
                    }
                    tray.ShowBalloonTip(timeout, cmd[2], cmd[3], icon);
                    System.Threading.Thread.Sleep(timeout);
                    tray.Visible = false;
                }
            }
            catch {
            }
        }

        public static string MsgBox(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(4);
            int i = tMsg.GetArgumentInt(1);

            new Thread(MsgBox).Start(tMsg.UnformattedDataString.Remove(0, 6).Trim());
            return "202 Accepted";
        }

        private void BlockMessage(object msg) {
            BlockInput b = new BlockInput((string)msg);
            b.ShowDialog();
        }

        private void BlockMessageRemote(object msg) {
            try {
                using (Process p = new Process()) {
                    p.StartInfo.FileName = GetHelperPath();
                    TMessage args = new TMessage();
                    args.Process("BLOCKMESSAGE", (string)msg);
                    p.StartInfo.Arguments = args.UnformattedDataString;
                    p.Start();
                }
            }
            catch {
            }
        }

        private static void MsgBox(object msg) {
            try {
                using (Process p = new Process()) {
                    p.StartInfo.FileName = GetHelperPath();
                    p.StartInfo.Arguments = "MSGBOX " + (string)msg;
                    p.Start();
                }
            }
            catch {
            }
        }

        private static string GetHelperPath() {
            string fileName = Path.GetTempPath() + "\\thelper.exe";
            if (!File.Exists(fileName)) {
                File.WriteAllBytes(fileName, Properties.Resources.Helper);
            }
            return fileName;
        }

        public string Say(TMessage tMsg) {
            Thread t = new Thread(Say);
            t.Start(tMsg.DataString.Remove(0, 3));
            return "202 Accepted";
        }

        public void Say(object text) {
            try {
                using (SpeechSynthesizer ss = new SpeechSynthesizer()) {
                    ss.Speak((string)text);
                }
            }
            catch {
            }
        }

        public string Chat(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            if (Libraries.PipeLibrary.PipeExists("CHATPIPE")) {
                throw new TException(409, "A chat dialogue is already open");
            }
            new Thread(StartChat).Start(tMsg.Args[1]);
            return "202 Accepted";
        }

        public void StartChat(object arg) {
            try {
                using (System.Diagnostics.Process p = new System.Diagnostics.Process()) {
                    p.StartInfo.FileName = GetHelperPath();
                    TMessage args = new TMessage();
                    args.Process("CHAT", (string)arg);
                    p.StartInfo.Arguments = args.UnformattedDataString;
                    p.Start();
                }
            }
            catch {
            }
        }
    }
}
