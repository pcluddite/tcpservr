﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Text;
using Tcpservr.Borrowed;
using Tcpservr.Errors;
using Tcpservr.Threads;
using System.Linq;

namespace Tcpservr.Libraries {
    public class PipeLibrary {

        private TCPSERVR tcpservr;
        private Dictionary<string, ByteMsg> cmds;
        private bool dominant;

        public PipeLibrary(TCPSERVR tcpservr, bool isDominant) {
            this.tcpservr = tcpservr;
            cmds = new Dictionary<string, ByteMsg>();
            cmds.Add("pipelistall", PipeListAll);
            cmds.Add("pipeexists", PipeExists);
            cmds.Add("pipeuse", PipeUse);
            cmds.Add("pipecreate", PipeCreate);
            if (isDominant) {
                cmds.Add("pipesetuser", PipeSetUser);
                cmds.Add("user", PipeSetUser);
                cmds.Add("pipelistusers", PipeListUsers);
            }
            dominant = isDominant;
        }

        public ByteMsg this[string command] {
            get {
                return cmds[command];
            }
        }

        public bool ContainsKey(string key) {
            return cmds.ContainsKey(key);
        }

        public byte[] PipeSetUser(TMessage tMsg) {
            TResponse response = new TResponse(tMsg);
            if (tMsg.Args.Length == 2) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], "False");
            }
            tMsg.ConfirmArgumentCount(3);
            
            if (!tcpservr.MasterPipe.Users.ContainsKey(tMsg.Args[1])) {
                throw new TException(404, "User");
            }
            bool global = tMsg.GetArgumentBool(2);

            string initialPipe = tcpservr.MasterPipe.Users[tMsg.Args[1]];
            string newPipe = tMsg.Args[1].Split('\\')[tMsg.Args[1].Split('\\').Length - 1];
            string responseMsg = "";
            if (!PipeExists(newPipe)) {
                TMessage createdMsg = new TMessage();
                createdMsg.Process("PipeCreate", initialPipe, newPipe);
                TResponse createdResponse = new TResponse(createdMsg);
                createdResponse.Process(PipeCreate(createdMsg));
                if (createdResponse.Status != 200) {
                    return createdResponse.Data;
                }
                responseMsg = "The current pipe is set to a new pipe '" + newPipe + "'";
            }
            else {
                responseMsg = "The current pipe is set to an existing pipe '" + newPipe + "'";
            }
            int id = System.Threading.Thread.CurrentThread.ManagedThreadId;
            tcpservr.Threads[id].CurrentPipeName = newPipe;
            tcpservr.Threads[id].UsingPipe = true;
            if (global) {
                tcpservr.GlobalPipe = newPipe;
                tcpservr.UsingGlobalPipe = global;
            }
            response.Process(200, responseMsg);
            return response.Data;
        }

        public byte[] PipeCreate(TMessage tMsg) {
            TResponse response = new TResponse(tMsg);
            tMsg.ConfirmArgumentCount(3);
            try {
                if (!PipeExists(tMsg.Args[1])) {
                    response.Process(404, "Pipe does not exist");
                    return response.Data;
                }
                TMessage pMsg = new TMessage();
                pMsg.Process("PIPEUSE \"" + tMsg.Args[1] + "\" OPEN \"" + tMsg.Args[2] + "\"");
                return PipeUse(pMsg);
            }
            catch (Exception ex) {
                throw new TException(500, ex.Message);
            }
        }

        public byte[] PipeListUsers(TMessage tMsg) {
            TResponse response = new TResponse(tMsg);
            if (tMsg.Args.Length != 1 && tMsg.Args.Length != 2) {
                tMsg.ConfirmArgumentCount(-5);
            }

            bool simple = false;
            if (tMsg.Args.Length == 2) {
                if (tMsg.Args[1].ToLower().Equals("/s")) {
                    simple = true;
                }
                else {
                    throw new TException(400, "arg[1] must be /s or null");
                }
            }

            response.Process(200, ListConnectedUsers(
                tcpservr.MasterPipe.Users,
                simple));

            return response.Data;
        }

        private string ListConnectedUsers(Dictionary<string, string> pipes, bool simple) {
            if (simple) {
                var users =
                    from u in pipes
                    select string.Format("{0}|{1}|{2}", u.Key, u.Value, PipeExists(u.Value) ? "Alive" : "Broken");
                return string.Join("\r\n", users.ToArray());
            }
            else {
                var users =
                    from u in pipes
                    select string.Format("{0,-25}{1,-8}{2}", 
                                          u.Key, u.Value, PipeExists(u.Value) ? "" : " - Broken Pipe");
                return string.Format("{0,-25}{1,-8}", "USER", "PIPE") +
                    "\r\n" + string.Join("\r\n", users.ToArray());
            }
        }

        public byte[] PipeListAll(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            TResponse response = new TResponse(tMsg);
            response.Process(200, string.Join("\n", FileIO.FindFiles(@"\\.\pipe\*")));
            return response.Data;
        }

        public byte[] PipeUse(TMessage tMsg) {
            TResponse response = new TResponse(tMsg);
            if (tMsg.Args.Length < 3) {
                tMsg.ConfirmArgumentCount(-5);
            }
            try {
                string[] args = new string[tMsg.Args.Length - 2];
                for (int i = 0; i < args.Length; i++) {
                    args[i] = tMsg.Args[i + 2];
                }

                TMessage pipeMsg = new TMessage();
                pipeMsg.Process(args);

                return PipeUse(tMsg.Args[1], pipeMsg, tcpservr.CurrentThread);
            }
            catch (Exception ex) {
                throw new TException(502, ex.Message);
            }
        }

        public static byte[] PipeUse(string pipe, TMessage tMsg, ThreadInfo currentThread) {
            TResponse response = new TResponse(tMsg);
            try {
                if (!PipeExists(pipe)) {
                    response.Process(502, "Pipe does not exist");
                    return response.Data;
                }

                int id = System.Threading.Thread.CurrentThread.ManagedThreadId;
                currentThread.AddTask("Connecting to '" + pipe + "'");
                using (NamedPipeClientStream client = new NamedPipeClientStream(pipe)) {
                    client.Connect(5000);
                    client.ReadMode = PipeTransmissionMode.Message;

                    currentThread.AddTask("Writing to '" + pipe + "'");

                    client.Write(tMsg.RawData, 0, tMsg.RawData.Length);

                    TReceiver receiver = new TReceiver(client, client);
                    byte[] data;
                    currentThread.AddTask("Reading from '" + pipe + "'");
                    int len = receiver.Receive(out data);
                    if (len == -1) {
                        response.Process(502, "An invalid message was received from the pipe and cannot be processed.");
                        return response.Data;
                    }
                    response.Process(data);

                    return response.Data;
                }
            }
            catch (Exception ex) {
                throw new TException(500, ex.Message);
            }
        }

        public static bool PipeExists(string pipe) {
            foreach (string s in FileIO.FindFiles(@"\\.\pipe\*")) {
                if (s.Equals(pipe)) {
                    return true;
                }
            }
            return false;
        }

        public byte[] PipeExists(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            TResponse response = new TResponse(tMsg);
            response.Process(200, PipeExists(tMsg.Args[1]).ToString());
            return response.Data;
        }
    }
}
