﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Tcpservr.Errors;
using System.Linq;

namespace Tcpservr
{
    public class WinList {
        [DllImport("user32.dll")]
        private static extern int EnumWindows(CallBackPtr callPtr, int lPar);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetWindowPlacement(IntPtr hWnd, out WINDOWPLACEMENT lpwndpl);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        private struct WINDOWPLACEMENT {
            public int length;
            public int flags;
            public int showCmd;
            public System.Drawing.Point ptMinPosition;
            public System.Drawing.Point ptMaxPosition;
            public System.Drawing.Rectangle rcNormalPosition;
        }

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool IsWindowEnabled(IntPtr hWnd);

        delegate bool CallBackPtr(IntPtr hwnd, int lParam);

        private List<IntPtr> list;
        private static CallBackPtr callBackPtr;

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr GetWindow(IntPtr hWnd, int uCmd);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        public WinList() {
            list = new List<IntPtr>();
        }

        private bool Report(IntPtr hwnd, int lParam) {
            list.Add(hwnd);
            return true;
        }

        public int WinGetState(IntPtr hwnd) {
            IntPtr exists = GetWindow(hwnd, 0);
            int state = 1;
            if (exists.ToInt32() == 0) { throw new TException(404, "window handle"); }
            if (IsWindowVisible(hwnd)) { state += 2; }
            if (IsWindowEnabled(hwnd))  { state += 4;  }
            if (GetForegroundWindow() == hwnd) { state += 8; }
            WINDOWPLACEMENT plac;
            GetWindowPlacement(hwnd, out plac);
            if (plac.showCmd == 2) { state += 16; }
            if (plac.showCmd == 3) { state += 32; }
            return state;
        }

        public IntPtr[] List() {
            list.Clear();
            callBackPtr = new CallBackPtr(Report);
            EnumWindows(callBackPtr, 0);
            return list.ToArray();
        }

        public IntPtr[] List(int flag) {

            var results =
                from hwnd in List()
                where (WinGetState(hwnd) & flag) == flag
                select hwnd;

            return results.ToArray();
        }
    }
}
