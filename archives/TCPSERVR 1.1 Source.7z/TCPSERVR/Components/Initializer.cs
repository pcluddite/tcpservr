﻿using System;
using System.Net;
using System.Windows.Forms;
using Tcpservr.Borrowed;
using System.IO;
using System.Text;
using System.Security;

namespace Tcpservr {
    public class Initializer {

        private IniFile file;
        private bool configExists;

        public Initializer() {
            try {
                if (File.Exists(Program.ApplicationPath + "\\Config.ini")) {
                    File.Move(Program.ApplicationPath + "\\Config.ini", Program.SettingsPath);
                }
            }
            catch {

            }
            file = new IniFile(Program.SettingsPath);
            configExists = File.Exists(file.path);
        }

        public static byte[] ReadToEnd(Stream stream) {
            long originalPosition = stream.Position;
            stream.Position = 0;

            try {
                byte[] readBuffer = new byte[4096];

                int totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0) {
                    totalBytesRead += bytesRead;

                    if (totalBytesRead == readBuffer.Length) {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1) {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead) {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally {
                stream.Position = originalPosition;
            }
        }

        public IPEndPoint GetEndpoint() {
            return new IPEndPoint(GetIP(), GetPort());
        }

        private int GetPort() {
            try {
                if (configExists) {
                    return int.Parse(file.IniReadValue("Config", "Port"));
                }
            }
            catch {
            }
            return 2200;
        }

        private IPAddress GetIP() {
            try {
                if (configExists) {
                    return IPAddress.Parse(file.IniReadValue("Config", "IP"));
                }
            }
            catch {
            }
            return IPAddress.Any;
        }

        public string GetPrivateKey() {
            try {
                if (configExists) {
                    try {
                        using (TcpSecure security = new TcpSecure("Ave Maria Gratia")) {
                            string key = file.IniReadValue("Config", "PrivateKey");
                            if (key.Trim().Equals("")) {
                                return null;
                            }
                            key = Encoding.UTF8.GetString(security.Decrypt(Convert.FromBase64String(key)));
                            return key;
                        }
                    }
                    catch {
                        Tcpservr.Errors.LoggedError error = new Errors.LoggedError("Initializer", 
                            "The private key was unable to be read. Defaulted to unencrypted mode.", "GetPrivateKey", true, false);
                        error.Write();
                    }
                }
            }
            catch {
            }
            return null;
        }

        public bool GetDoLogHistory() {
            try {
                if (configExists) {
                    return !file.IniReadValue("Config", "History").Equals("OFF", StringComparison.OrdinalIgnoreCase);
                }
            }
            catch {
            }
            return true;
        }
    }
}
