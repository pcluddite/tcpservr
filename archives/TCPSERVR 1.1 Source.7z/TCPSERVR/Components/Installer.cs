﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using Tcpservr.Borrowed;
using Microsoft.Win32;
using System.IO;
using System.Text;
namespace Tcpservr {
    public class Installer {

        public static bool TryInstall(string[] args) {
            if (args.Length < 2) {
                return false;
            }
            string arg0 = args[0].ToLower();
            if (!(arg0.Equals("-install") || arg0.Equals("-qinstall"))) {
                return false;
            }
            Installer installer = new Installer(arg0.Equals("-qinstall"));
            string arg1 = args[1].ToLower();
            switch (arg1) {
                case "service":
                    installer.AddService();
                    break;
                case "firewall":
                    installer.AddFirewallException();
                    break;
                case "hklm":
                    installer.AddHKLM();
                    break;
                case "hkcu":
                    installer.AddHKCU();
                    break;
                default:
                    if (args.Length != 3) {
                        return false;
                    }
                    switch (arg1) {
                        case "address":
                            installer.SetAddress(args[2]);
                            break;
                        case "port":
                            installer.SetPort(args[2]);
                            break;
                        case "pass":
                            installer.SetPass(args[2]);
                            break;
                        case "history":
                            installer.SetHistoryLog(args[2]);
                            break;
                        default:
                            return false;
                    }
                    break;
            }
            return true;
        }

        public static bool TryRemove(string[] args) {
            if (args.Length < 2) {
                return false;
            }
            string arg0 = args[0].ToLower();
            if (!(arg0.Equals("-remove") || arg0.Equals("-qremove"))) {
                return false;
            }
            Installer installer = new Installer(arg0.Equals("-qremove"));
            string arg1 = args[1].ToLower();
            switch (arg1) {
                case "service":
                    installer.RemoveService();
                    break;
                case "firewall":
                    installer.RemoveFirewallException();
                    break;
                case "hklm":
                    installer.RemoveHKLM();
                    break;
                case "hkcu":
                    installer.RemoveHKCU();
                    break;
                default:
                    return false;
            }
            return true;
        }

        private string curdir;
        public bool IsQuiet { get; set; }
        private IniFile file;

        public Installer(bool isQuiet) {
             curdir = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase).Remove(0, 6);
             this.IsQuiet = isQuiet;
             file = new IniFile(curdir + "\\Settings.ini");
        }

        public void SetAddress(string address) {
            file.IniWriteValue("Config", "IP", address);
            if (!this.IsQuiet) {
                MessageBox.Show("The new address has been set.", "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void SetPort(string port) {
            file.IniWriteValue("Config", "Port", port);
            if (!this.IsQuiet) {
                MessageBox.Show("The new port has been set.", "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void SetPass(string pass) {
            using (TcpSecure security = new TcpSecure("Ave Maria Gratia")) {
                if (pass.Equals("")) {
                    file.IniWriteValue("Config", "PrivateKey", "");
                }
                else {
                    pass = Convert.ToBase64String(security.Encrypt(Encoding.UTF8.GetBytes(pass)));
                    file.IniWriteValue("Config", "PrivateKey", pass);
                }
            }
            if (!this.IsQuiet) {
                MessageBox.Show("The new private key has been set.", "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void SetHistoryLog(string log) {
            log = log.ToUpper();
            file.IniWriteValue("Config", "History", log);
            if (!this.IsQuiet) {
                MessageBox.Show("The history is set to " + log + ".", "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void AddHKLM() {
            try {
                RegistryKey hklm = Registry.LocalMachine;
                hklm = hklm.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                hklm.SetValue("TCPSERVR", "\"" + Application.ExecutablePath + "\" -start");
                hklm.Close();
                if (!this.IsQuiet) {
                    MessageBox.Show("TCPSERVR has been added to the Run list in HKEY_LOCAL_MACHINE", "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex) {
                if (!this.IsQuiet) {
                    MessageBox.Show(ex.Message, "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void AddHKCU() {
            try {
                RegistryKey hkcu = Registry.CurrentUser;
                hkcu = hkcu.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                hkcu.SetValue("TCPSERVR", "\"" + Application.ExecutablePath + "\" -start");
                hkcu.Close();
                if (!this.IsQuiet) {
                    MessageBox.Show("TCPSERVR has been added to the Run list in HKEY_CURRENT_USER", "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex) {
                if (!this.IsQuiet) {
                    MessageBox.Show(ex.Message, "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void AddService() {
            Process p = new Process();
            if (this.IsQuiet) {
                if (Application.ExecutablePath.Contains(" ")) {
                    return;
                }
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.FileName = "sc";
                p.StartInfo.Arguments = "create TCPSERVR binPath= \"cmd /c start " + Application.ExecutablePath + " -start\" type= own type= interact start= auto";
                p.StartInfo.CreateNoWindow = true;
                p.Start();
                p.WaitForExit();
                p.StartInfo.Arguments = "start TCPSERVR";
                p.Start();
            }
            else {
                if (Application.ExecutablePath.Contains(" ")) {
                    MessageBox.Show("TCPSERVR cannot be in a path that includes spaces if you want to install it as a service.",
                        "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                p.StartInfo.FileName = "sc";
                p.StartInfo.Arguments = "create TCPSERVR binPath= \"cmd /c start " + Application.ExecutablePath + " -start\" type= own type= interact start= auto";
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.CreateNoWindow = true;
                p.Start();
                p.WaitForExit();
                if (MessageBox.Show("Installation returned:\r\n" + p.StandardOutput.ReadToEnd() + "\r\nWould you like to attempt to start the service?", "TCPSERVR",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) {
                    p.StartInfo.FileName = "sc";
                    p.StartInfo.Arguments = "start TCPSERVR";
                    p.Start();
                    MessageBox.Show("Attempted to start the service. Try to connect to the application to see if it succeeded.", "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        public void AddFirewallException() {
            Process p = new Process();
            p.StartInfo.FileName = "netsh";
            p.StartInfo.Arguments = "advfirewall firewall add rule name=\"TCPSERVR\" program=\"" + Application.ExecutablePath + "\" dir=\"in\" action=\"allow\" enable=\"yes\"";
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.CreateNoWindow = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.Start();
            p.WaitForExit();
            if (!this.IsQuiet) {
                MessageBox.Show("Installation returned:\r\n" + p.StandardOutput.ReadToEnd(), "TCPSERVR",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void RemoveHKLM() {
            try {
                RegistryKey hklm = Registry.LocalMachine;
                hklm = hklm.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                hklm.DeleteValue("TCPSERVR", false);
                if (!IsQuiet) {
                    MessageBox.Show("TCPSERVR has been removed from the Run list in HKEY_LOCAL_MACHINE", "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex) {
                if (!IsQuiet) {
                    MessageBox.Show(ex.Message, "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void RemoveHKCU() {
            try {
                RegistryKey hkcu = Registry.CurrentUser;
                hkcu = hkcu.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                hkcu.DeleteValue("TCPSERVR", false);
                if (!IsQuiet) {
                    MessageBox.Show("TCPSERVR has been removed from the Run list in HKEY_CURRENT_USER", "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex) {
                if (!IsQuiet) {
                    MessageBox.Show(ex.Message, "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void RemoveService() {
            Process p = new Process();
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.FileName = "sc";
            p.StartInfo.Arguments = "delete TCPSERVR";
            p.StartInfo.CreateNoWindow = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.Start();
            if (!IsQuiet)
                MessageBox.Show(p.StandardOutput.ReadToEnd(), "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public void RemoveFirewallException() {
            Process p = new Process();
            p.StartInfo.FileName = "netsh";
            p.StartInfo.Arguments = "advfirewall firewall delete rule name=\"TCPSERVR\" dir=\"in\"";
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.CreateNoWindow = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.Start();
            p.WaitForExit();
            if (!IsQuiet) {
                MessageBox.Show("Removal returned:\r\n" + p.StandardOutput.ReadToEnd(), "TCPSERVR",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
