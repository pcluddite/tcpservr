﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security;
using System.Runtime.InteropServices;

namespace Tcpservr {
    public static class ExtendedMethods {

        /// <summary>
        /// Determines whether or not a string was replaced
        /// </summary>
        /// <param name="searchString">The pattern to search</param>
        /// <param name="replaceString">The replacement</param>
        /// <param name="newString">The returned string</param>
        /// <returns>Returns true if the replacement was successful, otherwise false.</returns>
        public static bool TryReplace(this string initalString, string searchString, string replaceString, out string newString) {
            newString = initalString.Replace(searchString, replaceString);
            return !newString.Equals(initalString);
        }

        public static string Center(this string initial, int finalLength) {
            return initial.Center(finalLength, ' ');
        }

        public static string Center(this string initial, int finalLength, char padChar) {
            int start = (finalLength - initial.Length) / 2;
            if (start <= 0) {
                return initial;
            }
            int endLength = (finalLength - initial.Length);
            string line = string.Format("{0,-" + start + "}{1}{2," + endLength + "}", padChar, initial, padChar);
            return line;
        }

        public static string Roof(this string s, int maxSize) {
            if (s.Length < maxSize) {
                return s;
            }
            else {
                return s.Remove(maxSize - 5) + "[...]";
            }
        }

        public static string HideCharacters(this string s, char mask) {
            return "".PadLeft(s.Length, mask);
        }

        public static string GetFirstWord(this string s) {
            return s.Split(' ')[0];
        }

        public static string RemoveParentheses(this string s) {
            while (s.StartsWith("(")) {
                s = s.Remove(0, 1);
            }
            while (s.EndsWith(")")) {
                s = s.Remove(s.Length - 1, 1);
            }
            return s;
        }

        public static string RemoveBrackets(this string s) {
            while (s.StartsWith("[")) {
                s = s.Remove(0, 1);
            }
            while (s.EndsWith("]")) {
                s = s.Remove(s.Length - 1, 1);
            }
            return s;
        }

        public static string RemoveDoubleSpaces(this string s) {
            while (s.Contains("  ")) {
                s = s.Replace("  ", " ");
            }
            return s;
        }

        public static bool OneIsTrue(this bool[] allBools) {
            foreach (bool b in allBools) {
                if (b) {
                    return true;
                }
            }
            return false;
        }

        public static bool TryParse(this string initial, Type type, out object obj) {
            obj = null;
            try {
                obj = Enum.Parse(type, initial);
                return true;
            }
            catch {
                return false;
            }
        }

        public static bool IsBetween(this double x, double d1, double d2) {
            if (d1 < d2) {
                return (x <= d2) && (x >= d1);
            }
            else {
                return (x <= d1) && (x >= d2);
            }
        }

        public static string ToUnsecureString(this SecureString securePassword) {
            if (securePassword == null) {
                throw new ArgumentNullException("securePassword");
            }

            IntPtr unmanagedString = IntPtr.Zero;
            try {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(securePassword);
                return Marshal.PtrToStringUni(unmanagedString);
            }
            finally {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }
        }
    }
}
