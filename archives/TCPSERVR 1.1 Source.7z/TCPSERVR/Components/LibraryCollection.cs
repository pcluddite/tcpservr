﻿using System.Collections.Generic;

namespace Tcpservr.Libraries {
    
    public delegate string Command(TMessage msg);
    public delegate byte[] ByteMsg(TMessage msg);

    public class LibraryCollection {

        private Dictionary<string, Command> allCmds;
        private PipeLibrary pipeLib;

        public TCPSERVR tcpservr;

        public LibraryCollection(TCPSERVR server, bool isDominant) {
            tcpservr = server;
            IsMaster = isDominant;
            Load();
        }

        private void Load() {
            allCmds = new Dictionary<string, Command>();
            List<TcpservrLibrary> libraries = new List<TcpservrLibrary>();
            libraries.AddRange(new TcpservrLibrary[] {
                new AutomationLibrary(tcpservr), new FileLibrary(tcpservr),
                new CommunicationsLibrary(tcpservr), new ProcessLibrary(tcpservr),
                new RegistryLibrary(tcpservr), new ServerLibrary(tcpservr),
                new ThreadLibrary(tcpservr), new WindowLibrary(tcpservr)
            });
            foreach (TcpservrLibrary tLib in libraries) {
                foreach (var v in tLib.GetLibrary()) {
                    allCmds.Add(v.Key, v.Value);
                }
            }
        }

        private bool isDominant;

        public bool IsMaster {
            get {
                return isDominant;
            }
            set {
                this.isDominant = value;
                this.pipeLib = new PipeLibrary(tcpservr, this.isDominant);
            }
        }

        public PipeLibrary PipeLibrary {
            get {
                return pipeLib;
            }
        }

        public Command this[string command] {
            get {
                return allCmds[command];
            }
        }

        public bool ContainsKey(string key) {
            return allCmds.ContainsKey(key);
        }

        private string npass(string[] cmd, string msg) {
            return "530 A password is required to use any \r\n" +
                    "Use the PASS command to set a password.";
        }
    }
}
