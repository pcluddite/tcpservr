﻿using System.Collections.Generic;

namespace Tcpservr.Libraries {
    public abstract class TcpservrLibrary {

        protected TCPSERVR tcpservr;

        public TcpservrLibrary(TCPSERVR tcpservr) {
            this.tcpservr = tcpservr;
        }

        public abstract Dictionary<string, Command> GetLibrary();

        public Dictionary<string, Command>.Enumerator GetEnumerator() {
            return GetLibrary().GetEnumerator();
        }
    }
}
