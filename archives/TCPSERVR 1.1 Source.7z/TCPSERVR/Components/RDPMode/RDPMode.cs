﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tcpservr {
    public class RDPMode : ApplicationContext {

        private Timer timer = new Timer();

        public RDPMode() {
            timer.Interval = 100;
            timer.Start();
        }
    }
}
