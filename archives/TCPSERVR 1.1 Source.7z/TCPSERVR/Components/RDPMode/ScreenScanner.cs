﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.IO;

namespace Tcpservr {
    public class ScreenScanner {
        private int quality;
        private Bitmap screenshot;

        public ScreenScanner(int quality) {
            this.quality = quality;
        }

        public bool GetNew(out Bitmap outCapture) {
            Bitmap shot2 = TakeScreenshot();
            outCapture = null;
            if (!Compare(screenshot, shot2)) {
                outCapture = screenshot = shot2;
                return true;
            }
            return false;
        }

        public Bitmap TakeScreenshot() {
            Rectangle totalSize = Rectangle.Empty;
            
            foreach (Screen s in Screen.AllScreens) {
                totalSize = Rectangle.Union(totalSize, s.Bounds);
            }

            Bitmap screenShotBMP = new Bitmap(totalSize.Width, totalSize.Height, PixelFormat.
                Format32bppArgb);

            Graphics screenShotGraphics = Graphics.FromImage(screenShotBMP);

            screenShotGraphics.CopyFromScreen(totalSize.X, totalSize.Y, 0, 0, totalSize.Size,
                CopyPixelOperation.SourceCopy);

            screenShotGraphics.Dispose();

            return screenShotBMP;
        }

        private bool Compare(Bitmap b1, Bitmap b2) {
            if (b1 == null) {
                return false;
            }
            if (b1.Width != b2.Width || b1.Height != b2.Height) {
                return false;
            }
            if (b1.PixelFormat != b2.PixelFormat) {
                return false;
            }
            int bytes;
            if (b1.PixelFormat == PixelFormat.Format32bppArgb) {
                bytes = b1.Width * b1.Height * 4;
            }
            else {
                return false;
            }
            bool result = true;
            byte[] b1bytes = new byte[bytes - 1];
            byte[] b2bytes = new byte[bytes - 1];
            BitmapData bmd1 = b1.LockBits(new Rectangle(0, 0, b1.Width - 1, b1.Height - 1), ImageLockMode.ReadOnly, b1.PixelFormat);
            BitmapData bmd2 = b2.LockBits(new Rectangle(0, 0, b2.Width - 1, b2.Height - 1), ImageLockMode.ReadOnly, b2.PixelFormat);
            System.Runtime.InteropServices.Marshal.Copy(bmd1.Scan0, b1bytes, 0, bytes);
            System.Runtime.InteropServices.Marshal.Copy(bmd2.Scan0, b2bytes, 0, bytes);
            for (int n = 0; n < bytes - 1; n++) {
                if (b1bytes[n] != b2bytes[n]) {
                    result = false;
                }
            }
            b1.UnlockBits(bmd1);
            b2.UnlockBits(bmd1);
            return result;
        }
    }
}
