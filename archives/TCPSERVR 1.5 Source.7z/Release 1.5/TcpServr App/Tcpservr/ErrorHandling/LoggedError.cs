﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Tbasic.Errors {
    public class LoggedError {
        
        private string curdir;

        public string DateTimeNow {
            get {
                return DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt");
            }
        }

        public string Rank {
            get {
                return dominant ? "Dominant" : "Submissive";
            }
        }

        bool dominant;
        bool fatal;
        string sender;

        public string Message { get; set; }
        public string Method { get; set; }

        public string Fatal {
            get {
                return fatal ? "Yes" : "No";
            }
        }

        public string Sender {
            get {
                if (dominant) {
                    return "Client:\t" + sender;
                }
                else {
                    return "Pipe:\t" + sender;
                }
            }
        }

        public LoggedError(string sender, Exception ex, bool dominant, bool fatal) {
            curdir = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase).Remove(0, 6);
            this.dominant = dominant;
            this.Message = ex.Message;
            this.sender = sender;
            this.fatal = fatal;
        }

        public LoggedError(string sender, string msg, string method, bool dominant, bool fatal) {
            curdir = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase).Remove(0, 6);
            this.dominant = dominant;
            this.Message = msg;
            this.Method = method;
            this.sender = sender;
            this.fatal = fatal;
        }

        public string Error {
            get {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("-----------------------------------------------");
                sb.AppendLine("Date:\t" + this.DateTimeNow);
                sb.AppendLine("Status:\t" + this.Rank);
                //sb.AppendLine("User:\t" + System.Security.Principal.WindowsIdentity.GetCurrent().Name);
                sb.AppendLine(this.Sender);
                sb.AppendLine("Method:\t" + this.Method);
                sb.AppendLine("Fatal:\t" + this.Fatal);
                sb.AppendLine("Message:");
                sb.AppendLine(this.Message);
                return sb.ToString();
            }
        }

        public void Write() {
            try {
                using (StreamWriter sw = new StreamWriter(this.curdir + "\\DUMP.TXT", true)) {
                    sw.WriteLine(this.Error);
                }
            }
            catch {
            }
        }

        public override string ToString() {
            return Error;
        }
    }
}
