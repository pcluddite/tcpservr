﻿using System;
using System.IO;
using System.Security;

namespace Tbasic.Errors {
    public class TException : Exception {

        public int ErrorCode {
            get {
                return int.Parse(Message.Split(' ')[0]);
            }
        }

        public TException(int code, string msg)
            : base(GetMsg(code, msg, true)) {
        }

        public TException(int code, string msg, bool prependGeneric)
            : base(GetMsg(code, msg, prependGeneric)) {
        }

        public TException(Exception ex)
            : base(GetMsg(ex)) {
        }

        public TException(int code)
            : base(GetMsg(code)) {
        }

        public static string GetMessage(Exception ex) {
            if (ex.GetType() == typeof(TException)) {
                return ex.Message;
            }
            else {
                return (new TException(ex)).Message;
            }
        }

        private static string GetMsg(int code, string msg, bool prependGeneric) {
            if (prependGeneric) {
                return GetMsg(code) + ": " + msg;
            }
            else {
                return code + " " + msg;
            }
        }

        private static string GetMsg(int code) {
            switch (code) {
                case 201:
                    return "201 Created";
                case 202:
                    return "202 Accepted";
                case 204:
                    return "204 No Content";
                case 206:
                    return "206 Completed with warnings";
                case 400:
                    return "400 Bad Request";
                case 401:
                    return "401 Unauthorized";
                case 403:
                    return "403 No user access";
                case 404:
                    return "404 Not Found";
                case 409:
                    return "409 Conflict";
                case 423:
                    return "423 Locked";
                case 501:
                    return "501 Not Implemented";
                case 502:
                    return "502 Bad Gateway";
                case 507:
                    return "507 Insufficient Memory";
                default:
                    return "500 Generic Error";
            }
        }

        private static string GetMsg(int code, string msg) {
            return GetMsg(code, msg, true);
        }

        private static string GetMsg(Exception ex) {
            Type type = ex.GetType();
            if (type == typeof(TException)) {
                return ex.Message;
            }
            else if (type == typeof(ArgumentException) ||
                type == typeof(ArgumentNullException)) {
                    return GetMsg(400);
            }
            else if (type == typeof(PathTooLongException) ||
                type == typeof(NotSupportedException)) {
                return GetMsg(400, ex.Message);
            }
            else if (type == typeof(UnauthorizedAccessException) ||
                type == typeof(SecurityException) ||
                ex.Message.Contains("Logon failure")) {
                return GetMsg(403);
            }
            else if (type.Name.Contains("NotFound")) {
                    return GetMsg(404);
            }
            else if (type == typeof(NotImplementedException)) {
                return GetMsg(501, ex.Message, false);
            }
            else if (type == typeof(IOException)) {
                return GetMsg(423, ex.Message);
            }
            return GetMsg(500, ex.Message);
        }
    }
}
