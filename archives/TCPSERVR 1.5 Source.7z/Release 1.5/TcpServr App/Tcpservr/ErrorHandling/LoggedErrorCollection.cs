﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tbasic.Errors {
    public class LoggedErrorCollection {

        private List<LoggedError> errors;
        private int capacity;

        public LoggedErrorCollection(int capacity) {
            this.capacity = capacity;
            errors = new List<LoggedError>();
        }

        public void Add(LoggedError error) {
            errors.Add(error);
            if (errors.Count > capacity) {
                errors.RemoveAt(0);
            }
        }

        public override string ToString() {
            StringBuilder result = new StringBuilder();
            foreach (LoggedError error in errors) {
                result.AppendLine(error.Error);
            }
            return result.ToString();
        }
    }
}
