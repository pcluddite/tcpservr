﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Tbasic.Errors;

namespace Tbasic.Components {
    public class TcpSecure : IDisposable {

        private AesManaged rij;
        private ICryptoTransform encryptor;
        private ICryptoTransform decryptor;

        public TcpSecure(string key) {
            rij = new AesManaged();
            key = key.PadLeft(16, '0');
            encryptor = rij.CreateEncryptor(
                Encoding.UTF8.GetBytes(key),
                Encoding.UTF8.GetBytes("fq7XeXyqkbnmG4Ax")
                );
            decryptor = rij.CreateDecryptor(
                Encoding.UTF8.GetBytes(key),
                Encoding.UTF8.GetBytes("fq7XeXyqkbnmG4Ax")
                );
            IsDisposed = false;
        }

        public CryptoStream CreateEncryptorStream(Stream stream) {
            return new CryptoStream(stream, encryptor, CryptoStreamMode.Write);
        }

        public CryptoStream CreateDecryptorStream(Stream stream) {
            return new CryptoStream(stream, decryptor, CryptoStreamMode.Read);
        }

        public byte[] Encrypt(byte[] data) {
            return encryptor.TransformFinalBlock(data, 0, data.Length);
        }

        public byte[] Decrypt(byte[] data) {
            try {
                return decryptor.TransformFinalBlock(data, 0, data.Length);
            }
            catch {
                throw new TException(401, "Attempted to use an invalid encryption");
            }
        }

        public bool IsDisposed {
            get; private set;
        }

        public void Dispose() {
            encryptor.Dispose();
            decryptor.Dispose();
            rij.Clear();
            IsDisposed = true;
        }
    }
}