﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using System.Windows.Input;
using System.Windows.Documents;
using System.Threading;
using Tbasic.Components;
using Windows.Networking.Sockets;
using Windows.Networking;
using Windows.Foundation;
using Windows.Storage.Streams;
using System.IO;

namespace TcpServr_App {
    public partial class MainPage : PhoneApplicationPage {

        private const string HOST = "192.168.1.91", PASS = "", PORT = "2200";
        private const int TIMEOUT_MILLISECONDS = 5000;

        private Thread tListener;
        private StreamSocket client;
        private IAsyncAction connectAction;

        public MainPage() {
            InitializeComponent();

            client = new StreamSocket();

            connectAction = client.ConnectAsync(new HostName(HOST), PORT);

            connectAction.Completed += Listen;
        }

        private void Listen(IAsyncAction action, AsyncStatus status) {
            
            TextBlock block = new TextBlock();
            block.Text = "Connected";
            historyPanel.Children.Insert(0, block);

            TReceiver receiver = new TReceiver(client.InputStream, client.OutputStream);
            int bytes;
            byte[] data;
            while ((bytes = receiver.Receive(out data)) != 0) {
                TResponse response = new TResponse();
                response.Process(data);

                block = new TextBlock();
                block.Text = response.DataString;
                historyPanel.Children.Insert(0, block);
            }
        }

        private void cmdBox_GotFocus(object sender, RoutedEventArgs e) {
            if (cmdBox.Text.Equals("Type your command here...")) {
                cmdBox.Text = "";
            }
        }

        private void cmdBox_LostFocus(object sender, RoutedEventArgs e) {
            if (cmdBox.Text.Equals("")) {
                cmdBox.Text = "Type your command here...";
            }
        }

        private void cmdBox_KeyUp(object sender, KeyEventArgs e) {
            if (e.Key == Key.Enter) {
                TextBlock block = new TextBlock();
                block.Text = cmdBox.Text;
                block.Tap += block_Tap;
                historyPanel.Children.Insert(0, block);

                Send(cmdBox.Text);

                cmdBox.Text = "";                
            }
        }

        private void Send(string msg) {
            TMessage tMsg = new TMessage(client.OutputStream.AsStreamForWrite());
            tMsg.Send(msg);
        }

        private void block_Tap(object sender, GestureEventArgs e) {
            cmdBox.Text = (sender as TextBlock).Text;
        }
    }
}
