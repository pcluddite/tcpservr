﻿using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;

namespace Tbasic.Interpreter {
    public class Parameter {

        /// <summary>
        /// An individual parameter of a function to manage
        /// </summary>
        /// <param name="text">The parameter text</param>
        public Parameter(string text) {
            Text = text;
            QuotesRemoved = false;
        }

        /// <summary>
        /// An individual parameter of a function to manage
        /// </summary>
        /// <param name="text">The parameter text</param>
        /// /// <param name="text">The parameter type</param>
        public Parameter(string text, ParamType type) {
            this.text = text;
            thisType = type;
            QuotesRemoved = false;
        }

        string text;

        /// <summary>
        /// Gets or sets the text of the parameter
        /// </summary>
        public string Text {
            get {
                if (QuotesRemoved) {
                    return text;
                }
                else {
                    return text.Trim();
                }
            }
            set {
                text = value;
                brokenString = null;
                thisType = GetParamType();
            }
        }

        ParamType thisType = ParamType.NotSet;

        /// <summary>
        /// Gets or sets the Parameter type (Setting it will override the automatically derived type)
        /// </summary>
        public ParamType Type {
            get {
                if (thisType == ParamType.NotSet) {
                    return thisType = GetParamType();
                }
                else {
                    return thisType;
                }
            }
            set {
                thisType = value;
            }
        }

        /// <summary>
        /// Gets or sets whether or not quotes have been removed. If quotes have been removed, the parameter text will not be trimmed.
        /// </summary>
        public bool QuotesRemoved { get; set; }

        private string RemoveParentheses(string text) {
            if (text.StartsWith("(") && text.EndsWith(")")) {
                text = text.Substring(1, text.Length - 2);
            }
            return text;
        }

        private bool isInQuotes() {
            string tmp = text.Trim();
            return tmp.StartsWith("\"") && tmp.EndsWith("\"");
        }

        private bool isInParentheses() {
            return text.StartsWith("(") && text.EndsWith(")");
        }

        private ParamType GetParamType() {
            string tmp = text.Trim();
            if (tmp.Equals("")) {
                return ParamType.Empty;
            }
            Function fTemp;
            if (Function.TryParse(tmp, out fTemp)) {
                return ParamType.Function;
            }
            if (isDouble(tmp)) {
                return ParamType.Double;
            }
            if (IsMath()) {
                return ParamType.Math;
            }
            if (BreakString(tmp).Length > 1) {
                return ParamType.Broken;
            }
            if (isInQuotes()) {
                return ParamType.String;
            }
            if (ScriptRunner.VariableEx.Match(tmp).Success) {
                return ParamType.Variable;
            }
            return ParamType.Error;
        }

        private bool IsMath() {
            if (BeginsWithOpr(text) || EndsWithOpr(text)) {
                return false;
            }
            string temp = ScriptRunner.VariableEx.Replace(text.Trim(), "0");      // All variables will be seen as integers
            if (temp.Equals("0")) {
                return false;
            }
            temp = ScriptRunner.FunctionEx.Replace(temp, "0"); // All functions will be seen as integers
            if (temp.Equals("0")) {
                return false;
            }
            foreach (char c in temp.ToCharArray()) {
                if (!IsMathChar(c)) {
                    return false;
                }
            }
            return true;
        }

        private readonly char[] MATH_OPRTR = { '%', '+', '/', '*', '-' };
        private readonly char[] MATH_CHARS = { '(', ')', '.', ' ' };

        private bool IsOperator(char c) {
            return MATH_OPRTR.Contains(c);
        }

        private bool IsMathChar(char c) {
            return char.IsDigit(c) || MATH_OPRTR.Contains(c) || MATH_CHARS.Contains(c);
        }

        private bool BeginsWithOpr(string s) {
            return MATH_OPRTR.Contains(s[0]);
        }

        private bool EndsWithOpr(string s) {
            return MATH_OPRTR.Contains(s[s.Length - 1]);
        }

        /// <summary>
        /// Breaks up a parameter into more Parameters if the Parameter type is ParamType.Broken
        /// </summary>
        /// <returns>An array of all Parameters in a Broken Parameter</returns>
        public Parameter[] BreakParameter() {
            if (thisType != ParamType.NotSet && thisType != ParamType.Broken) {
                return new Parameter[] { this };
            }
            return BreakString(text);
        }

        private Parameter[] brokenString = null;

        private Parameter[] BreakString(string line) {
            if (brokenString != null) {
                return brokenString;
            }
            StringBuilder currentParm = new StringBuilder();
            List<Parameter> parms = new List<Parameter>(); // Initialize a list of parameters
            int offset = 0; // How many parentheses are expected
            bool inQuotes = false;
            foreach (char c in line.ToCharArray()) {
                if (c == '"') {
                    inQuotes = !inQuotes;
                }
                if (!inQuotes) { // Ignore if in quotes
                    if (c == '(') {
                        offset++;
                    }
                    if (c == ')') {
                        offset--;
                    }
                    if (offset == 0 && IsOperator(c)) { // No parentheses are expected, this is the current parameter
                        parms.Add(new Parameter(RemoveParentheses(currentParm.ToString()), ParamType.NotSet));
                        currentParm = new StringBuilder();
                        continue;
                    }
                }
                currentParm.Append(c);
            }
            parms.Add(new Parameter(RemoveParentheses(currentParm.ToString()), ParamType.NotSet));
            return brokenString = parms.ToArray();
        }

        private bool isDouble(string d) {
            double dum;
            return double.TryParse(d, out dum);
        }

        public static Parameter operator +(Parameter a, Parameter b) {
            if (a.Type == ParamType.Double && b.Type == ParamType.Double) {
                return new Parameter(
                    (double.Parse(a.text) + double.Parse(b.text)).ToString(),
                    ParamType.Double);
            }
            else {
                return new Parameter(a.text + b.text);
            }
        }

        public void RemoveQuotes() {
            if (!QuotesRemoved && text.Length > 1) {
                while (text.StartsWith("\"") && text.EndsWith("\"")) {
                    text = text.Substring(1, text.Length - 2);
                }
            }
            QuotesRemoved = true;
        }

        public override string ToString() {
            return text;
        }
    }

    public enum ParamType {
        String, Variable, Double, Math, Empty, NotSet,
        Function, Broken, Error
    }
}
