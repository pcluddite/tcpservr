﻿using System;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Tbasic.Errors;
using Tbasic.Libraries;
using Tbasic.Threads;
using Tbasic.Components;

namespace Tbasic.Interpreter
{
    public class TBasicCore {

        private readonly string appPath = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase).Remove(0, 6);

        public string ApplicationDirectory {
            get {
                return appPath;
            }
        }

        public string ExecutablePath {
            get {
                return System.Windows.Forms.Application.ExecutablePath;
            }
        }

        public LibraryCollection LibraryCollection { get; set; }

        public ThreadCollection Threads { get; set; }
        public LoggedErrorCollection ErrorLog { get; set; }

        public bool LogHistory { get; set; }
        
        public ThreadInfo CurrentThread {
            get {
                if (Threads.Contains(Thread.CurrentThread.ManagedThreadId)) {
                    return Threads[Thread.CurrentThread.ManagedThreadId];
                }
                else {
                    return null;
                }
            }
        }

        public TBasicCore() {
            Construct(false);
        }

        public TBasicCore(bool logHistory) {
            Construct(logHistory);
        }

        private void Construct(bool logHistory) {
            Threads = new ThreadCollection();
            LibraryCollection = new LibraryCollection(this);
            Directory.SetCurrentDirectory(ApplicationDirectory);
            LogHistory = logHistory;
        }

        public virtual TResponse GetResponse(TResponse response) {
            try {
                string cmd = response.Original.Args[0].ToLower();
                if (LibraryCollection.ContainsKey(cmd)) {
                    CurrentThread.AddTask("Found in the main library. Processing");
                    response.Process(LibraryCollection[cmd].Invoke(response.Original));
                }
                else {
                    throw new TException(501, response.Original.Args[0].ToUpper());
                }
                if (cmd.Equals("put")) {
                    CurrentThread.AddTask("Truncating PUT header");
                    TMessage newMsg = new TMessage();
                    newMsg.Process(response.Original.Args[0], response.Original.Args[1]);
                    TResponse newResponse = new TResponse(newMsg);
                    newResponse.Process(response.Status, response.Message);
                    response.Process(newResponse.Data);
                }
            }
            catch (Exception ex) {
                response.Process(TException.GetMessage(ex));
                CurrentThread.AddTask("Processing exception: " + response.Message);
            }
            return response.Clone();
        }

        protected internal void AddTask(string task) {
            if (CurrentThread != null) {
                CurrentThread.AddTask(task);
            }
        }

        public string GetRealPath(string path) {
            if (path.Equals("\\")) {
                path = Path.GetPathRoot(CurrentThread.CurrentDirectory);
            }
            else if (path.StartsWith("\\")) {
                path = Path.Combine(Path.GetPathRoot(CurrentThread.CurrentDirectory), path.Remove(0, 1));
            }
            if (!Path.IsPathRooted(path)) {
                path = Path.Combine(CurrentThread.CurrentDirectory, path);
            }
            return Path.GetFullPath(path);
        }

        internal static byte[] ReadToEnd(Stream stream) {
            long originalPosition = stream.Position;
            stream.Position = 0;

            try {
                byte[] readBuffer = new byte[4096];

                int totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0) {
                    totalBytesRead += bytesRead;

                    if (totalBytesRead == readBuffer.Length) {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1) {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead) {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally {
                stream.Position = originalPosition;
            }
        }
    }
}
