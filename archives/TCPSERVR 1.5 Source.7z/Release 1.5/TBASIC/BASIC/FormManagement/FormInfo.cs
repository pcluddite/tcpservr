﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tbasic.Interpreter {
    public class FormInfo : ControlInfo {
        
        public Form Form {
            get {
                return (Form)control;
            }
        }

        private bool disposed = false;

        private Dictionary<IntPtr, ControlInfo> controls;

        public ControlInfo[] Controls {
            get {
                return controls.Values.ToArray();
            }
        }

        public bool IsDisposed {
            get {
                return disposed;
            }
        }

        public string OnClosing { get; set; }

        public string Closed { get; set; }

        private FormLibrary formMan;

        public FormInfo(Form form, FormLibrary formMan) :
            base(form, formMan.UserLibrary) {
            controls = new Dictionary<IntPtr, ControlInfo>();
            this.formMan = formMan;
            this.Form.FormClosing += new FormClosingEventHandler(form_FormClosing);
            this.Form.FormClosed += new FormClosedEventHandler(form_FormClosed);
            this.Form.Disposed += new EventHandler(form_Disposed);
        }

        private void form_FormClosed(object sender, FormClosedEventArgs e) {
            if (this.Closed != null) {
                Invoke(Closed);
            }
        }

        void form_Disposed(object sender, EventArgs e) {
            this.disposed = true;
            formMan.ClearDisposed();
        }

        private void form_FormClosing(object sender, FormClosingEventArgs e) {
            if (this.OnClosing != null) {
                if (Invoke(OnClosing).ToUpper().Equals("202 STOP")) {
                    e.Cancel = true;
                }
            }
        }

        public void AddControl(ControlInfo info) {
            this.Form.Controls.Add(info.Control);
            controls.Add((IntPtr)info.Handle, info);
        }
    }
}
