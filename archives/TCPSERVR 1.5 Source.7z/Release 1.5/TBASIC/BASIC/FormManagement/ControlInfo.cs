﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Tbasic.Components;

namespace Tbasic.Interpreter {
    public class ControlInfo {

        protected Control control;

        public Control Control {
            get {
                return control;
            }
        }

        private IntPtr hwnd;

        public IntPtr Handle {
            get {
                return hwnd;
            }
        }

        #region define events
        public string OnMouseClick { get; set; }

        public string OnMouseDown { get; set; }

        public string OnMouseDoubleClick { get; set; }

        public string OnMouseUp { get; set; }

        public string OnKeyPress { get; set; }

        public string OnKeyDown { get; set; }

        public string OnKeyUp { get; set; }

        public string GotFocus { get; set; }
        #endregion

        protected internal CustomLibrary userLib;

        public ControlInfo(Control control, CustomLibrary userLib) {
            this.userLib = userLib;
            this.control = control;
            this.control.GotFocus += new EventHandler(gotFocus);
            this.control.MouseClick += new MouseEventHandler(mouseClick);
            this.control.MouseUp += new MouseEventHandler(mouseUp);
            this.control.MouseDown += new MouseEventHandler(mouseDown);
            this.control.MouseDoubleClick += new MouseEventHandler(mouseDoubleClick);
            this.control.KeyPress += new KeyPressEventHandler(keyPress);
            this.control.KeyDown += new KeyEventHandler(keyDown);
            this.control.KeyUp += new KeyEventHandler(keyUp);
            hwnd = control.Handle;
        }

        #region handle events
        protected void keyUp(object sender, KeyEventArgs e) {
            if (this.OnKeyUp != null) {
                Invoke(OnKeyUp);
            }
        }

        protected void keyDown(object sender, KeyEventArgs e) {
            if (this.OnKeyDown != null) {
                Invoke(OnKeyDown);
            }
        }

        protected void keyPress(object sender, KeyPressEventArgs e) {
            if (this.OnKeyPress != null) {
                Invoke(OnKeyPress);
            }
        }

        protected void mouseDoubleClick(object sender, MouseEventArgs e) {
            if (this.OnMouseDoubleClick != null) {
                Invoke(OnMouseDoubleClick);
            }
        }

        protected void mouseDown(object sender, MouseEventArgs e) {
            if (this.OnMouseDown != null) {
                Invoke(OnMouseDown);
            }
        }

        protected void mouseUp(object sender, MouseEventArgs e) {
            if (this.GotFocus != null) {
                Invoke(OnMouseUp);
            }
        }

        protected void mouseClick(object sender, MouseEventArgs e) {
            if (this.OnMouseClick != null) {
                Invoke(OnMouseClick);
            }
        }

        protected void gotFocus(object sender, EventArgs e) {
            if (this.GotFocus != null) {
                Invoke(GotFocus);
            }
        }
        #endregion

        protected string Invoke(params string[] args) {
            TMessage msg = new TMessage();
            msg.Process(args);
            return userLib.Invoke(msg);
        }

        public string Text {
            get {
                return control.Text;
            }
            set {
                control.Text = value;
            }
        }
    }
}
