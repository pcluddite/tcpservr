﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Tbasic.Interpreter.Libraries;

namespace Tbasic.Interpreter {
    internal partial class INPUT : Form {

        private ScriptExecutionLibrary scriptLib;

        public INPUT(ScriptExecutionLibrary interpreter, string title, string text, int width, int height) {
            InitializeComponent();
            this.scriptLib = interpreter;
            this.Text = title;
            this.Width = width;
            this.Height = height;
            this.label1.Text = text;
            this.textBox1.Select();
        }

        private void button2_Click(object sender, EventArgs e) {
            this.scriptLib.Storage = null;
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e) {
            this.scriptLib.Storage = textBox1.Text;
            this.Close();
        }
    }
}
