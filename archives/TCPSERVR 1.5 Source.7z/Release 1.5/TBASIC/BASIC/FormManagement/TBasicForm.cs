﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tbasic.Interpreter {
    internal partial class TBasicForm : Form {

        CustomLibrary userLib;

        public TBasicForm(CustomLibrary userLib) {
            this.userLib = userLib;
            InitializeComponent();
            this.Visible = false;
        }
    }
}
