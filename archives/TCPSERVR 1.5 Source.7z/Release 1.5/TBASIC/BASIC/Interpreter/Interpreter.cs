﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using Tbasic.Libraries;
using Tbasic.Components;

namespace Tbasic.Interpreter {

    public delegate object FunctionDelegate(TMessage statement);
    public delegate string ScriptCommandDelegate(Command statement);
    public delegate void CodeBlockDelegate(CodeBlock block);

    public delegate void UserExittedEventHandler(object sender, EventArgs e);

    public class Interpreter {
        
        public LibraryCollection MainLibrary { get; set; }
        public CommandLibraryCollection CmdLib { get; set; }
        public FunctionLibraryCollection FuncLib { get; set; }
        public CustomLibrary UserLibrary { get; set; }

        public FormLibrary FormLibrary { get; set; }

        public DataManager DataManager { get; set; }

        public bool ThrowOnError { get; set; }

        public ScriptRunner TBASIC { get; set; }

        public event UserExittedEventHandler OnUserExitRequest;

        protected virtual void OnUserExit(EventArgs e) {
            if (OnUserExitRequest != null) {
                OnUserExitRequest(this, e);
            }
        }

        public Interpreter(ScriptRunner tbasic, CustomLibrary userFuncs) {
            this.DataManager = new DataManager(this);
            this.FormLibrary = new FormLibrary(this);
            this.ThrowOnError = true;
            this.TBASIC = tbasic;
            this.CmdLib = new CommandLibraryCollection(this);
            this.FuncLib = new FunctionLibraryCollection(this);
            this.MainLibrary = new LibraryCollection(tbasic.Core);
            this.UserLibrary = userFuncs;
        }

        public void RequestExit() {
            TBASIC.ExitRequest = true;
            OnUserExit(EventArgs.Empty);
        }

        public object Execute(CodeLine codeLine) {
            string text = codeLine.Text;
            object ret;
            if (CmdLib.ContainsKey(codeLine.Name)) {
                ret = CmdLib.InvokeCMD(new Command(text, this.DataManager));
            }
            else {
                ret = SolveFunction(text);
            }
            int status;
            if (ret.GetType() == typeof(string)) {
                string retString = ret.ToString();
                if (!int.TryParse(retString.Split(' ')[0], out status)) {
                    throw new Exception("The command returned a bad status code");
                }
                ret = retString.Remove(0, 4);
                if (this.ThrowOnError && (status < 200 || status >= 300)) {
                    throw new Exception(retString);
                }
            }
            else {
                DataObject dObject = (DataObject)ret;
                if (!int.TryParse(ScriptRunner.Digits.Match(dObject.Name).Value, out status)) {
                    throw new Exception("The command returned a bad status code");
                }
                ret = dObject.GetData();
            }
            DataManager.SaveObject("@status", status, true);
            DataManager.SaveObject("@error", status, true);
            DataManager.SaveObject("@return", ret, true);
            DataManager.SaveObject("@ret", ret, true);
            return ret;
        }

        private object SolveFunction(string funcLine) {
            Function function = new Function(funcLine);
            string name = function.Name.ToLower();
            List<string> parms = new List<string>();
            parms.Add(name);
            foreach (Parameter p in function.Parameters) {
                parms.Add(ProcessParam(p, false).ToString());
            }
            TMessage msg = new TMessage();
            msg.Process(parms.ToArray()); // Convert to message to be processed by the main library
            msg.Storage = funcLine; // Store the original function text for possible use
            TBASIC.Core.CurrentThread.CreateReport(msg);
            try {
                if (this.FuncLib.ContainsKey(name)) {
                    return this.FuncLib.InvokeFunc(msg);
                }
                else if (this.MainLibrary.ContainsKey(name)) {
                    return this.MainLibrary[name].Invoke(msg);
                }
                else if (this.UserLibrary.FunctionExists(name)) {
                    return this.UserLibrary.Invoke(msg);
                }
                else {
                    throw new Exception("The meaning of '" + name + "' is unknown");
                }
            }
            finally {
                TBASIC.Core.CurrentThread.CompletedReport(msg);
            }
        }

        private Parameter ProcessParam(Parameter p, bool passError) {
            object ret;
            switch (p.Type) {
                case ParamType.Function:
                    ret = Execute(new CodeLine(p.Text));
                    break;
                case ParamType.Broken:
                    ret = JoinParm(p);
                    p.QuotesRemoved = true;
                    break;
                case ParamType.Math:
                    string eval = DataManager.ReplaceObjects(p.Text);
                    foreach (Match m in ScriptRunner.FunctionEx.Matches(p.Text)) {
                        eval = eval.Replace(m.Value, SolveFunction(m.Value).ToString().Remove(0, 4));
                    }
                    ret = Libraries.MathLibrary.Eval(eval);
                    break;
                case ParamType.Variable:
                    ret = DataManager.GetObject(p.Text).GetData();
                    p.QuotesRemoved = true;
                    break;
                case ParamType.Error:
                    if (!passError) {
                        throw new Exception("The name '" + p.Text + "' is undefined");
                    }
                    else {
                        ret = p.Text;
                    }
                    break;
                default:
                    ret = p.Text;
                    break;
            }
            p.Text = ret.ToString();
            if (p.Type == ParamType.Math) {
                return ProcessParam(p, passError);
            }
            p.RemoveQuotes();
            return p;
        }

        public string JoinParm(Parameter parm) {
            return JoinParm(parm, false);
        }

        public string JoinParm(Parameter parm, bool hideError) {
            Parameter result = new Parameter("");
            foreach (Parameter p in parm.BreakParameter()) {
                result += ProcessParam(p, hideError);
                result.QuotesRemoved = true;
            }
            return result.Text;
        }
    }
}
