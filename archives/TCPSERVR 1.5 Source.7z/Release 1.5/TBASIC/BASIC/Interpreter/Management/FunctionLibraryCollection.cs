﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tbasic.Interpreter.Libraries;
using Tbasic.Components;

namespace Tbasic.Interpreter {
    public class FunctionLibraryCollection : List<ScriptOnlyLibrary> {

        private Dictionary<string, FunctionDelegate> library;

        public FunctionLibraryCollection(Interpreter interpreter) {
            // Initialize the libraries
            library = new Dictionary<string, FunctionDelegate>();
            AddLibraries(interpreter);
        }

        protected virtual void AddLibraries(Interpreter interpreter) {
            AddRange(new ScriptOnlyLibrary[] {
                new MathLibrary(interpreter), new ScriptExecutionLibrary(interpreter),
                new StringLibrary(interpreter), new BooleanLibrary(interpreter),
                new FormLibrary(interpreter)
            });
            Refresh();
        }

        public void Refresh() {
            foreach (ScriptOnlyLibrary lib in this) {
                foreach (var kv in lib.GetFunctionLibrary()) {
                    library.Add(kv.Key, kv.Value);
                }
            }
        }

        public FunctionDelegate this[string command] {
            get {
                return library[command];
            }
        }

        public bool ContainsKey(string key) {
            return library.ContainsKey(key);
        }

        public object InvokeFunc(TMessage statement) {
            return this.library[statement.ArgsOriginal[0].ToLower()].Invoke(statement);
        }
    }
}
