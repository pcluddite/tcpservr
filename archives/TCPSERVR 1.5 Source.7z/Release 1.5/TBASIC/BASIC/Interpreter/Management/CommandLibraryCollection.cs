﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tbasic.Interpreter.Libraries;

namespace Tbasic.Interpreter {
    public class CommandLibraryCollection : List<ScriptOnlyLibrary> {

        private Dictionary<string, ScriptCommandDelegate> cmdLib;
        private Dictionary<string, CodeBlockDelegate> blockLib;

        public CommandLibraryCollection(Interpreter interpreter) {
            blockLib = new Dictionary<string, CodeBlockDelegate>(StringComparer.OrdinalIgnoreCase);
            cmdLib = new Dictionary<string, ScriptCommandDelegate>(StringComparer.OrdinalIgnoreCase);
            AddLibraries(interpreter);
        }

        protected virtual void AddLibraries(Interpreter interpreter) {
            AddRange(new ScriptOnlyLibrary[] {
                new ScriptExecutionLibrary(interpreter), new BooleanLibrary(interpreter)
            });
            Refresh();
        }

        public void Refresh() {
            foreach (ScriptOnlyLibrary lib in this) {
                if (lib.HasCommandLib()) {
                    foreach (var kv in lib.GetCommandLibrary()) {
                        cmdLib.Add(kv.Key, kv.Value);
                    }
                }
                else if (lib.HasBlockLib()) {
                    foreach (var kv in lib.GetBlockLibrary()) {
                        blockLib.Add(kv.Key, kv.Value);
                    }
                }
            }
        }

        public ScriptCommandDelegate this[string command] {
            get {
                return cmdLib[command];
            }
        }

        public bool ContainsKey(string key) {
            return cmdLib.ContainsKey(key);
        }

        public string InvokeCMD(Command command) {
            return this.cmdLib[command.Name].Invoke(command);
        }

        public void InvokeBlock(CodeBlock block) {
            this.blockLib[block.Header.Name].Invoke(block);
        }
    }
}
