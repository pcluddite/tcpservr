﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Tbasic.Components;

namespace Tbasic.Interpreter {
    public class DataManager {
        private Dictionary<string, DataObject> objects;
        private Interpreter interpreter;

        public DataManager(Interpreter interpreter) {
            this.interpreter = interpreter;
            objects = new Dictionary<string, DataObject>();
            // Add constants
            objects.Add("@at", new DataObject("@at", "@", true));
            objects.Add("@pipe", new DataObject("@pipe", "|", true));
            objects.Add("@break", new DataObject("@break", "\r\n", true));
            objects.Add("@cr", new DataObject("@cr", "\r", true));
            objects.Add("@lf", new DataObject("@lf", "\n", true));
            objects.Add("@crlf", new DataObject("@crlf", "\r\n", true));
            objects.Add("@quote", new DataObject("@quote", "\"", true));
        }

        public DataObject this[string name] {
            get {
                return objects[name];
            }
        }

        public DataObject GetObject(string key) {
            Match dim = ScriptRunner.DimensionEx.Match(key);
            if (dim.Success) {
                key = key.Replace(dim.Value, "");
                if (!ObjectExists(key)) {
                    throw new Exception("The variable is undefined");
                }
                int index;
                if (!int.TryParse(interpreter.JoinParm(new Parameter(dim.Value.RemoveBrackets()), false), out index)) {
                    throw new Exception("Could not parse array index");
                }
                return objects[key].GetArrayElement(index);
            }
            else {
                if (!ObjectExists(key)) {
                    throw new Exception("The variable is undefined");
                }
                return objects[key];
            }
        }

        public Type GetObjectType(string key) {
            return GetObject(key).Type;
        }

        public void SaveObject(string key, object value) {
            Match dim = ScriptRunner.DimensionEx.Match(key);
            if (dim.Success) {
                key = key.Replace(dim.Value, "");
                if (!ObjectExists(key)) {
                    throw new Exception("The array is undefined");
                }
                int index;
                if (!int.TryParse(interpreter.JoinParm(new Parameter(dim.Value.RemoveBrackets()), false), out index)) {
                    throw new Exception("Could not parse array index");
                }                
                SetArrayElement(key, index, value);
            }
            else {
                SaveObject(key, value, false);
            }
        }

        public void SaveObject(string key, object value, bool isMacro) {
            if (objects.ContainsKey(key)) {
                objects[key].SetData(value);
            }
            else {
                objects.Add(key, new DataObject(key, value, isMacro));
            }
        }

        public void DeleteObject(string key) {
            if (ObjectExists(key)) {
                this.objects.Remove(key);
            }
        }

        public bool ObjectExists(string key) {
            return objects.ContainsKey(key);
        }

        public void AllocateArray(string name, int dim) {
            SaveObject(name, new object[dim]);
        }

        public object GetArrayElement(string name, int element) {
            if (objects[name].Type != typeof(DataObject[])) {
                throw new Exception("The variable is not an array!");
            }
            return objects[name].GetArrayElement(element);
        }

        public void SetArrayElement(string name, int element, object value) {
            if (objects[name].Type != typeof(DataObject[])) {
                throw new Exception("The variable is not an array!");
            }
            objects[name].SetArrayElement(element, value);
        }

        public string ReplaceObjects(string input) {
            foreach (Match m in ScriptRunner.VariableEx.Matches(input)) {
                input = input.Replace(m.Value, GetObject(m.Value).GetData().ToString());
            }
            return input;
        }

        public Dictionary<string, DataObject>.Enumerator GetEnumerator() {
            return objects.GetEnumerator();
        }
    }
}
