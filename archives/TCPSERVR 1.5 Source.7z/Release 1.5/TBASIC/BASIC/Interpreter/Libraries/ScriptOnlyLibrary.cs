﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tbasic.Libraries;

namespace Tbasic.Interpreter.Libraries {
    public abstract class ScriptOnlyLibrary {

        protected Interpreter interpreter;

        public ScriptOnlyLibrary(Interpreter interpreter) {
            this.interpreter = interpreter;
        }

        public virtual Dictionary<string, ScriptCommandDelegate> GetCommandLibrary() {
            throw new NotImplementedException("A command library has not been implemented.");
        }

        public virtual Dictionary<string, CodeBlockDelegate> GetBlockLibrary() {
            throw new NotImplementedException("A block library has not been implemented.");
        }

        public virtual bool HasCommandLib() {
            return false;
        }

        public virtual bool HasBlockLib() {
            return false;
        }

        public abstract Dictionary<string, FunctionDelegate> GetFunctionLibrary();
    }
}
