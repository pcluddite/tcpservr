﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using Tbasic.Threads;

namespace Tbasic.Interpreter
{
    public class ScriptRunner
    {
        public const string VER = "TCPSERVR-BASIC 1.5.2014";

        public TBasicCore Core { get; set; }
        internal Interpreter Interpreter { get; set; }
        public bool ExitRequest { get; set; }
        public bool BreakRequest { get; set; }
        internal bool IsError { get; set; }
        internal int Status { get; set; }
        internal string ReturnValue { get; set; }
        internal int CurrentLine { get; set; }

        internal static Regex VariableEx = new Regex(@"((\w+|\d+)\$|\@(\w+|\d+))(\[.+\])*");
        internal static Regex DimensionEx = new Regex(@"\[.+\]");
        internal static Regex FunctionEx = new Regex(@"(\w+|\d+)\s*\(.*\)");
        internal static Regex Digits = new Regex(@"\d+");

        public ScriptRunner() {
            Construct(new TBasicCore());
        }

        public ScriptRunner(TBasicCore core) {
            Construct(core);
        }

        private void Construct(TBasicCore core) {
            this.IsError = false;
            this.ExitRequest = false;
            this.BreakRequest = false;
            this.Core = core;
            this.Interpreter = new Interpreter(this, new CustomLibrary());
            this.CurrentLine = 0;

            if (core.CurrentThread == null) {
                ThreadInfo tInfo = new ThreadInfo("TBASIC", "--", false, Thread.CurrentThread);
                core.Threads.Add(tInfo);
            }
        }

        public void RunScript(string script) {
            RunScript(script.Replace("\r\n", "\n").Split('\n'));
        }

        public void RunScript(string[] lines) {
            Code c = new Code(new CodeLineArray(lines), 0, BlockType.Main);
            this.Interpreter.UserLibrary.SetInterpreter(this.Interpreter);
            if (c.Functions != null) {
                foreach (CodeBlock cb in c.Functions) {
                    this.Interpreter.UserLibrary.AddFunction(cb);
                }
            }
            Process(c);

            if (Interpreter.FormLibrary.Count != 0 && !this.ExitRequest) {
                System.Windows.Forms.Application.Run(new FormLoader(Interpreter));
            }
        }

        internal string Process(Code c) {
            this.Status = 202;
            this.ReturnValue = "Accepted";
            this.BreakRequest = false;

            foreach (CodeHandle h in c.CodeHandles) {
                this.CurrentLine = h.ID;
                if (this.BreakRequest || this.ExitRequest) {
                    break;
                }
                if (h.Name.CompareTo("") == 0 || h.Name.StartsWith("'")) {
                    continue;
                }
                try {
                    if (h.IsCodeBlock) {
                        CodeBlock block = (CodeBlock)h.Code;
                        this.Interpreter.CmdLib.InvokeBlock(block);
                    }
                    else {
                        CodeLine line = (CodeLine)h.Code;
                        if (line.Name.EndsWith("$") || line.Name.EndsWith("]")) {
                            line.Text = "LET " + line.Text;
                        }
                        this.Interpreter.Execute(line);
                    }
                }
                catch (Exception ex) {
                    if (this.IsError) {
                        throw new Exception(ex.Message);
                    }
                    else {
                        doException(h.Name, ex.Message);
                    }
                }
            }
            return Status + " " + ReturnValue;
        }

        private void doException(string name, string error) {
            this.IsError = true;
            throw new Exception(string.Format(
                "An error occoured at {1} on line {0}:\r\n{2}", this.CurrentLine + 1, name.ToUpper(), error));
        }

        private bool isLoop(BlockType bt) {
            return (bt == BlockType.Do || bt == BlockType.While || bt == BlockType.For);
        }
    }
}
