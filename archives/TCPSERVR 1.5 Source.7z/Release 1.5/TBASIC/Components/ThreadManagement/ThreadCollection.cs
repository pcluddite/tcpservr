﻿using System;
using System.Threading;
using System.Text;
using System.Diagnostics;
using System.Collections.Generic;
using Tbasic.Errors;

namespace Tbasic.Threads {

    public class ThreadCollection {

        private Dictionary<int, ThreadInfo> threads = new Dictionary<int, ThreadInfo>();

        public ThreadInfo this[int i] {
            get {
                return threads[i];
            }
        }

        public void Add(ThreadInfo thread) {
            threads.Add(thread.Thread.ManagedThreadId, thread);
        }

        public ThreadInfo GetThread(int id) {
            if (!Contains(id)) {
                throw new TException(404, "thread");
            }
            return threads[id];
        }

        public void Remove(int id) {
            if (!Contains(id)) {
                throw new TException(404, "thread");
            }
            threads.Remove(id);
        }

        public bool Contains(int id) {
            return threads.ContainsKey(id);
        }

        public Dictionary<int, ThreadInfo>.Enumerator GetEnumerator() {
            return threads.GetEnumerator();
        }

        public string GetManagedThreadList() {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("List of Managed Threads\r\n");
            sb.AppendLine(string.Format("{0, -6}{1, -18}{2,-17}{3,-18}{4}", "ID", "State", "Client", "Start", "End"));
            int running = 0;

            foreach (var t in this.threads) {
                if (t.Value.Thread.ThreadState == System.Threading.ThreadState.Running) {
                    running++;
                }

                string endTime = "-";

                if (t.Value.EndTime != DateTime.MaxValue) {
                    endTime = t.Value.EndTime.ToString("MM/dd/yy hh:mm:ss");
                }
                sb.AppendLine(string.Format("{0, 4}  {1, -18}{2,-17}{3,-18}{4}",
                    t.Key, t.Value.ThreadState, t.Value.Client,
                    t.Value.StartTime.ToString("MM/dd/yy hh:mm:ss"), endTime));
            }
            if (running == 1) {
                sb.AppendLine(string.Format("\r\n{0,6} thread is running.", 1));
            }
            else {
                sb.AppendLine(string.Format("\r\n{0,6} threads are running.", running));
            }
            return sb.ToString();
        }

        public string GetProcessThreadList() {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("List of all threads\r\n");
            int i = 0;
            sb.AppendLine(string.Format("    {0, -10}{1, -17}{2,-15}", "ID", "State", "Processor Time"));
            int running = 0;
            foreach (ProcessThread t in Process.GetCurrentProcess().Threads) {
                if (t.ThreadState == System.Diagnostics.ThreadState.Running) { running++; }

                sb.AppendLine(string.Format("    {0, -10}{1, -17}{2,-15}", t.Id, t.ThreadState, t.StartTime));
                i++;
            }
            if (running == 1) {
                sb.AppendLine(string.Format("\r\n{0,6} thread is running.", 1));
            }
            else {
                sb.AppendLine(string.Format("\r\n{0,6} threads are running.", running));
            }
            return sb.ToString();
        }

        public void Clean() {
            List<int> toRemove = new List<int>();
            foreach (var v in this) {
                if (v.Value.ThreadState == System.Threading.ThreadState.Stopped ||
                    v.Value.ThreadState == System.Threading.ThreadState.Aborted) {
                    toRemove.Add(v.Key);
                }
            }

            foreach (int id in toRemove) {
                this.Remove(id);
            }
        }
    }
}