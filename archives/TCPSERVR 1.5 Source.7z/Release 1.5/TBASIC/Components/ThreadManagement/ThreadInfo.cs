﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.IO.Pipes;
using System.IO;
using Tbasic.Components;

namespace Tbasic.Threads {

    public class ThreadInfo {

        public bool LogHistory { get; set; }

        private Stream stream;

        public Stream GetStream() {
            return stream;
        }

        public void SetStream(Stream s) {
            stream = s;
        }

        public ThreadInfo(Socket client, bool logHistory, Thread t) {
            init((client.RemoteEndPoint as IPEndPoint).Address.ToString(),
                 (client.RemoteEndPoint as IPEndPoint).Port.ToString(), logHistory, t);
        }

        public ThreadInfo(string client, string port, bool logHistory, Thread t) {
            init(client, port, logHistory, t);
        }

        private void init(string client, string port, bool logHistory, Thread t) {
            endTime = DateTime.MaxValue;
            thread = t;
            name = client;
            this.port = port;
            Reports = new ReportCollection();
            report = new Report("Generic");
            LogHistory = logHistory;
            CurrentDirectory = Directory.GetCurrentDirectory();
        }

        private string curDir;
        public string CurrentDirectory {
            get {
                return curDir;
            }
            set {
                string newPath = value;
                if (newPath.Equals("\\")) {
                    newPath = Path.GetPathRoot(curDir);
                }
                else if (newPath.StartsWith("\\")) {
                    newPath = Path.Combine(Path.GetPathRoot(curDir), newPath.Remove(0, 1));
                }
                if (!Path.IsPathRooted(newPath)) {
                    newPath = Path.Combine(curDir, newPath);
                }
                newPath = Path.GetFullPath(newPath);
                if (!Directory.Exists(newPath)) {
                    throw new Errors.TException(404, newPath);
                }
                curDir = newPath;
            }
        }

        public ReportCollection Reports;

        private Thread thread;
        public Thread Thread {
            get {
                return thread;
            }
        }

        private string name;
        public string Client {
            get {
                return name;
            }
        }

        private string port;
        public string Port {
            get {
                return port;
            }
        }

        private DateTime startTime;
        public DateTime StartTime {
            get {
                return startTime;
            }
        }

        private DateTime endTime;
        public DateTime EndTime {
            get {
                return endTime;
            }
        }

        public string CurrentPipeName {
            get; set;
        }

        public bool UsingPipe {
            get; set;
        }

        private string currentTask;
        public string CurrentTask {
            get {
                return currentTask;
            }
        }

        public ThreadState ThreadState {
            get {
                return thread.ThreadState;
            }
        }

        public int ID {
            get {
                return thread.ManagedThreadId;
            }
        }

        public bool ForceGarbageCollection {
            get; set;
        }

        private Report report;

        public void Start(object client) {
            AddTask("Initializing");
            startTime = DateTime.Now;
            thread.Start(client);
        }

        public void AddTask(string task) {
            currentTask = task;
            report.AddTask(task);
        }

        public void CreateReport(TMessage tMsg) {
            report = new Report(tMsg.Args[0].ToUpper());
            if (LogHistory) {
                Reports.AddReport(tMsg, report);
            }
        }

        public void CompletedReport(TMessage tMsg) {
            tMsg.Process(tMsg.DataString.Roof(40));
            report.Completed();
            report = new Report("Generic");
        }

        public void Abort() {
            AddTask("Aborting");
            SetEndTimeToNow();
            thread.Abort();
        }

        public void End() {
            AddTask("Ending");
            SetEndTimeToNow();
            thread.Abort();
        }

        public void SetEndTimeToNow() {
            endTime = DateTime.Now;
        }
    }
}
