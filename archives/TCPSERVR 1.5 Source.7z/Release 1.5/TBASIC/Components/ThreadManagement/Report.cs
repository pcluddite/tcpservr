﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tbasic.Threads {
    public class Report {

        private Dictionary<string, bool> tasks = new Dictionary<string, bool>();

        private string name;
        private string last = "";

        public Report(string name) {
            this.name = name;
        }

        public void RemoveTask(string task) {
            tasks.Remove(task);
        }

        public void AddTask(string task) {
            if (!last.Equals("")) {
                Completed();
            }
            tasks.Add(task, false);
            last = task;
        }

        public void Completed() {
            SetCompleted(last, true);
        }

        public new string ToString() {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("|\n|{0,-25}{1}\n|", " ", name + " Command Report");
            foreach (var v in tasks) {
                sb.AppendFormat("\n{0,-50}{1}", v.Key + "...", v.Value ? "Completed" : "Working");
            }
            return sb.ToString();
        }

        public void SetCompleted(string task, bool completed) {
            tasks[task] = completed;
        }

        public bool IsCompleted(string task) {
            return tasks[task];
        }
    }
}
