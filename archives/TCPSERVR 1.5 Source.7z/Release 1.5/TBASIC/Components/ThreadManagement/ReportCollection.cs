﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tbasic.Errors;
using Tbasic.Components;

namespace Tbasic.Threads {
    public class ReportCollection {

        private Dictionary<TMessage, Report> reports = new Dictionary<TMessage, Report>();

        public Dictionary<TMessage, Report> Reports {
            get {
                return reports;
            }
        }

        public void Clear() {
            reports.Clear();
        }

        public void AddReport(TMessage msg, Report report) {
            reports.Add(msg, report);
        }

        public Report GetReport(TMessage msg) {
            if (reports[msg] == null) {
                throw new TException(204, "That message did not turn in a report", false);
            }
            return reports[msg];
        }

        public Report GetReportFromId(int id) {
            foreach (var v in reports) {
                if (v.Key.ID == id) {
                    if (v.Value == null) {
                        throw new TException(204, "That message did not turn in a report", false);
                    }
                    return v.Value;
                }
            }
            throw new TException(404, "message");
        }

        public Report[] GetReportsFromName(string cmdName) {
            return
                (from report in reports
                where report.Key.Args[0].Equals(cmdName, StringComparison.OrdinalIgnoreCase)
                select report.Value).ToArray();
        }

        public Dictionary<TMessage, Report>.Enumerator GetEnumerator() {
            return reports.GetEnumerator();
        }
    }
}
