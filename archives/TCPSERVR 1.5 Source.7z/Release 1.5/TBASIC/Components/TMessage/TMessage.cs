﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tbasic.Errors;
using System.IO;

namespace Tbasic.Components {
    public class TMessage {

        private byte[] raw;
        private string[] cmd;

        public bool IsEncrypted {
            get {
                return Encoding.UTF8.GetString(raw, 0, 3).Equals("ENC");
            }
        }

        /// <summary>
        /// The raw byte data of the message including the leading 7 bytes
        /// </summary>
        public byte[] RawData {
            get {
                return raw;
            }
        }

        /// <summary>
        /// The byte data of the message excluding the leading 7 bytes
        /// </summary>
        public byte[] Data {
            get {
                return this.RawData.Skip(7).ToArray();
            }
        }

        private string original;

        /// <summary>
        /// The data as a string without symbols
        /// </summary>
        public string DataString {
            get {
                return RemoveSymbols(original);
            }
        }

        /// <summary>
        /// The data as a string including the symbols
        /// </summary>
        public string UnformattedDataString {
            get {
                return original;
            }
        }

        /// <summary>
        /// The arguments of the message excluding quotes
        /// </summary>
        public string[] Args {
            get {
                return cmd;
            }
        }

        /// <summary>
        /// The arguments of the message including quotes
        /// </summary>
        public string[] ArgsOriginal {
            get {
                return ParseCmd(original, true);
            }
        }

        /// <summary>
        /// The length of the message excluding the preceding 7 bytes
        /// </summary>
        public int Length {
            get {
                return this.Data.Length;
            }
        }

        /// <summary>
        /// Temporary storage for 3rd party use
        /// </summary>
        public object Storage { get; set; }

        private DateTime startTime;

        /// <summary>
        /// Gets the time the TMessage object was created
        /// </summary>
        public DateTime CreationTime {
            get {
                return startTime;
            }
        }

        /// <summary>
        /// Gets or sets an ID for this message
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Initialize a new TMessage object
        /// </summary>
        public TMessage() {
            startTime = DateTime.Now;
        }

        /// <summary>
        /// Initialize a new TMessage object
        /// </summary>
        /// <param name="id">An identification number to assign the message</param>
        public TMessage(int id) {
            this.ID = id;
            startTime = DateTime.Now;
        }

        /// <summary>
        /// The writer stream
        /// </summary>
        public Stream Stream {
            get; set;
        }

        /// <summary>
        /// Initialize a new TMessage object
        /// </summary>
        /// <param name="writeStream">The stream on which to write messages</param>
        public TMessage(Stream writeStream) {
            Stream = writeStream;
        }

        /// <summary>
        /// Process raw byte data
        /// </summary>
        /// <param name="data">The byte array to process (including the preceding 7 bytes)</param>
        public void Process(byte[] data) {
            Process(data, false);
        }

        /// <summary>
        /// Process raw byte data
        /// </summary>
        /// <param name="data">The byte array to process</param>
        /// <param name="addPrecedingBytes">Sepcify whether or not the preceding bytes should be prepended</param>
        public void Process(byte[] data, bool addPrecedingBytes) {
            if (addPrecedingBytes) {
                List<byte> newData = new List<byte>();
                newData.AddRange(TReceiver.TCP);
                newData.AddRange(BitConverter.GetBytes(data.Length));
                newData.AddRange(data);
                data = newData.ToArray();
            }
            raw = new byte[data.Length];
            data.CopyTo(raw, 0);
            original = Encoding.UTF8.GetString(Data, 0, Data.Length);
            cmd = ParseCmd(original, false);
        }

        /// <summary>
        /// Process an array of arguments
        /// </summary>
        /// <param name="args">The argument array</param>
        public void Process(params object[] args) {
            for (int i = 0; i < args.Length; i++) {
                args[i] = AddSymbols(args[i].ToString());
            }
            Process(buildString(args));
        }

        private string buildString(object[] args) {
            int i = 1;
            StringBuilder sb = new StringBuilder(args[0].ToString());
            while (i < args.Length) {
                if (args[i].ToString().Contains(' ') || args[i].ToString().Equals("")) {
                    sb.Append(" \"" + args[i] + "\"");
                }
                else {
                    sb.Append(" " + args[i]);
                }
                i++;
            }
            return sb.ToString();
        }

        private string AddSymbols(string s) {
            return s.Replace("@", "@at").Replace("\"", "@quote").Replace("|", "@pipe").Replace("\r\n", "@break");
        }

        /// <summary>
        /// Process a string message
        /// </summary>
        /// <param name="message">The message string without any byte header</param>
        public void Process(string message) {
            List<byte> data = new List<byte>();
            data.AddRange(TReceiver.TCP);
            data.AddRange(BitConverter.GetBytes(message.Length));
            data.AddRange(Encoding.UTF8.GetBytes(message));
            this.Process(data.ToArray());
        }
        
        /// <summary>
        /// Send the TMessage
        /// </summary>
        public virtual void Send() {
            Stream.Write(raw, 0, raw.Length);
        }

        /// <summary>
        /// Send the TMessage
        /// </summary>
        /// <param name="data">The message to process</param>
        public virtual void Send(string data) {
            Process(data);
            Send();
        }

        /// <summary>
        /// Send the TMessage
        /// </summary>
        /// <param name="data">The paramaters of the message to process</param>
        public virtual void Send(params object[] data) {
            Process(data);
            Send();
        }

        /// <summary>
        /// Send the TMessage
        /// </summary>
        /// <param name="data">The raw data to process and send</param>
        public virtual void Send(byte[] data) {
            Process(data);
            Send();
        }

        /// <summary>
        /// Proces and encrypt a new message
        /// </summary>
        /// <param name="dataString">The plain-text message to encrypt</param>
        /// <param name="encryptionKey">The encryption key to apply</param>
        public void ProcessEncrypt(string dataString, string encryptionKey) {
            Process(dataString);
            raw = Encrypt(dataString, encryptionKey);
        }

        private byte[] Encrypt(string message, string pass) {
            using (TcpSecure tcpSecure = new TcpSecure(pass)) {
                byte[] encrypted = tcpSecure.Encrypt(Encoding.UTF8.GetBytes(message));
                byte[] data = new byte[7 + encrypted.Length];
                Encoding.UTF8.GetBytes("ENC").CopyTo(data, 0);
                BitConverter.GetBytes(encrypted.Length).CopyTo(data, 3);
                encrypted.CopyTo(data, 7);
                return data;
            }
        }

        private string[] ParseCmd(string msg, bool keepQuotes) {
            string[] cmd = ParseArguments(msg, keepQuotes);
            for (int i = 0; i < cmd.Length; i++) {
                cmd[i] = RemoveSymbols(cmd[i]);
            }
            return cmd;
        }

        private string RemoveSymbols(string s) {
            return s.Replace("@break", "\r\n").Replace("@pipe", "|").Replace("@quote", "\"").Replace("@at", "@");
        }

        private string[] ParseArguments(string commandLine) {
            return ParseArguments(commandLine, false);
        }

        private string[] ParseArguments(string commandLine, bool keepQuotes) {
            char[] parmChars = commandLine.ToCharArray();
            bool inQuote = false;
            for (int index = 0; index < parmChars.Length; index++) {
                if (parmChars[index] == '"')
                    inQuote = !inQuote;
                if (!inQuote && parmChars[index] == ' ')
                    parmChars[index] = '\n';
            }
            if (keepQuotes) {
                return (new string(parmChars)).Split('\n');
            }
            else {
                return (new string(parmChars)).Replace("\"", "").Split('\n');
            }
        }

        /// <summary>
        /// Appends new arguments to the message
        /// </summary>
        /// <param name="args">The new arguments to append</param>
        public void AppendArguments(params string[] args) {
            string[] newArgs = new string[args.Length + cmd.Length];
            cmd.CopyTo(newArgs, 0);
            args.CopyTo(newArgs, cmd.Length);
            Process(newArgs);
        }

        /// <summary>
        /// Assigns new data to an argument
        /// </summary>
        /// <param name="index">The index of the argument</param>
        /// <param name="data">The new string data to assign</param>
        public void SetArgument(int index, string data) {
            cmd[index] = data;
            Process(cmd);
        }

        /// <summary>
        /// Throws a TException if the parameter does not match the number of elements
        /// </summary>
        /// <param name="count">The number of elements required for the command to execute</param>
        public void ConfirmArgumentCount(int count) {
            if (cmd.Length != count) {
                throw new TException(400, (count - 1) + " argument(s) expected");
            }
        }

        /// <summary>
        /// Gets an argument as a string. Throws a TException if the argument is out of bounds
        /// </summary>
        /// <param name="index">The index of the argument</param>
        /// <returns></returns>
        public string GetArgument(int index) {
            if (index < cmd.Length) {
                return cmd[index];
            }
            throw new TException(400);
        }

        /// <summary>
        /// Gets an argument as a specific type. Throws a TException if the argument is out of bounds or is not an exceptable type
        /// </summary>
        /// <typeparam name="T">The specific argument type</typeparam>
        /// <param name="index">The index of the argument</param>
        /// <returns></returns>
        public T GetArgument<T>(int index) {
            T result;
            if (GetArgument(index).TryParse<T>(out result)) {
                return result;
            }
            throw new TException(400, "arg[" + index + "] not " + typeof(T).Name);
        }

        /// <summary>
        /// Gets an argument as a string. Throws a TException if the argument is out of bounds or is not listed as an exceptable string value
        /// </summary>
        /// <param name="index">The index of the argument</param>
        /// <param name="type">The type the argument represents</param>
        /// <param name="values">Acceptable string values</param>
        /// <returns></returns>
        public string GetArgument(int index, string type, params string[] values) {
            string arg = GetArgument(index);
            foreach (string val in values) {
                if (val.Equals(arg, StringComparison.OrdinalIgnoreCase)) {
                    return arg;
                }
            }
            throw new TException(400, "arg[" + index + "] not " + type);
        }

        /// <summary>
        /// Copies the TMessage
        /// </summary>
        /// <returns>A new TMessage object with the same data</returns>
        public TMessage Clone() {
            TMessage result = new TMessage(ID);
            result.Storage = Storage;
            result.startTime = startTime;
            result.Process(raw);
            return result;
        }

        /// <summary>
        /// Returns any arguments that begin with a specified character as a manageable dictionary
        /// </summary>
        /// <param name="separator">The character that separates the key from its value</param>
        /// <param name="switchStart">The string that specifies the beginning of the command switch</param>
        /// <returns>A dictionary of command switches and their values</returns>
        public Dictionary<string, string> GetLooseArgs(char separator, string switchStart) {
            Dictionary<string, string> result = new Dictionary<string, string>();
            List<string> args = Args.ToList();
            for (int index = 0; index < args.Count; index++) {
                if (args[index].StartsWith(switchStart)) {
                    string arg = args[index].Remove(0, switchStart.Length);
                    if (arg.Contains(separator)) {
                        string[] broken = arg.Split(separator);
                        if (arg.Contains(broken[0])) {
                            throw new TException(400, "The switch was defined more than once");
                        }
                        result.Add(broken[0], broken[1]);
                    }
                    else if (!arg.Contains(arg)) {
                        result.Add(arg, null);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Returns any arguments that contain a separator character as a manageable dictionary
        /// </summary>
        /// <param name="separator">The character that separates the key from its value</param>
        /// <returns>A dictionary of the argument keys and their values</returns>
        public Dictionary<string, string> GetLooseArgs(char separator) {
            Dictionary<string, string> result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            List<string> args = Args.ToList();
            for (int index = 0; index < args.Count; index++) {
                if (args[index].Contains(separator)) {
                    string key = args[index].Remove(args[index].IndexOf(separator));
                    result.Add(key, args[index].Remove(0, key.Length + 1));
                }
                else if (!result.ContainsKey(args[index])) {
                    result.Add(args[index], null);
                }
            }
            return result;
        }
    }
}
