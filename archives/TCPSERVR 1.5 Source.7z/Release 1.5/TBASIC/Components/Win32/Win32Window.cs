﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using Tbasic.Components;
using Tbasic.Errors;

namespace Tbasic.Win32 {
    internal class Win32Window : IDisposable {
        
        private const int ERROR_CLASS_ALREADY_EXISTS = 1410;

        public bool Disposed { get; private set;}
        public IntPtr Handle { get; private set; }

        public void Dispose() {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing) {
            if (!Disposed) {
                if (disposing) {
                    // Dispose managed resources
                }

                // Dispose unmanaged resources
                if (Handle != IntPtr.Zero) {
                    User32.DestroyWindow(Handle);
                    Handle = IntPtr.Zero;
                }

            }
        }

        public Win32Window(string class_name) {

            if (class_name == null) {
                throw new TException(400, "Class name is null");
            }
            if (class_name == String.Empty) {
                throw new TException(400, "Class name is empty");
            }

            m_wnd_proc_delegate = CustomWndProc;

            // Create WNDCLASS
            WNDCLASS wind_class = new WNDCLASS();
            wind_class.lpszClassName = class_name;
            wind_class.lpfnWndProc = Marshal.GetFunctionPointerForDelegate(m_wnd_proc_delegate);

            UInt16 class_atom = User32.RegisterClassW(ref wind_class);

            int last_error = Marshal.GetLastWin32Error();

            if (class_atom == 0 && last_error != ERROR_CLASS_ALREADY_EXISTS) {
                throw new TException(409, "Could not register. Class already exists", false);
            }

            // Create window
            Handle = User32.CreateWindowExW(
                0,
                class_name,
                String.Empty,
                0,
                0,
                0,
                0,
                0,
                IntPtr.Zero,
                IntPtr.Zero,
                IntPtr.Zero,
                IntPtr.Zero
            );
        }

        public bool Show() {
            return Show(1);
        }

        public bool Show(uint show) {
            return Win32.User32.ShowWindow(Handle, show);
        }

        public bool Destroy() {
            return User32.DestroyWindow(Handle);
        }

        public IntPtr CustomWndProc(uint msg, IntPtr wParam, IntPtr lParam) {
            return User32.DefWindowProcW(Handle, msg, wParam, lParam);
        }

        private static IntPtr CustomWndProc(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam) {
            return User32.DefWindowProcW(hWnd, msg, wParam, lParam);
        }

        private WndProc m_wnd_proc_delegate;
    }
}
