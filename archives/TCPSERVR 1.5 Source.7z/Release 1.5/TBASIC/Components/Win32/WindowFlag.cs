﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tbasic.Win32 {
    internal class WindowFlag {

        public Dictionary<string, uint> Flags;
        public Dictionary<string, int> States;

        public WindowFlag() {
            Flags = new Dictionary<string, uint>();
            Flags.Add("SW_HIDE", 0);
            Flags.Add("SW_SHOWNORMAL", 1);
            Flags.Add("SW_NORMAL", 1);
            Flags.Add("SW_SHOWMINIMIZED", 2);
            Flags.Add("SW_SHOWMAXIMIZED", 3);
            Flags.Add("SW_MAXIMIZE", 3);
            Flags.Add("SW_SHOWNOACTIVATE", 4);
            Flags.Add("SW_SHOW", 5);
            Flags.Add("SW_MINIMIZE", 6);
            Flags.Add("SW_SHOWMINNOACTIVE", 7);
            Flags.Add("SW_SHOWNA", 8);
            Flags.Add("SW_RESTORE", 9);

            States = new Dictionary<string, int>();
            States.Add("EXISTING", 1);
            States.Add("VISIBLE", 2);
            States.Add("ENABLED", 4);
            States.Add("ACTIVE", 8);
            States.Add("MINIMIZED", 16);
            States.Add("MAXIMIZED", 32);
        }

        public const UInt32 SW_HIDE = 0;
        public const UInt32 SW_SHOWNORMAL = 1;
        public const UInt32 SW_NORMAL = 1;
        public const UInt32 SW_SHOWMINIMIZED = 2;
        public const UInt32 SW_SHOWMAXIMIZED = 3;
        public const UInt32 SW_MAXIMIZE = 3;
        public const UInt32 SW_SHOWNOACTIVATE = 4;
        public const UInt32 SW_SHOW = 5;
        public const UInt32 SW_MINIMIZE = 6;
        public const UInt32 SW_SHOWMINNOACTIVE = 7;
        public const UInt32 SW_SHOWNA = 8;
        public const UInt32 SW_RESTORE = 9;
    }
}
