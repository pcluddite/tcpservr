﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Tbasic.Errors;
using Tbasic.Components;
using Tbasic.Interpreter;

namespace Tbasic.Libraries {
    public class FileLibrary : TBasicLibrary {

        public FileLibrary(TBasicCore core)
            : base(core) {
        }

        public override void ConstructLibrary() {
            Add("7zr", SevenZip);
            Add("7za", SevenZip);
            Add("get", Get);
            Add("getdir", GetDir);
            Add("getmult", GetMult);
            Add("put", Put);
            Add("recycle", Recycle);
            Add("getfileattributes", GetFileAttributes);
            Add("setfileattributes", SetFileAttributes);
            Add("getfileinfo", GetFileInfo);
            Add("setaccessdate", SetAccessDate);
            Add("setcreateddate", SetCreatedDate);
            Add("setmodifieddate", SetModifiedDate);
            Add("pwd", Pwd);
            Add("cd", Cd);
            Add("chdir", Cd);
            Add("mkdir", Cmd);
            Add("md", Cmd);
            Add("ren", Cmd);
            Add("rename", Cmd);
            Add("del", Cmd);
            Add("erase", Cmd);
            Add("rd", Cmd);
            Add("rmdir", Cmd);
            Add("copy", Cmd);
            Add("move", Cmd);
            Add("dir", Cmd);
            Add("cmd", Cmd);
        }

        public string SevenZip(TMessage tMsg) {
            string result = SevenZip(tMsg.DataString.Remove(0, 3).TrimStart());
            return "203 " + result;
        }

        public string WriteTempFile(string name, byte[] file) {
            string path = Path.GetTempPath() + name;
            if (!File.Exists(path)) {
                File.WriteAllBytes(path, file);
            }
            return path;
        }

        private string GetFileName(string path) {
            if (!path.Contains("\\")) {
                return path;
            }
            return path.Substring(path.LastIndexOf('\\'));
        }

        public string Get(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            string path = core.GetRealPath(tMsg.Args[1]);
            if (!File.Exists(path)) {
                throw new TException(404, "file path");
            }
            core.CurrentThread.ForceGarbageCollection = true;
            return "200 " + Convert.ToBase64String(File.ReadAllBytes(path));
        }

        public string GetMult(TMessage tMsg) {
            if (tMsg.Length < 2) {
                throw new TException(400);
            }
            StringBuilder files = new StringBuilder();
            for (int i = 1; i < tMsg.Args.Length; i++) {
                string path = core.GetRealPath(tMsg.Args[i]);
                if (!File.Exists(path) && !Directory.Exists(path)) {
                    throw new TException(404);
                }
                files.AppendFormat(" \"{0}\"", tMsg.Args[i]);
            }
            string tmp = Path.GetTempFileName() + ".zip";
            string fart = SevenZip("a -r \"" + tmp + "\" " + files.ToString().Trim());
            string result = Convert.ToBase64String(File.ReadAllBytes(tmp));
            File.Delete(tmp);
            core.CurrentThread.ForceGarbageCollection = true;
            return "200 " + result;
        }

        public string GetDir(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            string path = core.GetRealPath(tMsg.Args[1]);
            if (!Directory.Exists(path)) {
                throw new TException(404);
            }
            string tmp = Path.GetTempFileName() + ".zip";
            SevenZip("a -r \"" + tmp + "\" \"" + path + "\"");
            string result =  Convert.ToBase64String(File.ReadAllBytes(tmp));
            File.Delete(tmp);
            core.CurrentThread.ForceGarbageCollection = true;
            return "200 " + result;
        }

        public string Put(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            string path = core.GetRealPath(tMsg.Args[1]);
            if (File.Exists(path)) {
                throw new TException(409, "File already exists");
            }
            int len = tMsg.Args[2].Length;
            using (FileStream writer = File.Open(path, FileMode.CreateNew)) {
                using (MemoryStream mem = new MemoryStream(Convert.FromBase64String(tMsg.Args[2]))) {
                    tMsg.Process(tMsg.DataString.Roof(40));
                    tMsg = tMsg.Clone();
                    byte[] data = new byte[1];
                    while (mem.Read(data, 0, 1) != 0) {
                        writer.Write(data, 0, data.Length);
                    }
                }
            }
            core.CurrentThread.ForceGarbageCollection = true;
            return "200 " + len + " byte(s) Uploaded";
        }

        public string Recycle(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            string path = core.GetRealPath(tMsg.Args[1]);
            if (!File.Exists(path)) {
                throw new TException(404);
            }
            FileSystem.DeleteFile(path, UIOption.OnlyErrorDialogs, RecycleOption.SendToRecycleBin);
            return "202 Accepted";
        }

        public string GetFileInfo(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            string path = core.GetRealPath(tMsg.Args[1]);
            StringBuilder info = new StringBuilder();
            if (File.Exists(path)) {
                FileInfo fInfo = new FileInfo(path);
                info.AppendFormat("{0,-12}{1}\n", "Created", fInfo.CreationTime);
                info.AppendFormat("{0,-12}{1}\n", "Modified", fInfo.LastWriteTime);
                info.AppendFormat("{0,-12}{1}\n", "Accessed", fInfo.LastAccessTime);
                info.AppendFormat("{0,-12}{1}\n", "Size", fInfo.Length);
            }
            else if (Directory.Exists(path)) {
                DirectoryInfo dInfo = new DirectoryInfo(path);
                info.AppendFormat("{0,-12}{1}\n", "Created", dInfo.CreationTime);
                info.AppendFormat("{0,-12}{1}\n", "Modified", dInfo.LastWriteTime);
                info.AppendFormat("{0,-12}{1}\n", "Accessed", dInfo.LastAccessTime);
                info.AppendFormat("{0,-12}{1}\n", "Item(s)", dInfo.GetFiles().Length);
            }
            else {
                throw new TException(404, "File path");
            }
            info.AppendFormat("{0,-12}{1}", "Attributes", GetStringFromAttributes(File.GetAttributes(path)));
            return "200 " + info.ToString();
        }

        public string GetFileAttributes(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            string path = core.GetRealPath(tMsg.Args[1]);
            FileAttributes current = File.GetAttributes(path);
            return "200 " + GetStringFromAttributes(current);
        }

        public string SetFileAttributes(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            string path = core.GetRealPath(tMsg.Args[1]);
            FileAttributes current = File.GetAttributes(path);
            if ((current & FileAttributes.ReadOnly) == FileAttributes.ReadOnly) {
                File.SetAttributes(path, current & ~FileAttributes.ReadOnly);
            }
            FileAttributes attributes = GetAttributesFromString(tMsg.Args[2]);
            File.SetAttributes(path, attributes);
            return "200 OK";
        }

        private string GetStringFromAttributes(FileAttributes attributes) {
            StringBuilder sb = new StringBuilder();
            if ((attributes & FileAttributes.Archive) == FileAttributes.Archive) { sb.Append("a"); }
            if ((attributes & FileAttributes.Compressed) == FileAttributes.Compressed) { sb.Append("c"); }
            if ((attributes & FileAttributes.Encrypted) == FileAttributes.Encrypted) { sb.Append("e"); }
            if ((attributes & FileAttributes.Hidden) == FileAttributes.Hidden) { sb.Append("h"); }
            if ((attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly) { sb.Append("r"); }
            if ((attributes & FileAttributes.System) == FileAttributes.System) { sb.Append("s"); }
            return sb.ToString();
        }

        private FileAttributes GetAttributesFromString(string attributes) {
            FileAttributes result = new FileAttributes();
            foreach (char c in attributes.ToUpper().ToCharArray()) {
                switch (c) {
                    case 'A': result = result | FileAttributes.Archive; break;
                    case 'C': result = result | FileAttributes.Compressed; break;
                    case 'E': result = result | FileAttributes.Encrypted; break;
                    case 'H': result = result | FileAttributes.Hidden; break;
                    case 'R': result = result | FileAttributes.ReadOnly; break;
                    case 'S': result = result | FileAttributes.System; break;
                    default:
                        throw new TException(400, c + " not a valid attribute");
                }
            }
            return result;
        }

        public string SetAccessDate(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            string path = core.GetRealPath(tMsg.Args[1]);
            if (File.Exists(path)) {
                File.SetLastAccessTime(path, DateTime.Parse(tMsg.Args[2]));
                return "200 " + File.GetLastAccessTime(path).ToString();
            }
            else if (Directory.Exists(path)) {
                Directory.SetLastAccessTime(path, DateTime.Parse(tMsg.Args[2]));
                return "200 " + Directory.GetLastAccessTime(path).ToString();
            }
            throw new TException(404);
        }

        public string SetModifiedDate(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            string path = core.GetRealPath(tMsg.Args[1]);
            if (File.Exists(path)) {
                File.SetLastWriteTime(path, DateTime.Parse(tMsg.Args[2]));
                return "200 " + File.GetLastWriteTime(path).ToString();
            }
            else if (Directory.Exists(path)) {
                Directory.SetLastWriteTime(path, DateTime.Parse(tMsg.Args[2]));
                return "200 " + Directory.GetLastWriteTime(path).ToString();
            }
            throw new TException(404);
        }

        public string SetCreatedDate(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            string path = core.GetRealPath(tMsg.Args[1]);
            if (File.Exists(path)) {
                File.SetCreationTime(path, DateTime.Parse(tMsg.Args[2]));
                return "200 " + File.GetCreationTime(path).ToString();
            }
            else if (Directory.Exists(path)) {
                Directory.SetCreationTime(path, DateTime.Parse(tMsg.Args[2]));
                return "200 " + Directory.GetCreationTime(path).ToString();
            }
            throw new TException(404);
        }

        public string Pwd(TMessage tMsg) {
            return "200 " + core.CurrentThread.CurrentDirectory;
        }

        public string Cd(TMessage tMsg) {
            string setDir;
            if (tMsg.Args.Length > 2) {
                setDir = tMsg.DataString.Remove(0, tMsg.Args[0].Length);
            }
            else if (tMsg.Args.Length == 2) {
                setDir = tMsg.Args[1];
            }
            else {
                return Pwd(tMsg);
            }
            core.CurrentThread.CurrentDirectory = setDir;
            return "200 " + core.CurrentThread.CurrentDirectory;
        }

        public string Cmd(TMessage tMsg) {
            string msg = tMsg.DataString;
            if (tMsg.Args[0].ToLower().Equals("cmd")) { 
                msg = msg.Remove(0, 3);
            }
            string result = Shell(msg.Trim());
            if (result.Equals("")) {
                return "204 No Content";
            }
            else {
                return "203 " + result;
            }
        }

        public string SevenZip(string args) {
            string result;
            string path = WriteTempFile("7za.exe", Properties.Resources._7za);
            using (System.Diagnostics.Process p = new System.Diagnostics.Process()) {
                p.StartInfo.Arguments = args;
                p.StartInfo.FileName = path;
                p.StartInfo.WorkingDirectory = core.CurrentThread.CurrentDirectory;
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.CreateNoWindow = true;
                p.Start();
                result = p.StandardOutput.ReadToEnd();
                p.WaitForExit();
                switch (p.ExitCode) {
                    case 1:
                        throw new TException(206, result);
                    case 2:
                        throw new TException(500, result);
                    case 7:
                        throw new TException(400, result);
                    case 8:
                        throw new TException(507, "Not enough memory to complete the operation");
                    case 255:
                        throw new TException(500, "Request was cancelled by user");
                }
            }
            return result;
        }

        private string Shell(string command) {
            using (System.Diagnostics.Process console = new System.Diagnostics.Process()) {
                core.AddTask("Generating cmd.exe start info");
                console.StartInfo.FileName = "cmd.exe";
                console.StartInfo.Arguments = "/c " + command;
                console.StartInfo.RedirectStandardOutput = true;
                console.StartInfo.RedirectStandardError = true;
                console.StartInfo.UseShellExecute = false;
                console.StartInfo.CreateNoWindow = true;
                console.StartInfo.WorkingDirectory = core.CurrentThread.CurrentDirectory;
                core.AddTask("Starting cmd.exe with arguments");
                console.Start();
                core.AddTask("Redirecting output from console...");
                string output = console.StandardOutput.ReadToEnd();
                core.AddTask("Waiting for console to exit...");
                console.WaitForExit();
                if (console.ExitCode != 0) {
                    throw new TException(500, output, false);
                }
                return output;
            }
        }
    }
}
