﻿using System;
using System.Collections.Generic;
using Tbasic.Interpreter;

namespace Tbasic.Libraries {
    public abstract class TBasicLibrary {
        
        private Dictionary<string, GenericCommandDelegate> lib;
        protected TBasicCore core;

        public TBasicLibrary(TBasicCore core) {
            this.core = core;
            lib = new Dictionary<string, GenericCommandDelegate>();
            ConstructLibrary();
        }

        public abstract void ConstructLibrary();

        public void Add(string name, GenericCommandDelegate cmd) {
            lib.Add(name, cmd);
        }

        public bool Remove(string name) {
            return lib.Remove(name);
        }

        public GenericCommandDelegate this[string name] {
            get {
                return lib[name];
            }
        }

        public bool ContainsKey(string name) {
            return lib.ContainsKey(name);
        }

        public Dictionary<string, GenericCommandDelegate>.Enumerator GetEnumerator() {
            return lib.GetEnumerator();
        }
    }
}
