﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using Tbasic.Borrowed;
using Tbasic.Components;
using Tbasic.Errors;
using Tbasic.Interpreter;
using Tbasic.Win32;

namespace Tbasic.Libraries {

    public class WindowLibrary : TBasicLibrary {

        private WindowFlag windowFlags;

        public WindowLibrary(TBasicCore core)
            : base(core) {
                windowFlags = new WindowFlag();
        }

        public override void ConstructLibrary() {
            Add("winactivate", WinActivate);
            Add("winclose", WinClose);
            Add("winkill", WinKill);
            Add("winmove", WinMove);
            Add("winsize", WinSize);
            Add("wingethandle", WinGetHandle);
            Add("wingettitle", WinGetTitle);
            Add("winsettitle", WinSetTitle);
            Add("winsettrans", WinSetTrans);
            Add("winsetstate", WinSetState);
            Add("winlistinfo", WinListInfo);
            Add("wininfo", WinInfo);
            Add("winlist", WinList);
            Add("removex", WinRemoveClose);
            Add("winremoveclose", WinRemoveClose);
            Add("getscreen", GetScreen);
            Add("winpicture", WinPicture);
            Add("winexists", WindowExists);
        }

        public static void WinRemoveClose(IntPtr hwnd) {;
            IntPtr hMenu = User32.GetSystemMenu(hwnd, false);
            int menuItemCount = User32.GetMenuItemCount(hMenu);
            User32.RemoveMenu(hMenu, menuItemCount - 1, User32.MF_BYPOSITION);
        }

        public string WinRemoveClose(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            WinRemoveClose(tMsg.GetArgument<IntPtr>(1));
            return "200 OK";
        }

        public static IntPtr WinGetHandle(string title, string sz_class = null) {
            return User32.FindWindow(sz_class, title);
        }

        public string WinGetHandle(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            return "200 " + WinGetHandle(tMsg.Args[1]).ToInt32().ToString();
        }

        public string WinGetTitle(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            return "200 " + WinGetTitle(tMsg.GetArgument<IntPtr>(1));
        }

        /// <summary>
        /// Gets the title of a window
        /// </summary>
        /// <param name="hwnd">The handle of the window</param>
        /// <returns></returns>
        public static string WinGetTitle(IntPtr hwnd) {
            int capacity = User32.GetWindowTextLength(hwnd) + 1;
            StringBuilder sb = new StringBuilder(capacity);
            User32.GetWindowText(hwnd, sb, capacity);
            return sb.ToString();
        }

        public string WinSetTitle(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            IntPtr hwnd = tMsg.GetArgument<IntPtr>(1);
            if (User32.SetWindowText(hwnd, tMsg.Args[2])) {
                return "200 OK";
            }
            else {
                throw new TException(500, "Window title was unable to be set");
            }
        }

        public static void WinSetState(IntPtr hwnd, uint flag) {
            User32.ShowWindow(hwnd, flag);
        }

        public string WinGetState(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            return "200 " + WinGetState(
                tMsg.GetArgument<IntPtr>(1)
                );
        }

        public static int WinGetState(IntPtr hwnd) {
            return Windows.GetState(hwnd);
        }

        public string WinSetState(TMessage tMsg) {
            if (tMsg.Args.Length == 4) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], tMsg.Args[3]);
            }
            tMsg.ConfirmArgumentCount(3);
            uint flag;
            if (!windowFlags.Flags.TryGetValue(tMsg.Args[2], out flag)) {
                throw new TException(400, "arg[2] not window state");
            }
            WinSetState(tMsg.GetArgument<IntPtr>(1), flag);
            return "200 OK";
        }

        public string WinInfo(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            return "200 " + WinInfo(tMsg.GetArgument<IntPtr>(1));
        }

        /// <summary>
        /// Retrieves some general information of a window as a string
        /// </summary>
        /// <param name="handle">The window handle</param>
        /// <returns></returns>
        public static string WinInfo(IntPtr handle) {
            string title = WinGetTitle(handle);
            RECT rect = new RECT();
            WINDOWPLACEMENT winPlac = new WINDOWPLACEMENT();
            if (!User32.GetWindowPlacement(handle, out winPlac)) {
                throw new TException(404, "Window");
            }
            User32.GetWindowRect(handle, out rect);

            int state = Windows.GetState(handle);
            if (state == 0) {
                throw new TException(404, "window");
            }
            string[] result = new string[] { 
                title,
                state.ToString(),
                string.Format("Size: {0}x{1}", (rect.Right - rect.Left), (rect.Bottom - rect.Top)),
                string.Format("Location: ({0},{1})", (rect.Right - rect.Left), (rect.Bottom - rect.Top)),
                handle.ToString()
            };
            return string.Join("\n", result);
        }

        public static void WinActivate(IntPtr hwnd) {
            User32.SetForegroundWindow(hwnd);
        }

        public string WinActivate(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            WinActivate(tMsg.GetArgument<IntPtr>(1));
            return "200 OK";
        }

        public static void WinMove(IntPtr hwnd, int x, int y) {
            RECT rect = new RECT();
            if (!User32.GetWindowRect(hwnd, out rect)) {
                throw new TException(404, "Window");
            }
            if (User32.SetWindowPos(hwnd, HWND.NoTopMost,
                x,
                y,
                (rect.Right - rect.Left), (rect.Bottom - rect.Top), SWP.NOACTIVATE)) {
            }
            else {
                throw new TException(500, "The window was unable to be moved");
            }
        }

        public string WinMove(TMessage tMsg) {
            if (tMsg.Args.Length == 5) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], tMsg.Args[3], tMsg.Args[4]);
            }
            tMsg.ConfirmArgumentCount(4);
            IntPtr hwnd = tMsg.GetArgument<IntPtr>(1);
            WinMove(hwnd, tMsg.GetArgument<int>(2), tMsg.GetArgument<int>(3));
            return "200 OK";
        }
        
        public static void WinSize(IntPtr hwnd, int width, int height) {
            WINDOWPLACEMENT place = new WINDOWPLACEMENT();
            if (!User32.GetWindowPlacement(hwnd, out place)) {
                throw new TException(404, "Window");
            }
            if (User32.SetWindowPos(hwnd, HWND.NoTopMost,
                place.rcNormalPosition.X, place.rcNormalPosition.Y,
                width,
                height,
                SWP.NOACTIVATE)) {
            }
            else {
                throw new TException(500, "The window was unable to be sized");
            }
        }

        public string WinSize(TMessage tMsg) {
            if (tMsg.Args.Length == 5) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], tMsg.Args[3], tMsg.Args[4]);
            }
            tMsg.ConfirmArgumentCount(4);
            IntPtr hwnd = tMsg.GetArgument<IntPtr>(1);
            WinSize(hwnd, tMsg.GetArgument<int>(2), tMsg.GetArgument<int>(3));
            return "200 OK";
        }

        public static void WinKill(IntPtr hwnd) {
            if (!User32.DestroyWindow(hwnd)) {
                throw new TException(500, "Unable to kill window");
            }
        }

        public string WinKill(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            int hwnd = tMsg.GetArgument<int>(1);
            WinKill(new IntPtr(hwnd));
            return "200 OK";
        }

        public static void WinClose(IntPtr hwnd) {
            User32.SendMessage(hwnd, 0x0112, 0xF060, 0);
        }

        public string WinClose(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                tMsg.AppendArguments("");
            }
            tMsg.ConfirmArgumentCount(3);
            WinClose(tMsg.GetArgument<IntPtr>(1));
            return "202 Accepted";
        }

        public static void WinSetTrans(IntPtr hwnd, byte trans) {
            User32.SetWindowLong(hwnd, User32.GWL_EXSTYLE, User32.GetWindowLong(hwnd, User32.GWL_EXSTYLE) ^ User32.WS_EX_LAYERED);
            User32.SetLayeredWindowAttributes(hwnd, 0, trans, User32.LWA_ALPHA);
        }

        public string WinSetTrans(TMessage tMsg) {
            if (tMsg.Length == 4) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], tMsg.Args[3]);
            }
            tMsg.ConfirmArgumentCount(3);
            IntPtr hwnd = tMsg.GetArgument<IntPtr>(1);
            WinSetTrans(hwnd, tMsg.GetArgument<byte>(2));
            return "200 OK";
        }

        public static IntPtr[] WinList(int flag = 0) {
            return flag == 0 ? Windows.List() : Windows.List(flag);
        }

        public string WinList(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.Process(tMsg.Args[0], "VISIBLE");
            }
            tMsg.ConfirmArgumentCount(2);
            int state = 0;
            foreach (var v in windowFlags.States) {
                if (v.Key.Equals(tMsg.Args[1], StringComparison.OrdinalIgnoreCase)) {
                    state += v.Value;
                }
            }
            if (state == 0) {
                throw new TException(400, "arg[1] not window state");
            }

            var windows =
                from hwnd in Windows.List(state)
                let title = WinGetTitle(hwnd)
                where !title.Equals("")
                select title;
            string ret = string.Join("\n", windows.ToArray()).Trim();
            if (ret.Equals("")) {
                return "204 No Content";
            }
            return "200 " + ret;
        }

        public static string[] WinListInfo(int flag = 0) {
            return (from hwnd in (flag == 0 ? Windows.List() : Windows.List(flag))
                   let title = WinGetTitle(hwnd)
                   where !title.Equals("")
                   select WinInfo(hwnd)).ToArray();
        }

        public string WinListInfo(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.Process(tMsg.Args[0], "visible");
            }
            tMsg.ConfirmArgumentCount(2);
            int state = 0;
            foreach (var v in windowFlags.States) {
                if (v.Key.Equals(tMsg.Args[1], StringComparison.OrdinalIgnoreCase)) {
                    state += v.Value;
                }
            }
            if (state == 0) {
                throw new TException(400, "arg[1] not window state");
            }

            string result = string.Join("\n", WinListInfo(state));
            if (result.Trim().Equals("")) {
                return "204 No Content";
            }
            return "200 " + result.Trim();
        }

        public string GetScreen(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);

            int compression = tMsg.GetArgument<int>(1);
            if (compression > 100 || compression < 0) {
                throw new TException(400, "arg[1] must be int between 0 and 100");
            }
            return "200 " + Convert.ToBase64String(GetScreen(compression));
        }

        public static byte[] GetScreen(int compression = 50) {
            ScreenCapture sc = new ScreenCapture();
            Image img = sc.CaptureScreen();
            using (MemoryStream ms = Compress.DoIt(img, compression)) {
                return TBasicCore.ReadToEnd(ms);
            }
        }

        public static byte[] WinPicture(IntPtr hwnd, int compression = 50) {
            ScreenCapture sc = new ScreenCapture();
            System.Drawing.Image pic = sc.CaptureWindow(hwnd);
            using (MemoryStream ms = Compress.DoIt(pic, compression)) {
                return TBasicCore.ReadToEnd(ms);
            }
        }

        public string WinPicture(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            int compression = tMsg.GetArgument<int>(2);
            if (compression > 100 || compression < 0) {
                throw new TException(400, "arg[2] must be int between 0 and 100");
            }
            IntPtr hwnd = tMsg.GetArgument<IntPtr>(1);
            return "200 " + Convert.ToBase64String(WinPicture(hwnd, compression));
        }

        public static bool WindowExists(IntPtr hwnd) {
            return Windows.WindowExists(hwnd);
        }

        public string WindowExists(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            return "200 " + Windows.WindowExists(tMsg.GetArgument<IntPtr>(1));
        }
    }
}
