﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Forms = System.Windows.Forms;
using Tbasic.Errors;
using Tbasic.Components;
using Tbasic.Interpreter;
using Tbasic.Win32;

namespace Tbasic.Libraries
{
    public class AutomationLibrary : TBasicLibrary
    {
        public AutomationLibrary(TBasicCore core)
            : base(core) {
        }

        public override void ConstructLibrary() {
            Add("mouseclick", MouseClick);
            Add("blockinput", BlockInput);
            Add("mousemove", MouseMove);
            Add("send", Send);
            Add("volumeup", VolumeUp);
            Add("volumedown", VolumeDown);
            Add("volumemute", VolumeMute);
            Add("webcamcapture", WebCamCapture);
            Add("microphone", Microphone);
        }

        public static void MouseClick(int action, int x, int y, int clicks = 1, int speed = 5) {
            MouseMove(x, y, speed);
            for (int i = 0; i < clicks; i++) {
                User32.mouse_event(action, x, y, 0, 0);
            }
        }

        public string MouseClick(TMessage tMsg) {
            if (tMsg.Args.Length == 4) {
                tMsg.AppendArguments("1", "1");
            }
            if (tMsg.Args.Length == 5) {
                tMsg.AppendArguments("5");
            }
            tMsg.ConfirmArgumentCount(6);

            int x = tMsg.GetArgument<int>(2),
                y = tMsg.GetArgument<int>(3),
                clicks = tMsg.GetArgument<int>(4),
                speed = tMsg.GetArgument<int>(5);

            int button;
            if (tMsg.GetArgument(1, "button", "LEFT", "RIGHT").Equals("LEFT", StringComparison.OrdinalIgnoreCase)) {
                button = User32.MOUSEEVENTF_LEFTDOWN | User32.MOUSEEVENTF_LEFTUP;
            }
            else {
                button = User32.MOUSEEVENTF_RIGHTDOWN | User32.MOUSEEVENTF_RIGHTUP;
            }
            MouseClick(button, x, y, clicks, speed);
            return "200 OK";
        }

        public string MouseMove(TMessage tMsg) {
            if (tMsg.Args.Length == 3) {
                tMsg.AppendArguments("1");
            }
            tMsg.ConfirmArgumentCount(4);

            int x = tMsg.GetArgument<int>(1),
                y = tMsg.GetArgument<int>(2),
                s = tMsg.GetArgument<int>(3);
            MouseMove(x, y, s);
            return "200 OK";
        }

        public static void MouseMove(int X, int Y, int speed) {
            double endX = X, endY = Y;
            if (speed == 0) {
                Cursor.Position = new Point((int)(endX + 0.5), (int)(endY + 0.5));
                return;
            }
            else if (speed < 0) {
                throw new TException(400, "Speed must be positive");
            }
            double startX = Cursor.Position.X,
                   startY = Cursor.Position.Y;

            double direction = startX < endX ? 1 : -1;
            double slope = (endY - startY) / (endX - startX);
            speed = (int)(Math.Sqrt(speed));

            double oldX = startX;
            bool finished = false;
            for (double x = startX; !finished; x += direction) {
                double y = slope * (x - startX) + startY;
                int newX = (int)(x + 0.5),
                    newY = (int)(y + 0.5);
                System.Threading.Thread.Sleep(speed);
                oldX = x;
                if (finished = endX.IsBetween(oldX, x)) {
                    Cursor.Position = new Point((int)endX, (int)endY);
                }
                else {
                    Cursor.Position = new Point(newX, newY);
                }
            }
        }

        public static void BlockInput(bool doBlock) {
            if (!User32.BlockInput(doBlock)) {
                throw new TException(500, "Check user priveleges");
            }
        }

        public string BlockInput(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            tMsg.Process(tMsg.Args[0], tMsg.Args[1].Replace("1", "true").Replace("0", "false"));
            BlockInput(tMsg.GetArgument<bool>(1));
            return "200 OK";
        }

        public static void Send(string keys) {
            SendKeys.SendWait(keys);
        }

        public string Send(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            Send(tMsg.Args[1]);
            return "200 OK";
        }

        public static void VolumeUp(int amnt = 1) {
            for (int i = 0; i < amnt; i++) {
                User32.keybd_event((byte)Forms.Keys.VolumeUp, 0, 0, 0);
            }
        }

        public string VolumeUp(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.Process(tMsg.Args[0], "1");
            }
            tMsg.ConfirmArgumentCount(2);
            VolumeUp(tMsg.GetArgument<int>(1));
            return "200 OK";
        }

        public static void VolumeDown(int amnt = 1) {
            for (int i = 0; i < amnt; i++) {
                User32.keybd_event((byte)Forms.Keys.VolumeDown, 0, 0, 0);
            }
        }

        public string VolumeDown(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.Process(tMsg.Args[0], "1");
            }
            tMsg.ConfirmArgumentCount(2);
            VolumeDown(tMsg.GetArgument<int>(1));
            return "200 OK";
        }

        public static void VolumeMute() {
            User32.keybd_event((byte)Forms.Keys.VolumeMute, 0, 0, 0);
        }

        public string VolumeMute(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            VolumeMute();
            return "200 OK";
        }

        public static byte[] WebCamCapture(int compression = 50, int delay = 500) {
            byte[] data = Borrowed.ccWebCam.CaptureSTA(delay);
            try {
                using (MemoryStream img = Borrowed.Compress.DoIt(
                       Image.FromStream(new MemoryStream(data)), compression)) {
                    return TBasicCore.ReadToEnd(img);
                }
            }
            catch (ArgumentException) {
                throw new TException(404, "A web camera may not be enabled on this system.", false);
            }
            finally {
                Borrowed.ccWebCam.Disconnect();
            }
        }

        public string WebCamCapture(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], "500");
            }
            tMsg.ConfirmArgumentCount(3);
            int compression = tMsg.GetArgument<int>(1);
            if (compression < 0 || compression > 100) {
                throw new TException(400, "args[1] must be between 0 and 100");
            }
            return "200 " + Convert.ToBase64String(WebCamCapture(compression, tMsg.GetArgument<int>(2)));
        }

        public string Microphone(TMessage tMsg) {
            throw new NotImplementedException("Reserved for future use");
        }
    }
}
