﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;
using Tbasic.Errors;
using Tbasic.Threads;
using Tbasic.Components;
using Tbasic.Interpreter;

namespace Tbasic.Libraries {
    public class ThreadLibrary : TBasicLibrary {

        public ThreadLibrary(TBasicCore core)
            : base(core) {
        }

        public override void ConstructLibrary() {
            Add("threadlist", ThreadList);
            Add("threadlistclean", ThreadListClean);
            Add("threadabort", ThreadAbort);
            Add("threadstate", ThreadState);
            Add("threaddelete", ThreadDelete);
            Add("processthreadlist", ProcessThreadList);
            Add("history", History);
            Add("getreport", GetReport);
            Add("clearhistory", ClearHistory);
            Add("historylog", HistoryLog);
        }

        public string HistoryLog(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                tMsg.Process(tMsg.Args[0], core.CurrentThread.ID.ToString(), tMsg.Args[1]);
            }
            if (tMsg.Args.Length == 3) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], tMsg.Args[2], "CURRENT");
            }
            tMsg.ConfirmArgumentCount(4);
            int id = tMsg.GetArgument<int>(1);
            if (!core.Threads.Contains(id)) {
                throw new TException(404, "thread");
            }
            ThreadInfo thread = core.Threads[id];
            bool threadLog = tMsg.GetArgument(2, "'ON' or 'OFF'", "ON", "OFF").Equals("ON", StringComparison.OrdinalIgnoreCase);
            bool globalLog = tMsg.GetArgument(3, "'ALL' or 'CURRENT'", "ALL", "CURRENT").Equals("ALL", StringComparison.OrdinalIgnoreCase);
            thread.LogHistory = threadLog;
            if (globalLog) {
                core.LogHistory = threadLog;
            }
            return "200 OK";
        }

        public string History(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.AppendArguments(Thread.CurrentThread.ManagedThreadId.ToString());
            }
            tMsg.ConfirmArgumentCount(2);
            int id = tMsg.GetArgument<int>(1);
            if (!core.Threads.Contains(id)) {
                throw new TException(404, "thread");
            }
            ThreadInfo thread = core.Threads[id];
            if (!thread.LogHistory) {
                return "204 History is not being logged for this thread. No reports are available.";
            }
            StringBuilder history = new StringBuilder('|' + ("Message History for Thread " + thread.ID).Center(70));
            history.AppendFormat("\n{0,-8}{1,-40}{2,-20}", "[ ID ]", "[ Message ]", "[ Received ]");
            foreach (var v in thread.Reports) {
                history.AppendFormat("\n{0,6}  {1,-40}{2,-20}", v.Key.ID, v.Key.DataString, v.Key.CreationTime.ToString("HH:mm:ss MM/dd/yyyy"));
            }
            return "200 " + history.ToString();
        }

        public string ClearHistory(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.AppendArguments(Thread.CurrentThread.ManagedThreadId.ToString());
            }
            tMsg.ConfirmArgumentCount(2);
            int id = tMsg.GetArgument<int>(1);
            if (!core.Threads.Contains(id)) {
                throw new TException(404, "thread");
            }
            ThreadInfo thread = core.Threads[id];
            thread.Reports.Clear();
            return "200 All reports cleared for thread " + id;
        }

        public string GetReport(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                tMsg.Process(tMsg.Args[0], Thread.CurrentThread.ManagedThreadId.ToString(), tMsg.Args[1]);
            }
            tMsg.ConfirmArgumentCount(3);
            ThreadInfo thread = core.Threads.GetThread(tMsg.GetArgument<int>(1));
            Report report = thread.Reports.GetReportFromId(tMsg.GetArgument<int>(2));
            return "200 " + report.ToString();
        }

        public string ProcessThreadList(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            return "200 " + core.Threads.GetProcessThreadList();
        }

        public string ThreadList(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            return "200 " + core.Threads.GetManagedThreadList();
        }

        public string ThreadDelete(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            int id = tMsg.GetArgument<int>(1);
            if (!core.Threads.Contains(id)) {
                return "404 Thread not found";
            }
            if (core.Threads[id].ThreadState != System.Threading.ThreadState.Aborted &&
                core.Threads[id].ThreadState != System.Threading.ThreadState.Stopped) {
                return "409 Cannot delete thread because thread is running";
            }
            core.Threads.Remove(id);
            return "200 Thread Removed";
        }

        public string ThreadListClean(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            core.Threads.Clean();
            return "200 Unused threads removed from record";
        }

        public string ThreadAbort(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            int id = tMsg.GetArgument<int>(1);
            if (!core.Threads.Contains(id)) {
                return "404 Thread not found";
            }
            core.Threads[id].Abort();
            return "202 Terminating thread " + id;
        }

        public string ThreadState(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            int id = tMsg.GetArgument<int>(1);
            if (!core.Threads.Contains(id)) {
                return "404 Thread not found";
            }
            else {
                return "200 " + core.Threads[id].CurrentTask;
            }
        }
    }
}
