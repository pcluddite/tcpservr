﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using Tbasic.Errors;
using System.Diagnostics;
using Tbasic.Components;
using Tbasic.Interpreter;

namespace Tbasic.Libraries {
    public class ScriptLibrary : TBasicLibrary {

        public byte[] HelperApplication {
            get {
                return Properties.Resources.Helper;
            }
        }

        public ScriptLibrary(TBasicCore core)
            : base(core) {
        }

        public override void ConstructLibrary() {
            Add("script", Script);
            Add("scriptopen", ScriptOpen);
            Add("hello", Hello);
            Add("brew", Brew);
            Add("lorem", Lorem);
            Add("fuck", Die);
            Add("kill", Die);
            Add("die", Die);
            Add("errorlog", ErrorLog);
            Add("gc", GC);
        }

        public string GC(TMessage tMsg) {
            System.GC.Collect();
            return "200 OK";
        }

        public string ErrorLog(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            string log = core.ErrorLog.ToString();
            if (log.Equals("")) {
                return "204 No errors for this session";
            }
            else {
                return "200 " + log;
            }
        }

        public string Die(TMessage tMsg) {
            if (tMsg.DataString.Contains("you")) {
                throw new TException(409, "Between you and me");
            }
            throw new TException(400, "args must be formatted politely");
        }

        public string Hello(TMessage tMsg) {
            return "200 Hello!";
        }

        public string Brew(TMessage tMsg) {
            return "418 I'm a teapot";
        }

        public string Lorem(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            tMsg.GetArgument(1, "pseudo-Latin", "ipsum");
            return "200 dolor sit amet, consectetuer adipiscing elit";
        }

        public string ScriptOpen(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            Interpreter.ScriptRunner tbasic = new Interpreter.ScriptRunner(core);
            tbasic.RunScript(File.ReadAllLines(tMsg.Args[1]));
            return "202 Done";
        }

        public string Script(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            if (!File.Exists(tMsg.Args[1])) {
                throw new TException(404, "script");
            }

            System.Threading.Thread t = new System.Threading.Thread(Script);
            string path = Path.GetTempFileName();
            t.Start(new string[] { tMsg.Args[1], path });

            return "202 Script is running as " + path + "...";
        }

        private void Script(object o) {
            try {
                string[] args = (string[])o;
                System.Diagnostics.Process p = new System.Diagnostics.Process();
                p.StartInfo.FileName = args[1] + ".exe";
                p.StartInfo.Arguments = args[0];
                File.Copy(System.Windows.Forms.Application.ExecutablePath, p.StartInfo.FileName);
                p.Start();
                p.WaitForExit();
                File.Delete(p.StartInfo.FileName);
            }
            catch {
            }
        }
    }
}
