﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Text;
using Tbasic.Borrowed;
using Tbasic.Errors;
using Tbasic.Threads;
using System.Linq;
using Tbasic.Components;
using Tbasic.Interpreter;

namespace Tbasic.Libraries {
    public abstract class PipeLibrary {

        private TBasicCore core;
        private Dictionary<string, ByteCommandDelegate> lib;

        public PipeLibrary(TBasicCore core) {
            this.core = core;
            lib = CreateDictionary();
        }

        protected virtual Dictionary<string, ByteCommandDelegate> CreateDictionary() {
            Dictionary<string, ByteCommandDelegate> lib = new Dictionary<string, ByteCommandDelegate>();
            lib.Add("pipelistall", PipeListAll);
            lib.Add("pipeexists", PipeExists);
            lib.Add("pipeuse", PipeUse);
            lib.Add("pipecreate", PipeCreate);
            return lib;
        }

        public virtual bool ContainsKey(string key) {
            return lib.ContainsKey(key);
        }

        public byte[] PipeCreate(TMessage tMsg) {
            TResponse response = new TResponse(tMsg);
            tMsg.ConfirmArgumentCount(3);
            try {
                if (!PipeExists(tMsg.Args[1])) {
                    response.Process(404, "Pipe does not exist");
                    return response.Data;
                }
                TMessage pMsg = new TMessage();
                pMsg.Process("PIPEUSE \"" + tMsg.Args[1] + "\" OPEN \"" + tMsg.Args[2] + "\"");
                return PipeUse(pMsg);
            }
            catch (Exception ex) {
                throw new TException(500, ex.Message);
            }
        }

        private string ListConnectedUsers(Dictionary<string, string> pipes, bool simple) {
            if (simple) {
                var users =
                    from u in pipes
                    select string.Format("{0}|{1}|{2}", u.Key, u.Value, PipeExists(u.Value) ? "Alive" : "Broken");
                return string.Join("\r\n", users.ToArray());
            }
            else {
                var users =
                    from u in pipes
                    select string.Format("{0,-25}{1,-8}{2}", 
                                          u.Key, u.Value, PipeExists(u.Value) ? "" : " - Broken Pipe");
                return string.Format("{0,-25}{1,-8}", "USER", "PIPE") +
                    "\r\n" + string.Join("\r\n", users.ToArray());
            }
        }

        public byte[] PipeListAll(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(1);
            TResponse response = new TResponse(tMsg);
            response.Process(200, string.Join("\n", FileIO.FindFiles(@"\\.\pipe\*")));
            return response.Data;
        }

        public byte[] PipeUse(TMessage tMsg) {
            TResponse response = new TResponse(tMsg);
            if (tMsg.Args.Length < 3) {
                tMsg.ConfirmArgumentCount(-5);
            }
            try {
                string[] args = new string[tMsg.Args.Length - 2];
                for (int i = 0; i < args.Length; i++) {
                    args[i] = tMsg.Args[i + 2];
                }

                TMessage pipeMsg = new TMessage();
                pipeMsg.Process(args);

                return PipeUse(tMsg.Args[1], pipeMsg, core.CurrentThread);
            }
            catch (Exception ex) {
                throw new TException(502, ex.Message);
            }
        }

        public static byte[] PipeUse(string pipe, TMessage tMsg, ThreadInfo currentThread) {
            TResponse response = new TResponse(tMsg);
            try {
                if (!PipeExists(pipe)) {
                    response.Process(502, "Pipe does not exist");
                    return response.Data;
                }

                int id = System.Threading.Thread.CurrentThread.ManagedThreadId;
                currentThread.AddTask("Connecting to '" + pipe + "'");
                using (NamedPipeClientStream client = new NamedPipeClientStream(pipe)) {
                    client.Connect(5000);
                    client.ReadMode = PipeTransmissionMode.Message;

                    currentThread.AddTask("Writing to '" + pipe + "'");

                    client.Write(tMsg.RawData, 0, tMsg.RawData.Length);

                    TReceiver receiver = new TReceiver(client, client);
                    byte[] data;
                    currentThread.AddTask("Reading from '" + pipe + "'");
                    int len = receiver.Receive(out data);
                    if (len == -1) {
                        response.Process(502, "An invalid message was received from the pipe and cannot be processed.");
                        return response.Data;
                    }
                    response.Process(data);

                    return response.Data;
                }
            }
            catch (Exception ex) {
                throw new TException(500, ex.Message);
            }
        }

        public static bool PipeExists(string pipe) {
            foreach (string s in FileIO.FindFiles(@"\\.\pipe\*")) {
                if (s.Equals(pipe)) {
                    return true;
                }
            }
            return false;
        }

        public byte[] PipeExists(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            TResponse response = new TResponse(tMsg);
            response.Process(200, PipeExists(tMsg.Args[1]).ToString());
            return response.Data;
        }
    }
}
