﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Win32;
using Tbasic.Errors;
using Tbasic.Borrowed;
using Tbasic.Components;
using Tbasic.Interpreter;

namespace Tbasic.Libraries {
    public class RegistryLibrary : TBasicLibrary {

        public RegistryLibrary(TBasicCore core)
            : base(core) {
        }

        public override void ConstructLibrary() {
            Add("regenumkeys", new GenericCommandDelegate(RegEnumKeys));
            Add("regenumvalues", new GenericCommandDelegate(RegEnumValues));
            Add("regrenamekey", new GenericCommandDelegate(RegRenameKey));
            Add("regrename", new GenericCommandDelegate(RegRename));
            Add("regdelete", new GenericCommandDelegate(RegDelete));
            Add("regdeletekey", new GenericCommandDelegate(RegDeleteKey));
            Add("regcreatekey", new GenericCommandDelegate(RegCreateKey));
            Add("regread", new GenericCommandDelegate(RegRead));
            Add("regwrite", new GenericCommandDelegate(RegWrite));
        }

        private RegistryKey GetRootKey(string key) {
            key = key.ToUpper();
            if (key.StartsWith("HKEY_CURRENT_USER")) {
                return Registry.CurrentUser;
            }
            else if (key.StartsWith("HKEY_CLASSES_ROOT")) { 
                return Registry.ClassesRoot;
            }
            else if (key.StartsWith("HKEY_LOCAL_MACHINE")) { 
                return Registry.LocalMachine;
            }
            else if (key.StartsWith("HKEY_USERS")) { 
                return Registry.Users;
            }
            else if (key.StartsWith("HKEY_CURRENT_CONFIG")) { 
                return Registry.CurrentConfig; 
            }
            return null;
        }

        private string RemoveKeyRoot(string key) {
            int indexOfRoot = key.IndexOf('\\');
            if (indexOfRoot < 0) {
                return "";
            }
            string ret = key.Remove(0, indexOfRoot);
            while (ret.StartsWith("\\")) {
                ret = ret.Remove(0, 1);
            }
            return ret;
        }

        public string RegValueKind(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            using (RegistryKey key = OpenKey(tMsg.Args[1], false)) {
                return "200 " + key.GetValueKind(tMsg.Args[2]);
            }
        }

        private RegistryValueKind RegValueKind(string key, string value) {
            RegistryKey keyBase = GetRootKey(key);
            using (keyBase = keyBase.OpenSubKey(RemoveKeyRoot(key))) {
                RegistryValueKind kind = keyBase.GetValueKind(value);
                return kind;
            }
        }

        public string RegRead(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);

            object ret = RegRead(tMsg.Args[1], tMsg.Args[2]);

            if (ret == null) {
                throw new TException(404);
            }

            return "200 " + ret.ToString();
        }

        static string byteToString(byte b) {
            return Convert.ToString(b, 16);
        }

        public object RegRead(string key, string value) {
            object ret = RegistryUtilities.Read(GetRootKey(key), RemoveKeyRoot(key), value, null);
            RegistryValueKind kind = RegValueKind(key, value);
            if (kind == RegistryValueKind.MultiString) {
                ret = string.Join("\n", (string[])ret);
            }
            if (kind == RegistryValueKind.Binary) {
                List<byte> blist = new List<byte>();
                blist.AddRange((byte[])ret);
                ret = string.Join(" ",
                    blist.ConvertAll(new Converter<byte, string>(byteToString)).ToArray());
            }
            return ret;
        }

        public string RegDelete(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            RegistryKey key = GetRootKey(tMsg.Args[1]);
            using (key = key.OpenSubKey(RemoveKeyRoot(tMsg.Args[1]), true)) {
                key.DeleteValue(tMsg.Args[2], true);
                return "200 OK";
            }
        }

        public string RegRename(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(4);
            RegistryKey key = GetRootKey(tMsg.Args[1]);
            using (key = key.OpenSubKey(RemoveKeyRoot(tMsg.Args[1]), true)) {
                key.SetValue(tMsg.Args[3], key.GetValue(tMsg.Args[2]), key.GetValueKind(tMsg.Args[2]));
                key.DeleteValue(tMsg.Args[2], true);
                return "200 OK";
            }
        }

        public string RegDeleteKey(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            using (RegistryKey key = GetRootKey(tMsg.Args[1])) {
                key.DeleteSubKeyTree(RemoveKeyRoot(tMsg.Args[1]));
                return "200 OK";
            }
        }

        public string RegRenameKey(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            using (RegistryKey key = OpenParentKey(tMsg.Args[1], true)) {
                RegistryUtilities.RenameSubKey(key, RemoveKeyRoot(tMsg.Args[1]), tMsg.Args[2]);
                return "200 OK";
            }
        }

        public string RegCreateKey(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(3);
            using (RegistryKey key = OpenKey(tMsg.Args[1], true)) {
                key.CreateSubKey(tMsg.Args[2]);
                return "201 Created";
            }
        }

        private string ByteToHex(byte b) {
            return int.Parse(b.ToString()).ToString("x2");
        }

        public string RegEnumValues(TMessage tMsg) {
            string simpleString = null;
            bool isSimple = false;
            if (tMsg.Args.Length == 3) {
                simpleString = tMsg.Args[2];
                tMsg.Process(tMsg.Args[0], tMsg.Args[1]);
                isSimple = true;
            }
            tMsg.ConfirmArgumentCount(2);
            if (tMsg.Args.Length == 3 && simpleString.ToLower().CompareTo("/s") != 0) {
                throw new TException(400, "arg[2] should be null or '/s'");
            }

            using (RegistryKey key = OpenKey(tMsg.Args[1], false)) {
                StringBuilder sb = new StringBuilder();
                foreach (string s in key.GetValueNames()) {
                    if (isSimple) {
                        TMessage line = new TMessage();
                        line.Process("ENTRY:", s, RegValueKind(tMsg.Args[1], s), RegRead(tMsg.Args[1], s));
                        sb.AppendLine(line.UnformattedDataString);
                    }
                    else {
                        sb.AppendLine(string.Format("{0,-10}{1}", "Name:", s));
                        sb.AppendLine(string.Format("{0,-10}{1}", "Type:", RegValueKind(tMsg.Args[1], s)));
                        sb.AppendLine(string.Format("{0,-10}{1}", "Value:", RegRead(tMsg.Args[1], s)));
                        sb.AppendLine();
                    }
                }
                return "200 " + sb.ToString();
            }
        }

        public RegistryKey OpenKey(string path, bool write) {
            using (RegistryKey key = GetRootKey(path)) {
                return key.OpenSubKey(RemoveKeyRoot(path), write);
            }
        }

        public RegistryKey OpenParentKey(string path, bool write) {
            int indexOfLast = path.LastIndexOf('\\');
            if (indexOfLast > -1) {
                path = path.Substring(0, indexOfLast);
            }
            return OpenKey(path, write);
        }

        public string RegEnumKeys(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(2);
            using (RegistryKey key = OpenKey(tMsg.Args[1], false)) {
                return "200 " + string.Join("\r\n", key.GetSubKeyNames());
            }
        }

        public string RegWrite(TMessage tMsg) {
            tMsg.ConfirmArgumentCount(5);

            object value = tMsg.Args[3];

            RegistryValueKind k = RegistryValueKind.Unknown;
            switch (tMsg.Args[4].ToLower()) {
                case "binary": k = RegistryValueKind.Binary;
                    List<string> slist = new List<string>();
                    slist.AddRange(tMsg.Args[3].Split(' '));
                    value = slist.ConvertAll<byte>(new Converter<string, byte>(stringToByte)).ToArray();
                    break;
                case "dword": 
                    k = RegistryValueKind.DWord; 
                    break;
                case "expandstring": 
                    k = RegistryValueKind.ExpandString; 
                    break;
                case "multistring": 
                    k = RegistryValueKind.MultiString;
                    value = tMsg.Args[3].Replace("\r\n", "\n").Split('\n');
                    break;
                case "qword": 
                    k = RegistryValueKind.QWord; 
                    break;
                case "string": 
                    k = RegistryValueKind.String; 
                    break;
            }
            if (k == RegistryValueKind.Unknown) {
                throw new TException(400, "arg[4] not data type");
            }

            using (RegistryKey key = OpenKey(tMsg.Args[1], true)) {
                key.SetValue(tMsg.Args[2], value, k);
            }
            return "200 OK";
        }

        private byte stringToByte(string s) {
            return Convert.ToByte(s, 16);
        }
    }
}