﻿using System.Collections.Generic;
using Tbasic.Components;
using Tbasic.Interpreter;

namespace Tbasic.Libraries {

    public delegate string GenericCommandDelegate(TMessage msg);
    public delegate byte[] ByteCommandDelegate(TMessage msg);

    public class LibraryCollection : List<TBasicLibrary> {

        private Dictionary<string, GenericCommandDelegate> allCmds;

        public TBasicCore core;

        public LibraryCollection(TBasicCore core) {
            this.core = core;
            allCmds = new Dictionary<string, GenericCommandDelegate>();
            AddLibraries();
        }

        protected virtual void AddLibraries() {
            AddRange(new TBasicLibrary[] {
                new AutomationLibrary(core), new FileLibrary(core),
                new CommunicationsLibrary(core), new ProcessLibrary(core),
                new RegistryLibrary(core), new ScriptLibrary(core),
                new ThreadLibrary(core), new WindowLibrary(core)
            });
            Refresh();
        }

        public void Refresh() {
            foreach (TBasicLibrary lib in this) {
                foreach (var kv in lib) {
                    allCmds.Add(kv.Key, kv.Value);
                }
            }
        }

        public GenericCommandDelegate this[string command] {
            get {
                return allCmds[command];
            }
        }

        public bool ContainsKey(string key) {
            return allCmds.ContainsKey(key);
        }
    }
}
