﻿using System.Collections.Generic;
using System.Linq;
using Tbasic.Components;
using Tbasic.Errors;
using Tbasic.Libraries;

namespace Tcpservr {
    public class PipeManager : PipeLibrary {

        private TCPSERVR tcpservr;
        private bool dominant;
        private Dictionary<string, ByteCommandDelegate> lib;

        public PipeManager(TCPSERVR tcpservr, bool isDominant) : base(tcpservr) {
            this.tcpservr = tcpservr;
            dominant = isDominant;
        }

        protected override Dictionary<string, ByteCommandDelegate> CreateDictionary() {
            Dictionary<string, ByteCommandDelegate> lib = base.CreateDictionary();
            lib.Add("pipesetuser", PipeSetUser);
            lib.Add("user", PipeSetUser);
            lib.Add("pipelistusers", PipeListUsers);
            return this.lib = lib;
        }

        public ByteCommandDelegate this[string command] {
            get {
                return lib[command];
            }
        }

        public override bool ContainsKey(string key) {
            if (!dominant && (
                key.Equals("pipesetuser") || key.Equals("user") || key.Equals("pipelistusers"))) {
                return false;
            }
            else {
                return base.ContainsKey(key);
            }
        }

        public byte[] PipeSetUser(TMessage tMsg) {
            TResponse response = new TResponse(tMsg);
            if (tMsg.Args.Length == 2) {
                tMsg.Process(tMsg.Args[0], tMsg.Args[1], "False");
            }
            tMsg.ConfirmArgumentCount(3);
            
            if (!tcpservr.MasterPipe.Users.ContainsKey(tMsg.Args[1])) {
                throw new TException(404, "User");
            }
            bool global = tMsg.GetArgument<bool>(2);

            string initialPipe = tcpservr.MasterPipe.Users[tMsg.Args[1]];
            string newPipe = tMsg.Args[1].Split('\\')[tMsg.Args[1].Split('\\').Length - 1];
            string responseMsg = "";
            if (!PipeExists(newPipe)) {
                TMessage createdMsg = new TMessage();
                createdMsg.Process("PipeCreate", initialPipe, newPipe);
                TResponse createdResponse = new TResponse(createdMsg);
                createdResponse.Process(PipeCreate(createdMsg));
                if (createdResponse.Status != 200) {
                    return createdResponse.Data;
                }
                responseMsg = "The current pipe is set to a new pipe '" + newPipe + "'";
            }
            else {
                responseMsg = "The current pipe is set to an existing pipe '" + newPipe + "'";
            }
            int id = System.Threading.Thread.CurrentThread.ManagedThreadId;
            tcpservr.Threads[id].CurrentPipeName = newPipe;
            tcpservr.Threads[id].UsingPipe = true;
            if (global) {
                tcpservr.GlobalPipe = newPipe;
                tcpservr.UsingGlobalPipe = global;
            }
            response.Process(200, responseMsg);
            return response.Data;
        }

        public byte[] PipeListUsers(TMessage tMsg) {
            TResponse response = new TResponse(tMsg);
            if (tMsg.Args.Length != 1 && tMsg.Args.Length != 2) {
                tMsg.ConfirmArgumentCount(-5);
            }

            bool simple = false;
            if (tMsg.Args.Length == 2) {
                if (tMsg.Args[1].ToLower().Equals("/s")) {
                    simple = true;
                }
                else {
                    throw new TException(400, "arg[1] must be /s or null");
                }
            }

            response.Process(200, ListConnectedUsers(
                tcpservr.MasterPipe.Users,
                simple));

            return response.Data;
        }

        private string ListConnectedUsers(Dictionary<string, string> pipes, bool simple) {
            if (simple) {
                var users =
                    from u in pipes
                    select string.Format("{0}|{1}|{2}", u.Key, u.Value, PipeExists(u.Value) ? "Alive" : "Broken");
                return string.Join("\r\n", users.ToArray());
            }
            else {
                var users =
                    from u in pipes
                    select string.Format("{0,-25}{1,-8}{2}", 
                                          u.Key, u.Value, PipeExists(u.Value) ? "" : " - Broken Pipe");
                return string.Format("{0,-25}{1,-8}", "USER", "PIPE") +
                    "\r\n" + string.Join("\r\n", users.ToArray());
            }
        }
    }
}
