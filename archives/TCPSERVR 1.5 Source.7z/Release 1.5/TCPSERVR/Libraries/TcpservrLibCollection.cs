﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TLibs = Tbasic.Libraries;
namespace Tcpservr {
    public class TcpservrLibCollection : TLibs.LibraryCollection {

        public TcpservrLibCollection(TCPSERVR core)
            : base(core) {
        }

        protected override void AddLibraries() {
            AddRange(new TLibs.TBasicLibrary[] {
                new TLibs.AutomationLibrary(core), new TLibs.FileLibrary(core),
                new TLibs.CommunicationsLibrary(core), new TLibs.ProcessLibrary(core),
                new TLibs.RegistryLibrary(core), new ServerLibrary(core),
                new TLibs.ThreadLibrary(core), new TLibs.WindowLibrary(core)
            });
            Refresh();
        }

    }
}
