﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using Tbasic.Errors;
using System.Diagnostics;
using Tbasic.Components;
using Tbasic.Libraries;
using Tbasic.Interpreter;

namespace Tcpservr {
    class ServerLibrary : ScriptLibrary {

        public ServerLibrary(TBasicCore tcpservr)
            : base(tcpservr) {
            
        }

        [DllImport("kernel32", SetLastError = true)]
        static extern bool FreeLibrary(IntPtr hModule);

        public override void ConstructLibrary() {
            base.ConstructLibrary();
            Add("update", Update);
            Add("ver", Ver);
        }

        private void UnloadModule(string moduleName) {
            foreach (ProcessModule mod in Process.GetCurrentProcess().Modules) {
                if (mod.ModuleName == moduleName) {
                    FreeLibrary(mod.BaseAddress);
                }
            }
        }

        public string Ver(TMessage tMsg) {
            return "200 " + Program.VER;
        }

        public string Update(TMessage tMsg) {
            if (tMsg.Args.Length == 1) {
                tMsg.AppendArguments(core.ApplicationDirectory + "\\tcpservr2.exe");
            }
            tMsg.ConfirmArgumentCount(2);
            if (!File.Exists(tMsg.Args[1])) {
                throw new TException(404, "updated application");
            }
            string fileName = core.ApplicationDirectory + "\\updater.exe";
            File.WriteAllBytes(fileName, HelperApplication);
            TMessage args = new TMessage();
            args.Process("UPDATE", core.ExecutablePath, tMsg.Args[1]);
            using (Process p = new Process()) {
                p.StartInfo.FileName = fileName;
                p.StartInfo.Arguments = args.DataString;
                p.Start();
            }
            return "202 Update is being prepared. End the server and wait a few minutes for the update to complete.";
        }
    }
}
