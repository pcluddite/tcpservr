﻿using System.IO;
using System.Windows.Forms;
using System;

namespace Tcpservr {
    public class Launcher {
        public static void Main(string[] args) {
            try {
                if (File.Exists(Application.StartupPath + "\\tbasic.dll")) {
                    Program.Start(args);
                }
                else {
                    MessageBox.Show("Could not find file '" + Application.StartupPath + "\\tbasic.dll'. Ensure this file exists in the same directory as TCPSERVR.",
                        "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex) {
                MessageBox.Show("Unable to start TCPSERVR application. " + ex.Message,
                    "TCPSERVR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
