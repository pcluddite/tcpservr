﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Security.Principal;
using System.Threading;
using Tbasic.Errors;
using Tbasic.Threads;
using Tbasic.Components;

namespace Tcpservr {
    public class SlaveMode {
        public static List<string> pipes = new List<string>();

        public TCPSERVR tcpservr;

        public SlaveMode(TCPSERVR server) {
            this.tcpservr = server;
        }

        private string GetId() {
            Random r = new Random();
            string ret;
            do {
                ret = "pipe" + r.Next(0, 1000);
            }
            while (PipeManager.PipeExists(ret));
            return ret;
        }

        public void Start() {
            tcpservr.Threads = new ThreadCollection();
            try {
                using (NamedPipeClientStream client = new NamedPipeClientStream("TCPSERVR")) {
                    client.Connect(5000);
                    client.ReadMode = PipeTransmissionMode.Message;
                    string id = GetId();
                    string name = WindowsIdentity.GetCurrent().Name;
                    if (name.Contains("\\")) {
                        string[] split = name.Split('\\');
                        name = split[split.Length - 1];
                    }
                    TMessage pMsg = new TMessage();
                    pMsg.Process("REGISTER", name, id);

                    client.Write(pMsg.RawData, 0, pMsg.RawData.Length);
                    client.WaitForPipeDrain();

                    TReceiver receiver = new TReceiver(client, client);
                    byte[] data;
                    int len = receiver.Receive(out data);

                    if (len == -1) {
                        new LoggedError("--",
                            "An invalid message was received when attempting to contact the master application.",
                            "Receiver.PRead", false, true).Write();
                        Environment.Exit(500);
                    }

                    TResponse response = new TResponse(pMsg);
                    response.Process(data);

                    if (response.Status == 200) {
                        Thread t = new Thread(CheckTCPSERVR);
                        t.Start();
                        StartChild(id);
                    }
                    else {
                        new LoggedError("--", "Submissive application returned: " + response.DataString,
                            "Receiver.PRead",
                            false, true).Write();
                    }
                }
            }
            catch (Exception ex) {
                new LoggedError("--", ex, false, true).Write();
                Environment.Exit(500);
            }
        }

        private void CheckTCPSERVR() {
            while (PipeManager.PipeExists("TCPSERVR")) {
                Thread.Sleep(5000);
            }
            Environment.Exit(404);
        }


        private PipeSecurity GetAccessLevel() {
            PipeSecurity ps = new PipeSecurity();
            SecurityIdentifier sid = new SecurityIdentifier(WellKnownSidType.WorldSid, null);
            ps.SetAccessRule(new PipeAccessRule(sid, PipeAccessRights.ReadWrite, System.Security.AccessControl.AccessControlType.Allow));
            return ps;
        }

        private void StartChild(string id) {
            try {
                NamedPipeServerStream server = new NamedPipeServerStream(id, PipeDirection.InOut, 1, 
                    PipeTransmissionMode.Message, PipeOptions.None, 4096, 4096, GetAccessLevel());
                while (true) {
                    server.WaitForConnection();
                    TReceiver receiver = new TReceiver(server, server);
                    byte[] data;
                    int len = receiver.Receive(out data);
                    if (len == -1) {
                        new LoggedError("--", "An invalid message was received",
                            "receiver.PRead", false, false).Write();
                        server.Disconnect();
                        continue;
                    }
                    TMessage pMsg = new TMessage();
                    pMsg.Process(data);

                    TResponse response = new TResponse(pMsg);

                    try {
                        if (pMsg.Args[0].Equals("OPEN", StringComparison.OrdinalIgnoreCase)) {
                            pMsg.ConfirmArgumentCount(2);
                            ThreadInfo info = new ThreadInfo(pMsg.Args[1], "--", tcpservr.LogHistory, new Thread(HandlePipe));
                            tcpservr.Threads.Add(info);
                            info.Thread.Start(pMsg.Args[1]);
                            response.Process(200, "OK");
                        }
                        else {
                            throw new TException(501, pMsg.Args[0].ToUpper());
                        }
                    }
                    catch (Exception ex) {
                        response.Process(TException.GetMessage(ex));
                    }
                    server.Write(response.Data, 0, response.Length);
                    server.WaitForPipeDrain();
                    server.Disconnect();
                }
            }
            catch (Exception ex) {
                new LoggedError("--", ex, false, true).Write();
                Environment.Exit(500);
            }
        }

        private void HandlePipe(object pipe) {
            int id = Thread.CurrentThread.ManagedThreadId;
            string pipeName = (string)pipe;
            try {
                pipes.Add(pipeName);
                ThreadInfo thread = tcpservr.CurrentThread;
                int msgId = 0;
                while (true) {
                    while (PipeManager.PipeExists(pipeName)) {
                        Thread.Sleep(10);
                    }
                    using (NamedPipeServerStream server = new NamedPipeServerStream(pipeName,
                        PipeDirection.InOut, 254, PipeTransmissionMode.Message, PipeOptions.None, 4096, 4096, GetAccessLevel())) {
                        server.WaitForConnection();

                        TReceiver receiver = new TReceiver(server, server);
                        byte[] data;
                        int len = receiver.Receive(out data);
                        if (len == -1) {
                            new LoggedError("--", "An invalid message was received", "receiver.PRead", false, false).Write();
                            server.Disconnect();
                            continue;
                        }
                        TMessage pMsg = new TMessage(msgId++);
                        pMsg.Process(data);
                        thread.CreateReport(pMsg);

                        thread.AddTask("Processing " + pMsg.Args[0].ToUpper());

                        TResponse response = new TResponse(pMsg);
                        try {
                            switch (pMsg.Args[0].ToUpper()) {
                                #region BREAK
                                case "BREAK":
                                    response.Process(202, "Pipe is being broken. Do not reconnect.");
                                    server.Write(response.Data, 0, response.Data.Length);
                                    server.Disconnect();
                                    server.Dispose();
                                    tcpservr.Threads[id].Abort();
                                    break;
                                #endregion
                                #region GETCHILDPIPES
                                case "GETCHILDPIPES":
                                    response.Process(200, string.Join("\r\n", pipes.ToArray()));
                                    break;
                                #endregion
                                #region ENDCHILD
                                case "ENDCHILD":
                                    response.Process(202, "Ending child instance of the application.");
                                    server.Write(response.Data, 0, response.Data.Length);
                                    server.Disconnect();
                                    server.Dispose();
                                    Environment.Exit(200);
                                    break;
                                #endregion
                                #region RESTART
                                case "RESTART":
                                    if (File.Exists(tcpservr.ApplicationDirectory + "\\TCPSERVR2.EXE")) {
                                        try {
                                            File.Delete(tcpservr.ApplicationDirectory + "\\TCPSERVR2.EXE");
                                        }
                                        catch {
                                            response.Process(500, "Could not delete file 'TCPSERVR2.EXE'");
                                            goto Write;
                                        }
                                    }
                                    File.Copy(tcpservr.ExecutablePath, tcpservr.ApplicationDirectory + "\\TCPSERVR2.EXE");
                                    TMessage restart = new TMessage();
                                    restart.Process("UPDATE");
                                    ServerLibrary updater = new ServerLibrary(tcpservr);
                                    if (!updater.Update(restart).StartsWith("202")) {
                                        response.Process(409, "Conflict");
                                        goto Write;
                                    }
                                    response.Process(202, "Attempting to restart. Please reconnect.");
                                    server.Write(response.Data, 0, response.Data.Length);
                                    server.Disconnect();
                                    server.Dispose();
                                    Environment.Exit(200);
                                    break;
                                #endregion
                                default:
                                    response = tcpservr.GetResponse(response);
                                    break;
                            }
                        }
                        catch (Exception ex) {
                            response.Process(TException.GetMessage(ex));
                        }
                    Write:
                        thread.AddTask("Writing '" + response.Message.Replace("\r\n", "\n").Replace("\n", " ").Roof(35) + "'");
                        server.Write(response.Data, 0, response.Length);
                        thread.AddTask("Waiting for pipe drain");
                        server.WaitForPipeDrain();
                        server.Disconnect();
                        thread.AddTask("Waiting for data");
                        thread.CompletedReport(pMsg);
                    }
                }
            }
            catch (Exception ex) {
                new LoggedError(pipe.ToString(), ex, false, false).Write();
            }
            finally {
                tcpservr.CurrentThread.End();
            }
        }
    }
}