﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.IO;
using System.Linq;
using System.Xml;
using System.Text.RegularExpressions;
using Tbasic.Components;

namespace console
{
    public class Program {

        public const string VER = "TCPSERVR Console [Version 1.5.2014]";
        public const string COPYRIGHT = "Copyright (c) 2011-2014 TCPSERVR";

        static XmlDocument doc = new XmlDocument();
        static int lastError = 200;

        public static void Main(string[] args) {
            Settings settings = new Settings();
            Executer executer = new Executer(settings);
            TcpSecure security = null;
            settings.Initialize();

            string prompt = settings.GetValue("prompt");
            string remoteDir = "";
            string lastData = "";

            Console.Clear();
            Console.Title = "TCPSERVR Console";
            Console.WriteLine(VER);
            Console.WriteLine(COPYRIGHT);

            TcpClient client = new TcpClient();

            Stream readerStream = null;
            Stream writerStream = null;

            TMessage tMsg = new TMessage(writerStream);
            TResponse response = new TResponse();

            while (true) {
                Console.WriteLine();
                if (client.Client == null || !client.Connected) {
                    remoteDir = "";
                }
                Console.Write(settings.GetPrompt(remoteDir));

                tMsg.Process(settings.ReplaceVariables(Console.ReadLine()));

                switch (tMsg.Args[0].ToLower()) {
                    #region yuck
                    case "exit":
                        executer.Exit(client);
                        return;
                    case "set":
                        executer.Set(tMsg);
                        break;
                    case "connect":
                        if (executer.Connect(tMsg, client)) {
                            //if (security == null) {
                                tMsg.Stream = 
                                readerStream = client.GetStream();
                            /*}
                            else {
                                tMsg.Stream = security.CreateEncryptorStream(client.GetStream());
                                readerStream = security.CreateDecryptorStream(client.GetStream());
                            }*/
                        }
                        break;
                    case "disconnect":
                        if (executer.Disconnect(tMsg, client)) {
                            client = new TcpClient();
                            if (security != null && !security.IsDisposed) {
                                security.Dispose();
                            }
                        }
                        break;
                    case "help":
                        executer.Help();
                        break;
                    case "cls":
                        Console.Clear();
                        break;
                    case "color":
                        executer.Color(tMsg);
                        break;
                    case "prompt":
                        string tmp;
                        if ((tmp = executer.Prompt(tMsg)) != null) {
                            prompt = tmp;
                        }
                        break;
                    case "pass":
                        if (executer.Pass(tMsg)) {
                            if (security != null && !security.IsDisposed) {
                                security.Dispose();
                            }
                            if (settings.Password == null) {
                                security = null;
                            }
                            else {
                                security = new TcpSecure(settings.Password);
                                /*if (client != null && client.Connected) {
                                    tMsg.Stream = security.CreateEncryptorStream(client.GetStream());
                                    readerStream = security.CreateDecryptorStream(client.GetStream());
                                }*/
                            }
                        }
                        break;
                    case "saveas":
                    case "save":
                        executer.SaveAs(tMsg, lastData);
                        break;
                    #endregion
                    default:
                        if (tMsg.DataString.Trim().CompareTo("") == 0) {
                            continue;
                        }
                        TimeSpan ts = new TimeSpan();
                        try {
                            #region cd\
                            if (tMsg.DataString.StartsWith("cd\\")) {
                                tMsg.Process("cd " + tMsg.DataString.Remove(0, 2));
                            }
                            #endregion
                            #region put
                            if (tMsg.Args[0].ToLower() == "put") {
                                byte[] file = File.ReadAllBytes(tMsg.Args[1]);
                                tMsg.Process(tMsg.Args[0] + " " + tMsg.Args[1].Split('\\')[tMsg.Args[1].Split('\\').GetUpperBound(0)]
                                    + " " + Convert.ToBase64String(file));
                            }
                            #endregion
                            long ticks = DateTime.Now.Ticks;

                            if (settings.Password != null) {
                                tMsg.ProcessEncrypt(tMsg.DataString, settings.Password);
                            }
                            tMsg.Send();

                            response = new TResponse(readerStream, tMsg);

                            response.Receive(settings.Timeout, settings.Password);
                            ts = new TimeSpan(DateTime.Now.Ticks - ticks);

                            lastError = response.Status;
                            lastData = response.Message;

                            switch (tMsg.Args[0].ToLower()) {
                                #region cd
                                case "cd":
                                    if (response.Status == 200) {
                                        remoteDir = lastData;
                                    }
                                    break;
                                #endregion
                                #region pwd
                                case "pwd":
                                    if (lastError == 200) {
                                        remoteDir = lastData;
                                    }
                                    break;
                                #endregion
                            }
                            if (tMsg.DataString.ToLower().StartsWith("get ") && lastError == 200) {
                                File.WriteAllBytes(settings.ApplicationPath + "\\Temp\\" + tMsg.Args[1], Convert.FromBase64String(lastData));
                                Console.WriteLine("200 LOCAL\r\n" + lastData.Length + " bytes downloaded");
                                continue;
                            }
                            if (response.Data != null && !response.DataString.Equals("")) {
                                Console.WriteLine(response.DataString);
                            }
                        }
                        catch (Exception ex) {
                            Executer.PrintException(ex);
                        }
                        break;
                }
            }
        }
    }
}
