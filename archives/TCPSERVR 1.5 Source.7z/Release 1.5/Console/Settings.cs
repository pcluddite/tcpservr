﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Xml;
using System.IO;

namespace console {
    public class Settings {

        private XmlDocument doc;
        private string curdir = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase).Remove(0, 6);
        private Dictionary<string, string> vars;
        public string ApplicationPath {
            get {
                return curdir;
            }
        }

        public int Timeout {
            get {
                int timeout;
                if (int.TryParse(GetValue("timeout"), out timeout)) {
                    return timeout;
                }
                return 5000;
            }
        }

        public string Password { get; set; }

        public Settings() {
            doc = new XmlDocument();
            if (!File.Exists(curdir + "\\Data.xml")) {
                doc.LoadXml("<tcpservr></tcpservr>");
            }
            else {
                doc.Load(curdir + "\\Data.xml");
            }

            if (doc.SelectSingleNode("tcpservr/console") == null) {
                XmlElement child = doc.CreateElement("console");
                doc.DocumentElement.AppendChild(child);
            }
        }

        public void Initialize() {
            LoadVariables();
        }

        public void RemoveValue(string name) {
            if (vars.ContainsKey(name)) {
                vars.Remove(name);
            }
        }

        public string GetValue(string name) {
            if (vars.ContainsKey(name)) {
                return vars[name];
            }
            else {
                return "";
            }
        }

        public Dictionary<string, string> GetVariables() {
            return vars;
        }

        public void SetValue(string name, string value) {
            if (vars.ContainsKey(name)) {
                vars[name] = value;
            }
            else {
                vars.Add(name, value);
            }
        }

        public bool GetHost(out IPEndPoint result) {
            IPAddress host;
            if (!IPAddress.TryParse(GetValue("host"), out host)) {
                Console.Write("Finding host {0}...", GetValue("host"), GetValue("port"));
                try {
                    var addresses =
                        from address in Dns.GetHostAddresses(GetValue("host"))
                        where address.AddressFamily != AddressFamily.InterNetworkV6
                        select address;
                    host = addresses.ElementAt(0);
                    Console.WriteLine("OK!");
                }
                catch {
                    Console.WriteLine("FAILED!");
                    SetValue("host", "LocalHost");
                    Console.WriteLine("Unable to find host! Host has been set to loopback.");
                    result = null;
                    return false;
                }
            }
            int port;
            if (!int.TryParse(GetValue("port"), out port)) {
                SetValue("port", "2200");
                Console.WriteLine("Could not parse port as an integer! Port has been set to 2200.");
                result = null;
                return false;
            }
            result = new IPEndPoint(host, port);
            return true;
        }

        public void LoadVariables() {
            vars = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (XmlNode n in doc.SelectNodes("tcpservr/console/variable")) {
                try {
                    vars.Add(n.Attributes["name"].InnerText, n.Attributes["value"].InnerText);
                }
                catch {
                }
            }

            if (!vars.ContainsKey("host")) { vars.Add("host", "localhost"); }
            if (!vars.ContainsKey("port")) { vars.Add("port", "2200"); }
            if (!vars.ContainsKey("color")) { vars.Add("color", "08"); }
            if (!vars.ContainsKey("prompt")) { vars.Add("prompt", "$p$g"); }
            if (!vars.ContainsKey("timeout")) { vars.Add("timeout", "5000"); }
        }

        public void SaveVariables() {
            XmlNode console = doc.SelectSingleNode("tcpservr/console");
            console.RemoveAll();

            foreach (var kv in vars) {
                XmlElement var = doc.CreateElement("variable");
                var.SetAttribute("name", kv.Key);
                var.SetAttribute("value", kv.Value);
                console.AppendChild(var);
            }
        }

        public void Save() {
            SaveVariables();
            doc.Save(curdir + "\\Data.xml");
        }

        public string ReplaceVariables(string line) {
            string ret = line;

            foreach (var kv in vars) {
                ret = System.Text.RegularExpressions.Regex.Replace(ret, "%" + kv.Key + "%", kv.Value, System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            }

            return ret;
        }

        public bool SetColor(string hex) {
            if (hex.Length != 2) { return false; }
            string bcolor = hex.ToLower().Remove(1, 1);
            string fcolor = hex.ToLower().Remove(0, 1);
            if (bcolor.Equals(fcolor)) { 
                return false;
            }
            switch (bcolor) {
                case "0": Console.BackgroundColor = ConsoleColor.Black; break;
                case "1": Console.BackgroundColor = ConsoleColor.DarkBlue; break;
                case "2": Console.BackgroundColor = ConsoleColor.DarkGreen; break;
                case "3": Console.BackgroundColor = ConsoleColor.DarkCyan; break;
                case "4": Console.BackgroundColor = ConsoleColor.DarkRed; break;
                case "5": Console.BackgroundColor = ConsoleColor.DarkMagenta; break;
                case "6": Console.BackgroundColor = ConsoleColor.DarkYellow; break;
                case "7": Console.BackgroundColor = ConsoleColor.DarkGray; break;
                case "8": Console.BackgroundColor = ConsoleColor.Gray; break;
                case "9": Console.BackgroundColor = ConsoleColor.Blue; break;
                case "a": Console.BackgroundColor = ConsoleColor.Green; break;
                case "b": Console.BackgroundColor = ConsoleColor.Cyan; break;
                case "c": Console.BackgroundColor = ConsoleColor.Red; break;
                case "d": Console.BackgroundColor = ConsoleColor.Magenta; break;
                case "e": Console.BackgroundColor = ConsoleColor.Yellow; break;
                case "f": Console.BackgroundColor = ConsoleColor.White; break;
                default: return false;
            }
            switch (fcolor) {
                case "0": Console.ForegroundColor = ConsoleColor.Black; break;
                case "1": Console.ForegroundColor = ConsoleColor.DarkBlue; break;
                case "2": Console.ForegroundColor = ConsoleColor.DarkGreen; break;
                case "3": Console.ForegroundColor = ConsoleColor.DarkCyan; break;
                case "4": Console.ForegroundColor = ConsoleColor.DarkRed; break;
                case "5": Console.ForegroundColor = ConsoleColor.DarkMagenta; break;
                case "6": Console.ForegroundColor = ConsoleColor.DarkYellow; break;
                case "7": Console.ForegroundColor = ConsoleColor.DarkGray; break;
                case "8": Console.ForegroundColor = ConsoleColor.Gray; break;
                case "9": Console.ForegroundColor = ConsoleColor.Blue; break;
                case "a": Console.ForegroundColor = ConsoleColor.Green; break;
                case "b": Console.ForegroundColor = ConsoleColor.Cyan; break;
                case "c": Console.ForegroundColor = ConsoleColor.Red; break;
                case "d": Console.ForegroundColor = ConsoleColor.Magenta; break;
                case "e": Console.ForegroundColor = ConsoleColor.Yellow; break;
                case "f": Console.ForegroundColor = ConsoleColor.White; break;
                default: return false;
            }
            return true;
        }

        public string GetPrompt(string remoteDir) {
            string prompt = GetValue("prompt");
            prompt = prompt.Replace("$a", "&").Replace("$A", "&");
            prompt = prompt.Replace("$b", "|").Replace("$B", "|");
            prompt = prompt.Replace("$c", "(").Replace("$C", "(");
            prompt = prompt.Replace("$d", DateTime.Today.Date.ToShortDateString()).Replace("$D", DateTime.Today.Date.ToShortDateString());
            prompt = prompt.Replace("$e", Encoding.UTF8.GetString(new byte[] { 27 })).Replace("$E", Encoding.UTF8.GetString(new byte[] { 27 }));
            prompt = prompt.Replace("$f", ")").Replace("$F", ")");
            prompt = prompt.Replace("$g", ">").Replace("$G", ">");
            prompt = prompt.Replace("$h", "\b").Replace("$H", "\b");
            prompt = prompt.Replace("$l", "<").Replace("$L", "<");
            if (remoteDir.CompareTo("") != 0) {
                prompt = prompt.Replace("$n", remoteDir.Remove(2, remoteDir.Length - 2)).Replace("$N", remoteDir.Remove(2, remoteDir.Length - 2));
                prompt = prompt.Replace("$p", remoteDir).Replace("$P", remoteDir);
            }
            else {
                prompt = prompt.Replace("$n", "").Replace("$N", "");
                prompt = prompt.Replace("$p", "").Replace("$P", "");
            }
            prompt = prompt.Replace("$q", "=").Replace("$Q", "=");
            prompt = prompt.Replace("$s", " ").Replace("$S", " ");
            prompt = prompt.Replace("$t", DateTime.Now.TimeOfDay.ToString().Remove(DateTime.Now.TimeOfDay.ToString().Length - 5, 5)).Replace("$T", DateTime.Now.TimeOfDay.ToString().Remove(DateTime.Now.TimeOfDay.ToString().Length - 5, 5));
            prompt = prompt.Replace("$v", "TCPSERVR Console [Version 1.0.2014]").Replace("$V", "TCPSERVR Console [Version 1.0.2014]");
            return prompt.Trim();
        }
    }
}
