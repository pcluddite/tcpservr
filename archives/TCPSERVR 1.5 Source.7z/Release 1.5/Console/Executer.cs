﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.IO;
using Tbasic.Components;

namespace console {
    public class Executer {

        private Settings settings;
        private TcpSecure security;

        public Executer(Settings settings) {
            this.settings = settings;
            if (settings.Password == null) {
                security = null;
            }
            else {
                security = new TcpSecure(settings.Password);
            }
        }

        public bool Connect(TMessage tMsg, TcpClient client) {
            if (tMsg.Args.Length == 1) {
                if (client.Client != null && client.Connected) {
                    Console.WriteLine("A server connection has already been established!");
                    return false;
                }
                try {
                    IPEndPoint ep;
                    if (!settings.GetHost(out ep)) {
                        Console.WriteLine("The client is not connected.");
                        return false;
                    }
                    Console.Write("Connecting to {0}:{1}...", ep.Address, ep.Port);
                    client.Connect(ep);
                    Console.WriteLine("OK!");
                    Console.WriteLine("Connection established!");
                    return true;
                }
                catch (Exception ex) {
                    Console.WriteLine("FAILED!");
                    PrintException(ex);
                }
            }
            else {
                Console.WriteLine("'CONNECT' does not take any arguments");
            }
            return false;
        }

        public bool Disconnect(TMessage tMsg, TcpClient client) {
            if (tMsg.Args.Length == 1) {
                try {
                    client.Client.Shutdown(SocketShutdown.Both);
                    client.Close();
                    Console.WriteLine("Disconnected from remote host.");
                    return true;
                }
                catch (Exception ex) {
                    PrintException(ex);
                }
            }
            else {
                Console.WriteLine("'DISCONNECT' does not take any arguments.");
            }
            return false;
        }

        public void Set(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                if (tMsg.Args[1].Contains("=")) {
                    string var = tMsg.Args[1].Split('=')[0];
                    string val = tMsg.Args[1].Split('=')[1];

                    if (!val.Equals("")) {
                        settings.SetValue(var, val);
                    }
                    else {
                        settings.RemoveValue(var);
                    }
                }
                else {
                    Console.WriteLine(settings.GetValue(tMsg.Args[1]));
                }
            }
            else if (tMsg.Args.Length == 1) {
                foreach (var kv in settings.GetVariables()) {
                    Console.WriteLine("{0}={1}", kv.Key, kv.Value);
                }
            }
            else {
                Console.WriteLine("'SET' had too many arguments.");
            }
        }

        public void Exit(TcpClient client) {
            try {
                settings.RemoveValue("lastdata");
                settings.Save();
                client.Client.Shutdown(SocketShutdown.Both);
                client.Close();
            }
            catch {
            }
        }

        public static void PrintException(Exception ex) {
            Type type = ex.GetType();
            if (type == typeof(NullReferenceException) || ex.Message.Contains("no address was supplied")) {
                Console.WriteLine("The client is not connected to a remote host.");
            }
            else if (type == typeof(ObjectDisposedException)) {
                Console.WriteLine("The client has been disconnected.");
            }
            else if (ex.Message.Contains("target machine actively refused")) {
                Console.WriteLine("The host machine is not accepting any connections at that port.");
            }
            else if (type == typeof(SocketException)) {
                Console.WriteLine("Unable to connect to the remote host.");
            }
            else {
                Console.WriteLine("A network exception occoured:\r\n" + ex.Message);
            }
        }

        public void Help() {
            Console.WriteLine("List of Local Commands");
            Console.WriteLine();
            Console.WriteLine("{0,-25}{1,-50}", "cls", "Clears the screen");
            Console.WriteLine("{0,-25}{1,-50}", "color", "Changes the console color. (/? for more)");
            Console.WriteLine("{0,-25}{1,-50}", "connect", "Connects to the remote host");
            Console.WriteLine("{0,-25}{1,-50}", "disconnect", "Ends connection to the remote host");
            Console.WriteLine("{0,-25}{1,-50}", "exit", "Ends connection to the host (if any) and exits");
            Console.WriteLine("{0,-25}{1,-50}", "prompt", "Changes the console prompt (/? for more)");
            Console.WriteLine("{0,-25}{1,-50}", "saveas", "Saves the last data into a file (for byte messages)");
            Console.WriteLine("{0,-25}{1,-50}", "set host=HOST", "Sets the host computer");
            Console.WriteLine("{0,-25}{1,-50}", "set port=PORT", "Sets the socket port for the host");
            Console.WriteLine("{0,-25}{1,-50}", "set timeout=TIME", "Sets the time limit (in milliseconds) to read messages");
            Console.WriteLine("{0,-25}{1,-50}", "set VAR=VALUE", "Sets an environment variable to be used in %'s");
            Console.WriteLine();
            Console.WriteLine("These commands are local commands. For remote commands refer to documentation.");
        }

        public void Color(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                ConsoleColor fcurrent = Console.ForegroundColor;
                ConsoleColor bcurrent = Console.BackgroundColor;
                if (tMsg.Args[1].Equals("/?")) {
                    try {
                        System.Diagnostics.Process p = new System.Diagnostics.Process();
                        p.StartInfo.FileName = "cmd.exe";
                        p.StartInfo.Arguments = "/c color /?";
                        p.StartInfo.RedirectStandardOutput = true;
                        p.StartInfo.UseShellExecute = false;
                        p.StartInfo.CreateNoWindow = true;
                        p.Start();
                        Console.WriteLine(p.StandardOutput.ReadToEnd());
                    }
                    catch (Exception ex) {
                        PrintException(ex);
                    }
                    return;
                }
                if (!settings.SetColor(tMsg.Args[1])) {
                    Console.ForegroundColor = fcurrent;
                    Console.BackgroundColor = bcurrent;
                    Console.WriteLine("'CONNECT' does not take any arguments.");
                }
                else {
                    settings.SetValue("color", tMsg.Args[1]);
                }
            }
            else {
                Console.WriteLine("The syntax of the command was invalid.");
            }
        }

        public string Prompt(TMessage tMsg) {
            if (tMsg.DataString.Remove(0, 6).Trim().CompareTo("/?") == 0) {
                try {
                    System.Diagnostics.Process p = new System.Diagnostics.Process();
                    p.StartInfo.FileName = "cmd.exe";
                    p.StartInfo.Arguments = "/c prompt /?";
                    p.StartInfo.RedirectStandardOutput = true;
                    p.StartInfo.UseShellExecute = false;
                    p.StartInfo.CreateNoWindow = true;
                    p.Start();
                    Console.WriteLine(p.StandardOutput.ReadToEnd());
                }
                catch (Exception ex) {
                    PrintException(ex);
                }
                return null;
            }
            return tMsg.DataString.Remove(0, 6).Trim();
        }

        public bool Pass(TMessage tMsg) {
            if (tMsg.Args.Length == 2) {
                if (tMsg.Args[1].Equals("")) {
                    settings.Password = null;
                    Console.WriteLine("No key will be used to send and receive data.");
                    return true;
                }
                else {
                    settings.Password = tMsg.Args[1];
                    Console.WriteLine("Data will now be sent and received with this key.");
                    return true;
                }
            }
            else {
                Console.WriteLine("The syntax of the command was invalid.");
            }
            return false;
        }

        public void SaveAs(TMessage tMsg, string lastData) {
            if (tMsg.Args.Length != 2) {
                Console.WriteLine("The syntax of the command was incorrect.");
            }
            try {
                File.WriteAllBytes(tMsg.Args[1], Convert.FromBase64String(lastData));
                Console.WriteLine("The last data received was saved as '{0}'.", tMsg.Args[1]);
            }
            catch (Exception ex) {
                PrintException(ex);
            }
        }
    }
}
